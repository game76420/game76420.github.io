from __future__ import annotations

"""Source-grounded Python recreation of the WinMine v3.0a core.

GUI architecture in this step deliberately follows the original Windows/GDI
shape: USER32 window/message loop + GDI BitBlt/brush/pen/font operations.
No pygame/SDL runtime is used.

Authoritative sources shipped under source/:
  WINMINE.EXE, WINMINE.EXE.c, WINMINE.EXE.asm, original PNG-converted bitmap sheets and icon resource.
"""

import configparser
import ctypes
from ctypes import wintypes
import time
import struct
import zlib
from dataclasses import dataclass
from pathlib import Path

CELL = 16
BOARD_X = 0x07  # MAINWNDPROC mouse mapping base
BOARD_Y = 0x27  # MAINWNDPROC mouse mapping base; first cell is +0x10
TOP_H = 0x34
MIN_W = 8
MIN_H = 8
MAX_H = 30

COVERED = 0x0F
FLAG = 0x0E
QUESTION = 0x0D
MINE_REVEALED = 0x0C
WRONG_FLAG = 0x0B
LOSS_MINE = 0x0A

# Win32 constants used by the original MAINWNDPROC / rendering path.
WM_DESTROY = 0x0002
WM_SIZE = 0x0005
WM_PAINT = 0x000F
WM_CLOSE = 0x0010
WM_ENDSESSION = 0x0016
WM_ERASEBKGND = 0x0014
WM_KEYDOWN = 0x0100
WM_COMMAND = 0x0111
WM_TIMER = 0x0113
WM_MOUSEMOVE = 0x0200
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_LBUTTONDBLCLK = 0x0203
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
WM_MBUTTONDOWN = 0x0207
WM_MBUTTONUP = 0x0208
WM_MOUSEACTIVATE = 0x0021
WM_CAPTURECHANGED = 0x0215
WM_SYSCOMMAND = 0x0112
WM_ACTIVATE = 0x0006
WM_MOVE = 0x0003
WM_INITDIALOG = 0x0110
WM_LBUTTONDBLCLK = 0x0203
IDOK = 1
IDCANCEL = 2
DS_MODALFRAME = 0x80
DS_SETFONT = 0x40
WS_POPUP = 0x80000000
WS_CAPTION = 0x00C00000
WS_SYSMENU = 0x00080000
WS_CHILD = 0x40000000
WS_VISIBLE = 0x10000000
WS_TABSTOP = 0x00010000
ES_NUMBER = 0x2000
ES_AUTOHSCROLL = 0x0080
BS_DEFPUSHBUTTON = 0x0001
SS_LEFT = 0x00000000
WM_NCHITTEST = 0x0084

VK_F2 = 0x71
VK_ESCAPE = 0x1B

MF_STRING = 0x0000
MF_SEPARATOR = 0x0800
MF_CHECKED = 0x0008
MF_UNCHECKED = 0x0000
MF_POPUP = 0x0010

IMAGE_BITMAP = 0
LR_LOADFROMFILE = 0x00000010
LR_CREATEDIBSECTION = 0x00002000
SRCCOPY = 0x00CC0020
PATCOPY = 0x00F00021
TRANSPARENT = 1
NULL_BRUSH = 5
WHITE_BRUSH = 0
GRAY_BRUSH = 2
BLACK_PEN = 7
WHITE_PEN = 6
PS_SOLID = 0
FW_NORMAL = 400
FW_BOLD = 700
DT_SINGLELINE = 0x20
DT_CENTER = 0x1

IDM_NEW = 0x1FE
IDM_QUIT = 0x200
IDM_BEGINNER = 0x209
IDM_INTERMEDIATE = 0x20A
IDM_EXPERT = 0x20B
IDM_CUSTOM = 0x20C
IDM_MARK = 0x20F
IDM_BEST = 0x210
IDM_COLOR = 0x211
IDM_HELP_CONTENTS = 0x24F
IDM_HELP_SEARCH = 0x251
IDM_HELP_HOW = 0x252
IDM_ABOUT = 0x254

TIMER_ID = 1


class SourceRNG:
    """Exact arithmetic equivalent of FUN_1000_2600/FUN_1000_2612/FUN_1000_1736."""
    def __init__(self, seed: int = 0):
        self.low = seed & 0xFFFF
        self.high = 0

    def next15(self) -> int:
        # FUN_1000_2612 -> FUN_1000_2a10, preserving the original
        # 16-bit/16-bit product layout exactly.  In the native helper,
        # low*3 is added to the HIGH word, not to the low word.
        # The previous implementation put low*3 into the complete 32-bit
        # value and therefore produced the wrong low-word recurrence;
        # for some seeds that made mine placement repeat indefinitely.
        low = self.low & 0xFFFF
        high = self.high & 0xFFFF

        product = low * 0x43FD
        low_word = product & 0xFFFF
        high_word = ((product >> 16) + high * 0x43FD + low * 3) & 0xFFFFFFFF

        # ADD AX,9EC3h / ADC DX,26h in the original ASM.
        low_word += 0x9EC3
        carry = 1 if low_word > 0xFFFF else 0
        low_word &= 0xFFFF
        high_word = (high_word + 0x26 + carry) & 0xFFFF

        self.low = low_word
        self.high = high_word
        return self.high & 0x7FFF

    def mod(self, n: int) -> int:
        return self.next15() % n


@dataclass
class Preset:
    name: str
    mines: int
    width: int
    height: int


# The native command table is read at FUN_1000_111 / FUN_1000_0320:
# 0x209/0x20a/0x20b select the first three six-byte records.
PRESETS = [
    Preset("初學者", 10, 8, 8),
    Preset("中級者", 40, 16, 16),
    Preset("進階者", 99, 30, 16),
]

# Exact Big5 strings extracted from the original NE RT_STRING resource (IDs 1..15).
# These are source data, not newly authored UI copy.
SOURCE_STRINGS = {
    2: "踩地雷",
    3: "WINMINE.HLP",
    4: "踩地雷錯誤",
    5: "計時資源不足以供踩地雷使用.\n\n請結束一或多個應用程式, 然後再試一次.",
    6: "記憶體不足",
    7: "錯誤: %d",
    8: "%d 秒",
    9: "不具名的",
    10: "在初學者這一級, 你的速度最快.\n請留下您的大名.",
    11: "在中級者這一級, 你的速度最快.\n請留下您的大名.",
    12: "在進階者這一級, 你的速度最快.\n請留下您的大名.",
    13: "踩地雷",
    14: "經由 Robert Donner 和 Curt Johnson ",
    15: "踩地雷",
}

# Exact menu captions extracted from the original RT_MENU resource (resource 500).
SOURCE_MENU = {
    "game": "遊戲(&G)",
    "new": "開新檔案(&N)\tF2",
    "beginner": "初學者(&B)",
    "intermediate": "中級者(&I)",
    "expert": "進階者(&E)",
    "custom": "依個人偏好修改(&C)...",
    "mark": "標記(?)(&M) ",
    "color": "色彩(&l)",
    "best": "最快時間(&T)...",
    "quit": "結束(&X)",
    "help": "輔助說明(&H)",
    "help_contents": "內容(&C)\tF1",
    "help_search": "尋找輔助說明主題(&S)",
    "help_how": "輔助說明使用方法(&H)",
    "about": "關於踩地雷(&A)...",
}


if hasattr(ctypes, "windll"):
    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    kernel32 = ctypes.windll.kernel32
else:  # import-safe on non-Windows; runtime reports a clear error.
    user32 = gdi32 = kernel32 = None


def _configure_win32():
    if user32 is None:
        return
    # Explicit pointer-sized signatures are required on 64-bit Windows.
    kernel32.GetModuleHandleW.restype = ctypes.c_void_p
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    user32.GetSystemMetrics.restype = ctypes.c_int
    user32.GetSystemMetrics.argtypes = [ctypes.c_int]
    user32.RegisterClassExW.restype = wintypes.ATOM
    user32.RegisterClassExW.argtypes = [ctypes.c_void_p]
    user32.LoadCursorW.restype = ctypes.c_void_p
    user32.LoadCursorW.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    user32.LoadImageW.restype = ctypes.c_void_p
    user32.LoadImageW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    user32.CreateWindowExW.restype = ctypes.c_void_p
    user32.CreateWindowExW.argtypes = [wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
    user32.DefWindowProcW.restype = ctypes.c_ssize_t
    user32.DefWindowProcW.argtypes = [ctypes.c_void_p, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.BeginPaint.restype = wintypes.HDC
    user32.BeginPaint.argtypes = [ctypes.c_void_p, ctypes.POINTER(PAINTSTRUCT)] if 'PAINTSTRUCT' in globals() else None
    user32.EndPaint.argtypes = [ctypes.c_void_p, ctypes.POINTER(PAINTSTRUCT)] if 'PAINTSTRUCT' in globals() else None
    user32.GetClientRect.argtypes = [ctypes.c_void_p, ctypes.POINTER(RECT)] if 'RECT' in globals() else None
    user32.InvalidateRect.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.BOOL]
    user32.SetTimer.restype = ctypes.c_uint
    user32.SetTimer.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p]
    user32.KillTimer.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    user32.ShowWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
    user32.UpdateWindow.argtypes = [ctypes.c_void_p]
    user32.SetCapture.restype = ctypes.c_void_p
    user32.SetCapture.argtypes = [ctypes.c_void_p]
    user32.ReleaseCapture.restype = wintypes.BOOL
    user32.DestroyWindow.argtypes = [ctypes.c_void_p]
    user32.CloseWindow.argtypes = [ctypes.c_void_p]
    user32.PostQuitMessage.argtypes = [ctypes.c_int]
    user32.GetMessageW.restype = ctypes.c_int
    user32.GetMessageW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.UINT, wintypes.UINT]
    user32.TranslateMessage.argtypes = [ctypes.c_void_p]
    user32.DispatchMessageW.argtypes = [ctypes.c_void_p]
    user32.AdjustWindowRectEx.argtypes = [ctypes.POINTER(RECT), wintypes.DWORD, wintypes.BOOL, wintypes.DWORD] if 'RECT' in globals() else None
    user32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    user32.CreateMenu.restype = ctypes.c_void_p
    user32.CreatePopupMenu.restype = ctypes.c_void_p
    user32.AppendMenuW.argtypes = [ctypes.c_void_p, wintypes.UINT, ctypes.c_size_t, wintypes.LPCWSTR]
    user32.CheckMenuItem.argtypes = [ctypes.c_void_p, wintypes.UINT, wintypes.UINT]
    user32.DrawMenuBar.argtypes = [ctypes.c_void_p]
    user32.SetMenu.restype = wintypes.BOOL
    user32.SetMenu.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    user32.PostMessageW.restype = wintypes.BOOL
    user32.PostMessageW.argtypes = [ctypes.c_void_p, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.MessageBoxW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.UINT]
    user32.DialogBoxIndirectParamW.restype = ctypes.c_int
    user32.DialogBoxIndirectParamW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, wintypes.LPARAM]
    user32.EndDialog.argtypes = [ctypes.c_void_p, ctypes.c_int]
    user32.GetDlgItem.argtypes = [ctypes.c_void_p, ctypes.c_int]
    user32.SetDlgItemInt.argtypes = [ctypes.c_void_p, ctypes.c_int, wintypes.UINT, wintypes.BOOL]
    user32.GetDlgItemInt.restype = wintypes.UINT
    user32.GetDlgItemInt.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(wintypes.BOOL), wintypes.BOOL]
    user32.SetDlgItemTextW.argtypes = [ctypes.c_void_p, ctypes.c_int, wintypes.LPCWSTR]
    user32.GetDlgItemTextW.argtypes = [ctypes.c_void_p, ctypes.c_int, wintypes.LPWSTR, ctypes.c_int]
    user32.SetWindowTextW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    user32.WinHelpW.restype = wintypes.BOOL
    user32.WinHelpW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_size_t]
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    gdi32.GetStockObject.restype = ctypes.c_void_p
    gdi32.GetStockObject.argtypes = [ctypes.c_int]
    gdi32.CreateSolidBrush.restype = ctypes.c_void_p
    gdi32.CreateSolidBrush.argtypes = [wintypes.COLORREF]
    gdi32.CreateCompatibleDC.restype = wintypes.HDC
    gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
    gdi32.SelectObject.restype = ctypes.c_void_p
    gdi32.SelectObject.argtypes = [wintypes.HDC, ctypes.c_void_p]
    gdi32.DeleteDC.argtypes = [wintypes.HDC]
    gdi32.DeleteObject.argtypes = [ctypes.c_void_p]
    gdi32.BitBlt.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.HDC, ctypes.c_int, ctypes.c_int, wintypes.DWORD]
    gdi32.GetObjectW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
    gdi32.CreatePen.restype = ctypes.c_void_p
    gdi32.CreatePen.argtypes = [ctypes.c_int, ctypes.c_int, wintypes.COLORREF]
    gdi32.Rectangle.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
    gdi32.MoveToEx.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
    gdi32.LineTo.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
    gdi32.SetROP2.argtypes = [wintypes.HDC, ctypes.c_int]
    user32.FillRect.argtypes = [wintypes.HDC, ctypes.POINTER(RECT), ctypes.c_void_p]


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG),
                ("right", wintypes.LONG), ("bottom", wintypes.LONG)]


class PAINTSTRUCT(ctypes.Structure):
    _fields_ = [
        ("hdc", wintypes.HDC), ("fErase", wintypes.BOOL), ("rcPaint", RECT),
        ("fRestore", wintypes.BOOL), ("fIncUpdate", wintypes.BOOL),
        ("rgbReserved", wintypes.BYTE * 32),
    ]


# The WNDCLASSEXW.lpfnWndProc member is a real function pointer in the
# Win32 ABI.  Keep the callback type in the structure rather than declaring
# the field as c_void_p; Python 3.13 rejects assigning a CFUNCTYPE instance
# directly to a c_void_p structure field.
WNDPROC = (ctypes.WINFUNCTYPE(ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT,
                              wintypes.WPARAM, wintypes.LPARAM)
           if hasattr(ctypes, "WINFUNCTYPE") else ctypes.c_void_p)


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT), ("style", wintypes.UINT),
        ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int),
        ("hInstance", ctypes.c_void_p), ("hIcon", ctypes.c_void_p),
        ("hCursor", ctypes.c_void_p), ("hbrBackground", ctypes.c_void_p),
        ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR),
        ("hIconSm", ctypes.c_void_p),
    ]


# The structures above must exist before _configure_win32() binds pointer
# arguments.  Binding them earlier leaves BeginPaint/GetClientRect/
# AdjustWindowRectEx with ctypes' default 32-bit argument conversion on
# 64-bit Windows, which can truncate the RECT pointer and prevent painting.
_configure_win32()


def _lo_word(v: int) -> int:
    return v & 0xFFFF


def _hi_word(v: int) -> int:
    return (v >> 16) & 0xFFFF


def _signed16(v: int) -> int:
    return v - 0x10000 if v & 0x8000 else v



class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
        ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]

class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 1)]

BI_RGB = 0
DIB_RGB_COLORS = 0


def _decode_png_rgba(path: str):
    """Decode the PNGs produced from the source BMP sheets using stdlib only."""
    data = Path(path).read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"Not a PNG file: {path}")
    pos = 8
    width = height = bit_depth = color_type = None
    packed = bytearray()
    while pos < len(data):
        if pos + 8 > len(data): raise ValueError("Truncated PNG chunk")
        n = struct.unpack_from(">I", data, pos)[0]; typ = data[pos+4:pos+8]; pos += 8
        chunk = data[pos:pos+n]; pos += n
        if pos + 4 > len(data): raise ValueError("Truncated PNG CRC")
        pos += 4
        if typ == b"IHDR":
            width, height, bit_depth, color_type, comp, filt, interlace = struct.unpack(">IIBBBBB", chunk)
            if bit_depth != 8 or interlace != 0 or comp != 0 or filt != 0:
                raise ValueError("Unsupported PNG format")
        elif typ == b"IDAT":
            packed.extend(chunk)
        elif typ == b"IEND":
            break
    if width is None or not packed: raise ValueError("Invalid PNG")
    raw=zlib.decompress(bytes(packed))
    channels={0:1,2:3,4:2,6:4}.get(color_type)
    if channels is None: raise ValueError("Unsupported PNG color type")
    stride=width*channels
    expected=(stride+1)*height
    if len(raw) != expected: raise ValueError("Unexpected PNG data size")
    rows=[]; prev=bytearray(stride); off=0
    for _ in range(height):
        f=raw[off]; off+=1; cur=bytearray(raw[off:off+stride]); off+=stride
        for i in range(stride):
            a=cur[i-channels] if i>=channels else 0
            b=prev[i]
            c=prev[i-channels] if i>=channels else 0
            if f==1: cur[i]=(cur[i]+a)&255
            elif f==2: cur[i]=(cur[i]+b)&255
            elif f==3: cur[i]=(cur[i]+((a+b)//2))&255
            elif f==4:
                p=a+b-c; pa=abs(p-a); pb=abs(p-b); pc=abs(p-c)
                pr=a if pa<=pb and pa<=pc else (b if pb<=pc else c)
                cur[i]=(cur[i]+pr)&255
            elif f!=0: raise ValueError("Unsupported PNG filter")
        rows.append(cur); prev=cur
    rgba=bytearray(width*height*4)
    for y,row in enumerate(rows):
        for x in range(width):
            si=x*channels; di=(y*width+x)*4
            if color_type==6: rgba[di:di+4]=row[si:si+4]
            elif color_type==2: rgba[di:di+3]=row[si:si+3]; rgba[di+3]=255
            elif color_type==4: rgba[di]=rgba[di+1]=rgba[di+2]=row[si]; rgba[di+3]=row[si+1]
            else: rgba[di]=rgba[di+1]=rgba[di+2]=row[si]; rgba[di+3]=255
    return width,height,bytes(rgba)


def _load_png_as_dib(path: str):
    if gdi32 is None: return None
    width,height,rgba=_decode_png_rgba(path)
    bmi=BITMAPINFO()
    bmi.bmiHeader.biSize=ctypes.sizeof(BITMAPINFOHEADER)
    bmi.bmiHeader.biWidth=width
    bmi.bmiHeader.biHeight=-height  # top-down DIB preserves PNG visual row order
    bmi.bmiHeader.biPlanes=1
    bmi.bmiHeader.biBitCount=32
    bmi.bmiHeader.biCompression=BI_RGB
    bits=ctypes.c_void_p()
    gdi32.CreateDIBSection.restype=ctypes.c_void_p
    gdi32.CreateDIBSection.argtypes=[wintypes.HDC, ctypes.POINTER(BITMAPINFO), wintypes.UINT, ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p, wintypes.DWORD]
    hbmp=gdi32.CreateDIBSection(None, ctypes.byref(bmi), DIB_RGB_COLORS, ctypes.byref(bits), None, 0)
    if not hbmp or not bits.value: return None
    # GDI 32bpp BI_RGB expects BGRA byte order.
    out=bytearray(len(rgba))
    for i in range(0,len(rgba),4):
        r,g,b,a=rgba[i:i+4]; out[i:i+4]=bytes((b,g,r,a))
    ctypes.memmove(bits.value, bytes(out), len(out))
    return hbmp

class NativeBitmapSheet:
    """Load the source sprite sheet from PNG into a GDI DIB, then BitBlt frames."""

    def __init__(self, path: Path, frame_w: int, frame_h: int):
        if user32 is None:
            raise RuntimeError("WINMINE native GUI requires Windows USER32/GDI32")
        self.path = path
        self.frame_w = frame_w
        self.frame_h = frame_h
        self.hbmp = _load_png_as_dib(str(path))
        if not self.hbmp:
            raise OSError(f"PNG load failed for {path}")
        bm = BITMAP()
        if not gdi32.GetObjectW(self.hbmp, ctypes.sizeof(bm), ctypes.byref(bm)):
            raise OSError(f"GetObjectW failed for {path}")
        self.width = abs(bm.bmWidth)
        self.height = abs(bm.bmHeight)
        self.count = self.height // frame_h

    def draw(self, dst_hdc, index: int, x: int, y: int) -> None:
        index = max(0, min(self.count - 1, int(index)))
        # Generic visual-frame helper.  This indexes the loaded bitmap in
        # GDI's top-to-bottom DC coordinate system.
        src_y = index * self.frame_h
        src_dc = gdi32.CreateCompatibleDC(dst_hdc)
        if not src_dc:
            return
        old = gdi32.SelectObject(src_dc, self.hbmp)
        gdi32.BitBlt(dst_hdc, x, y, self.frame_w, self.frame_h,
                     src_dc, 0, src_y, SRCCOPY)
        gdi32.SelectObject(src_dc, old)
        gdi32.DeleteDC(src_dc)

    def draw_source_frame(self, dst_hdc, source_index: int, x: int, y: int) -> None:
        # The original source does not use a top-to-bottom sprite index.
        # FUN_1000_1d70 indexes the DIB offset table with source_index, and
        # the shipped BMP is a positive-height (bottom-up) DIB.  Therefore
        # source index 0 is the bottom visual frame, source index 1 the next
        # one, etc.  Convert that source/DIB index to GDI DC coordinates here.
        index = max(0, min(self.count - 1, int(source_index)))
        self.draw(dst_hdc, self.count - 1 - index, x, y)

    def close(self):
        if self.hbmp:
            gdi32.DeleteObject(self.hbmp)
            self.hbmp = None


class BITMAP(ctypes.Structure):
    _fields_ = [
        ("bmType", wintypes.LONG), ("bmWidth", wintypes.LONG),
        ("bmHeight", wintypes.LONG), ("bmWidthBytes", wintypes.LONG),
        ("bmPlanes", wintypes.WORD), ("bmBitsPixel", wintypes.WORD),
        ("bmBits", wintypes.LPVOID),
    ]



class WinMineGame:
    """Core state + source-shaped native Windows presentation."""

    def __init__(self, root: Path):
        if user32 is None:
            raise RuntimeError("This recreation intentionally uses native Win32/GDI and must run on Windows.")
        self.root = root
        self.config_path = root / "winmine.ini"
        self.low_resolution = False
        if user32 is not None:
            try:
                self.low_resolution = int(user32.GetSystemMetrics(1)) < 0x1E0
            except Exception:
                pass
        self.resource_exe = root / "source" / "WINMINE.EXE"
        self.preset_index = 0
        self.mark_enabled = True
        self.custom = False
        self.width, self.height, self.mine_total = 9, 9, 10
        self.best = [999, 999, 999]
        self.best_names = ["", "", ""]
        # WM_PAINT can arrive before the first board/reset path. The native
        # counter starts at the configured mine total, so initialize its
        # Python counterpart before creating the window.
        self.mine_remaining = self.mine_total
        self.load_preferences()
        self.mine_remaining = self.mine_total
        self.hwnd = None
        self.hinstance = kernel32.GetModuleHandleW(None)
        self.class_name = "PY_WINMINE_NATIVE"
        self._wndproc = None
        self.menu = None
        self.font = None
        self.bevel_pen = None
        self.running = True
        self.left_down = False
        self.chord = False
        self.press_face = False
        self.press_face_button = False
        self._last_mouse = (0, 0)
        self.hover_x = -1
        self.hover_y = -1
        self.cheat_index = 0
        self._eat_next_click = False
        self._paused = False
        self._menu_mouse_state = 0
        self.color_supported = True
        self.color_mode = True
        self.sound_state_code = 3
        self.sound_enabled = True
        seed = 0
        if kernel32 is not None:
            try:
                kernel32.GetTickCount.restype = wintypes.DWORD
                seed = int(kernel32.GetTickCount()) & 0xFFFF
            except Exception:
                seed = int(time.monotonic_ns() // 1_000_000) & 0xFFFF
        else:
            seed = int(time.monotonic_ns() // 1_000_000) & 0xFFFF
        self._rng = SourceRNG(seed)
        # Source FUN_1000_0010 creates/shows the native window and initializes
        # its resources before FUN_1000_11c3 performs the first mine layout.
        self._create_window()
        self.new_game()
        self._invalidate()

    def _detect_display_capability(self):
        # Source FUN_1000_17e5: DAT_0380 = (GetDeviceCaps(desktop DC, 0x18) > 2).
        if user32 is None or gdi32 is None:
            return True
        try:
            hwnd = user32.GetDesktopWindow()
            hdc = user32.GetDC(hwnd)
            if not hdc:
                return True
            gdi32.GetDeviceCaps.restype = ctypes.c_int
            gdi32.GetDeviceCaps.argtypes = [ctypes.c_void_p, ctypes.c_int]
            value = int(gdi32.GetDeviceCaps(hdc, 0x18))
            user32.ReleaseDC(hwnd, hdc)
            return value > 2
        except Exception:
            return True

    # FUN_1000_2274 / FUN_1000_232f
    def load_preferences(self):
        cfg = configparser.ConfigParser()
        if self.config_path.exists():
            try:
                cfg.read(self.config_path, encoding="mbcs")
            except Exception:
                cfg.read(self.config_path, encoding="utf-8")
        self.width, self.height, self.mine_total = 8, 8, 10
        self.xpos, self.ypos = 0x50, 0x50
        self.sound_enabled = True
        self.sound_state_code = 3
        self.tick_enabled = True
        # FUN_1000_232f defaults Color to DAT_0380 (display color capability), not
        # unconditionally to True.  The value is refined in _detect_display_capability().
        self.color_supported = self._detect_display_capability()
        self.color_mode = self.color_supported
        self.menu_mode = 2
        self.timer_subtick = 0
        self.color = 0
        self.best_names = ["", "", ""]
        section = "WinMine"
        if cfg.has_section(section):
            get = lambda k, d: cfg.getint(section, k, fallback=d)
            try: self.preset_index = max(0, min(3, get("Difficulty", 0)))
            except Exception: self.preset_index = 0
            self.height = max(8, min(16 if self.low_resolution else 22, get("Height", 8)))
            self.width = max(8, min(30, get("Width", 8)))
            self.mine_total = max(10, min(999, get("Mines", 10)))
            # Valid values produced by PREFDLGPROC obey the same upper bound
            # used by the source dialog.  Keep a stale/manual INI from
            # creating an impossible placement request.
            self.mine_total = min(self.mine_total, (self.height - 1) * (self.width - 1))
            self.xpos, self.ypos = get("Xpos", 0x50), get("Ypos", 0x50)
            self.sound_state_code = max(0, min(3, get("Sound", 3)))
            self.sound_enabled = self.sound_state_code == 3
            self.tick_enabled = get("Tick", 1) != 0
            self.color_mode = self.color_supported and (get("Color", 1) != 0)
            self.mark_enabled = get("Mark", 1) != 0
            self.menu_mode = max(0, min(2, get("Menu", 1)))
            self.config_tick = max(0, min(2, get("Tick", 0)))
            self.best = [max(0, min(999, get(k, 999))) for k in ("Time1", "Time2", "Time3")]
            self.best_names = [cfg.get(section, k, fallback="") for k in ("Name1", "Name2", "Name3")]

    # FUN_1000_24d7
    def save_preferences(self):
        cfg = configparser.ConfigParser()
        cfg["WinMine"] = {
            "Difficulty": str(self.preset_index), "Mines": str(self.mine_total),
            "Height": str(self.height), "Width": str(self.width),
            "Xpos": str(self.xpos), "Ypos": str(self.ypos),
            "Sound": str(self.sound_state_code),
            "Color": "1" if self.color_mode else "0",
            "Mark": "1" if self.mark_enabled else "0",
            "Menu": str(self.menu_mode),
            "Tick": str(getattr(self, "config_tick", 0)),
            "Time1": str(self.best[0]), "Name1": self.best_names[0],
            "Time2": str(self.best[1]), "Name2": self.best_names[1],
            "Time3": str(self.best[2]), "Name3": self.best_names[2],
        }
        self.config_path.write_text(_ini_text(cfg), encoding="utf-8")

    # FUN_1000_0d20
    def reset_board(self):
        self.board = [[0x10 for _ in range(self.width + 2)] for _ in range(self.height + 2)]
        for y in range(1, self.height + 1):
            for x in range(1, self.width + 1):
                self.board[y][x] = COVERED

    # FUN_1000_1736
    def rng_mod(self, n):
        return self._rng.mod(n)

    # FUN_1000_11c3
    def new_game(self):
        self.reset_board()
        self.revealed_safe = 0
        self.started = False
        self.finished = False
        self.won = False
        self.elapsed = 0
        self._last_tick = None
        self.timer_subtick = 0
        self.press_face = False
        self.press_face_button = False
        self.hover_x = self.hover_y = -1
        # The source Preferences dialog constrains mines to
        # min(999, (Height-1)*(Width-1)).  A stale hand-edited winmine.ini
        # can otherwise contain an impossible mine count and reproduce the
        # native placement loop forever.  Normalize that external invalid
        # state using the same documented dialog upper bound rather than
        # inventing a new game rule.
        max_mines = min(999, max(0, (self.height - 1) * (self.width - 1)))
        if self.mine_total > max_mines:
            self.mine_total = max_mines
        self.mine_remaining = self.mine_total
        placed = 0
        while placed < self.mine_total:
            x = self.rng_mod(self.width) + 1
            y = self.rng_mod(self.height) + 1
            if self.board[y][x] & 0x80:
                continue
            self.board[y][x] |= 0x80
            placed += 1
        self._invalidate()

    # FUN_1000_0d83
    def adjacent_mines(self, x, y):
        return sum(1 for yy in range(y-1, y+2) for xx in range(x-1, x+2)
                   if self.board[yy][xx] & 0x80)

    def adjacent_flags(self, x, y):
        return sum(1 for yy in range(y-1, y+2) for xx in range(x-1, x+2)
                   if self.in_board(xx, yy) and (self.board[yy][xx] & 0x1F) == FLAG)

    def in_board(self, x, y):
        return 1 <= x <= self.width and 1 <= y <= self.height

    # FUN_1000_0cf8
    def set_low_state(self, x, y, state):
        self.board[y][x] = (self.board[y][x] & 0xE0) | state

    # FUN_1000_1273
    def normalize_mark(self, x, y):
        state = self.board[y][x] & 0x1F
        if state == QUESTION: state = 9
        elif state == 0x0F: state = 0
        self.set_low_state(x, y, state)

    # FUN_1000_12be
    def cycle_mark_preview(self, x, y):
        state = self.board[y][x] & 0x1F
        if state == 9: state = QUESTION
        elif state == 0: state = 0x0F
        self.set_low_state(x, y, state)

    # FUN_1000_1724 -> FUN_1000_1e14 -> FUN_1000_1daa.
    # The native routine changes the value AND immediately paints the three
    # LED cells through GetDC/ReleaseDC; it does not invalidate the whole
    # window. Keep that call/data-flow instead of routing it through WM_PAINT.
    def change_mine_counter(self, delta):
        self.mine_remaining += delta
        self._draw_counter_now()

    # FUN_1000_15a3
    def toggle_mark(self, x, y):
        if not self.in_board(x, y) or self.finished: return
        cell = self.board[y][x]
        if cell & 0x40: return
        state = cell & 0x1F
        if state == FLAG:
            if self.mark_enabled: self.set_low_state(x, y, QUESTION)
            else: self.set_low_state(x, y, COVERED)
            self.change_mine_counter(+1)
        elif state == QUESTION:
            self.set_low_state(x, y, COVERED)
        else:
            self.set_low_state(x, y, FLAG)
            self.change_mine_counter(-1)
        if ((self.board[y][x] & 0x1F) == FLAG and
            self.revealed_safe == self.width * self.height - self.mine_total):
            self.finish(True)
        self._invalidate()

    # FUN_1000_0eed
    def reveal_one(self, x, y):
        if not self.in_board(x, y): return
        cell = self.board[y][x]
        state = cell & 0x1F
        if (cell & 0x40) or state in (0x10, FLAG): return
        self.revealed_safe += 1
        number = self.adjacent_mines(x, y)
        self.board[y][x] = number | 0x40
        if number == 0: self._queue.append((x, y))

    # FUN_1000_0f6a
    def reveal_flood(self, x, y):
        self._queue = []
        self.reveal_one(x, y)
        q = 0
        while q < len(self._queue):
            cx, cy = self._queue[q]; q += 1
            for yy in range(cy-1, cy+2):
                for xx in range(cx-1, cx+2): self.reveal_one(xx, yy)

    # FUN_1000_1028 — native scan deliberately excludes bottom/right edge.
    def open_cell(self, x, y):
        if not self.in_board(x, y) or self.finished: return
        cell = self.board[y][x]
        if cell & 0x80:
            if self.revealed_safe == 0:
                target = None
                for sy in range(1, self.height):
                    for sx in range(1, self.width):
                        if not (self.board[sy][sx] & 0x80):
                            target = (sx, sy); break
                    if target: break
                if target:
                    tx, ty = target
                    self.board[y][x] = COVERED
                    self.board[ty][tx] |= 0x80
            else:
                self.set_low_state(x, y, MINE_REVEALED)
                self.board[y][x] |= 0x40
                self.finish(False); return
        self.reveal_flood(x, y)
        if self.revealed_safe >= self.width * self.height - self.mine_total:
            self.finish(True)
        self._invalidate()

    # FUN_1000_1113
    def chord_cell(self, x, y):
        if not self.in_board(x, y) or self.finished: return
        cell = self.board[y][x]
        state = cell & 0x1F
        if not (cell & 0x40) or not (0 <= state <= 8): return
        if self.adjacent_flags(x, y) != state:
            return
        hit_mine = False
        for yy in range(y-1, y+2):
            for xx in range(x-1, x+2):
                c = self.board[yy][xx]
                if (c & 0x1F) == FLAG or not (c & 0x80): self.reveal_flood(xx, yy)
                else:
                    hit_mine = True; self.set_low_state(xx, yy, MINE_REVEALED | 0x40)
        if hit_mine: self.finish(False)
        elif self.revealed_safe == self.width * self.height - self.mine_total: self.finish(True)
        self._invalidate()

    # FUN_1000_0e30 / 0dc8
    def finish(self, win):
        self.finished, self.won = True, bool(win)
        self._last_tick = None
        if win:
            self.mine_remaining = 0
            for y in range(1, self.height+1):
                for x in range(1, self.width+1):
                    if self.board[y][x] & 0x80 and not (self.board[y][x] & 0x40): self.set_low_state(x, y, FLAG)
        else:
            for y in range(1, self.height+1):
                for x in range(1, self.width+1):
                    c = self.board[y][x]
                    if c & 0x80 and not (c & 0x40): self.set_low_state(x, y, LOSS_MINE)
                    elif (c & 0x1F) == FLAG and not (c & 0x80): self.set_low_state(x, y, WRONG_FLAG)
        if win and self.preset_index < 3 and self.elapsed < self.best[self.preset_index]:
            self.best[self.preset_index] = self.elapsed
            self.save_preferences()
            if getattr(self, "hwnd", None):
                self.show_best()
                self.show_name_entry()
        self._invalidate()

    # FUN_1000_1308 — source hover/press preview state machine.
    def handle_key_source(self, key):
        # MAINWNDPROC WM_KEYDOWN source branches.  XYZZY is a separate
        # five-key state sequence and is not substituted with a guessed rule.
        k = int(key) & 0xFF
        if k == ord("S") or k == ord("s"):
            if self.sound_state_code > 1:
                self.sound_state_code = 2 if self.sound_state_code == 3 else 3
            return False
        if k == ord("T") or k == ord("t"):
            if self.menu_mode != 0:
                self.set_menu_mode(1)
            return False
        if k == 0x75:  # VK_F6
            if self.menu_mode != 0:
                self.set_menu_mode(2)
            return False
        if k == 0x10:  # VK_SHIFT
            if self.cheat_index > 4:
                self.cheat_index ^= 0x14
            return False
        seq = b"XYZZY"
        if self.cheat_index < len(seq) and k == seq[self.cheat_index]:
            self.cheat_index += 1
        else:
            self.cheat_index = 0
        return False

    def set_menu_mode(self, mode):
        # FUN_1000_18be stores 0/1/2 and hides the menu when bit 1 is set.
        self.menu_mode = int(mode) & 3
        if self.menu_mode & 2:
            user32.SetMenu(self.hwnd, None)
        else:
            user32.SetMenu(self.hwnd, self.menu)
        user32.DrawMenuBar(self.hwnd)
        self._resize_native()

    def _rebuild_palette_mode(self):
        # The original toggles DAT_026c and rebuilds the DIB/pen resources.
        # Our source BMPs are the original color resources; the monochrome
        # mode is represented by GDI palette remapping at load time.
        self._close_sheets()
        self._load_sheets()
        self._create_bevel_pen()

    def _close_sheets(self):
        for obj in (getattr(self, "cells", None), getattr(self, "counter", None), getattr(self, "faces", None)):
            if obj: obj.close()
        if self.bevel_pen and self.color_mode:
            try: gdi32.DeleteObject(self.bevel_pen)
            except Exception: pass
        self.bevel_pen = None

    def cheat_pixel_state(self, x, y):
        """Source mouse-move branch after XYZZY: board mine bit -> desktop pixel color."""
        cell = self.board_at(x, y)
        if not cell or self.cheat_index < 5:
            return
        bx, by = cell
        mine = bool(self.board[by][bx] & 0x80)
        # The original uses SetPixel(0xffff,0xff) vs (0,0). We expose the
        # verified state for the native path; no alternate game rule is added.
        self._cheat_mine_under_cursor = mine

    # FUN_1000_1308
    def preview_move(self, x, y):
        new = self.board_at(x, y)
        nx, ny = new if new else (-1, -1)
        ox, oy = self.hover_x, self.hover_y
        if (nx, ny) == (ox, oy):
            return
        if not self.chord:
            if self.in_board(ox, oy) and not (self.board[oy][ox] & 0x40):
                self.cycle_mark_preview(ox, oy)
            if self.in_board(nx, ny):
                c = self.board[ny][nx]
                if not (c & 0x40) and (c & 0x1F) != FLAG:
                    self.normalize_mark(nx, ny)
        else:
            def around(cx, cy, fn):
                if not self.in_board(cx, cy): return
                for yy in range(max(1, cy-1), min(self.height, cy+1)+1):
                    for xx in range(max(1, cx-1), min(self.width, cx+1)+1):
                        if not (self.board[yy][xx] & 0x40): fn(xx, yy)
            around(ox, oy, lambda xx,yy: self.cycle_mark_preview(xx,yy))
            around(nx, ny, lambda xx,yy: self.normalize_mark(xx,yy))
        self.hover_x, self.hover_y = nx, ny
        self._invalidate()

    # FUN_1000_1651
    def activate_cell(self, x, y, chord=False):
        if not self.in_board(x, y) or self.finished: return
        cell = self.board[y][x]
        if self.revealed_safe == 0 and self.elapsed == 0 and not self.started:
            # FUN_1000_1651 increments DAT_0384 once immediately on the first
            # valid activation, before dispatching the open/chord operation.
            self.started = True
            self.elapsed = 1
            self.timer_subtick = 0
        elif not self.started:
            self.started = True
            self.timer_subtick = 0
        if (cell & 0x40) and not chord: return
        if not chord and (cell & 0x1F) == FLAG: return
        if chord: self.chord_cell(x, y)
        else: self.open_cell(x, y)

    # FUN_1000_0eb1 — WM_TIMER at 100 ms.
    def update_timer(self):
        if not self.started or self.finished: return
        # Source counts WM_TIMER messages, not wall-clock time. On every
        # tenth message DAT_0384 increments, then FUN_1000_1eaa obtains a
        # window DC and paints ONLY the timer digits. There is no InvalidateRect
        # in FUN_1000_0eb1, so the other GUI pixels must not be repainted here.
        if not self.started or self.finished or self._paused:
            return
        self.timer_subtick += 1
        if self.timer_subtick == 10:
            self.timer_subtick = 0
            if self.elapsed < 999:
                self.elapsed += 1
                self._draw_timer_now()

    # ---------------- native GUI ----------------
    def _create_window(self):
        if user32 is None: return
        self._wndproc = WNDPROC(self._window_proc_safe)
        wc = WNDCLASSEXW()
        wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
        wc.style = 0
        wc.lpfnWndProc = self._wndproc
        wc.cbClsExtra = wc.cbWndExtra = 0
        wc.hInstance = self.hinstance
        wc.hIcon = self._load_icon()
        wc.hCursor = user32.LoadCursorW(None, ctypes.c_void_p(32512))
        wc.hbrBackground = gdi32.GetStockObject(GRAY_BRUSH)
        wc.lpszMenuName = None
        wc.lpszClassName = self.class_name
        wc.hIconSm = wc.hIcon
        atom = user32.RegisterClassExW(ctypes.byref(wc))
        if not atom and ctypes.get_last_error() not in (1410,):
            raise ctypes.WinError(ctypes.get_last_error())
        self.menu = self._build_menu()
        style = 0x00CF0000  # WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX
        self.window_w = self.width * CELL + 0x2E
        self.window_h = self.height * CELL + 0x43
        rc = RECT(0, 0, self.window_w, self.window_h)
        user32.AdjustWindowRectEx(ctypes.byref(rc), style, True, 0)
        w = rc.right - rc.left; h = rc.bottom - rc.top
        self.hwnd = user32.CreateWindowExW(0, self.class_name, SOURCE_STRINGS[2],
                                           style, 100, 100, w, h, None, self.menu,
                                           self.hinstance, None)
        if not self.hwnd:
            raise ctypes.WinError(ctypes.get_last_error())
        self._load_sheets()
        self._create_bevel_pen()
        user32.SetTimer(self.hwnd, TIMER_ID, 100, None)
        user32.ShowWindow(self.hwnd, 1)
        user32.UpdateWindow(self.hwnd)
        self._sync_menu()

    def _load_icon(self):
        p = self.root / "assets" / "Icon_100.ico"
        return user32.LoadImageW(None, str(p), 1, 0, 0, LR_LOADFROMFILE)

    def _load_sheets(self):
        suffix = "410" if self.color_mode else "411"
        counter = "420" if self.color_mode else "421"
        face = "430" if self.color_mode else "431"
        self.cells = NativeBitmapSheet(self.root / "assets" / f"Card_Bitmap_{suffix}.png", 16, 16)
        self.counter = NativeBitmapSheet(self.root / "assets" / f"Card_Bitmap_{counter}.png", 13, 23)
        self.faces = NativeBitmapSheet(self.root / "assets" / f"Card_Bitmap_{face}.png", 24, 24)
        self.cell_mask = None
        self.counter_mask = None
        self.face_mask = None

    def _build_menu(self):
        # Recreate the original RT_MENU 500 text and separator ordering exactly.
        hmenu = user32.CreateMenu()
        game = user32.CreatePopupMenu(); helpm = user32.CreatePopupMenu()
        items = [
            (SOURCE_MENU["new"], IDM_NEW),
            (None, 0),
            (SOURCE_MENU["beginner"], IDM_BEGINNER),
            (SOURCE_MENU["intermediate"], IDM_INTERMEDIATE),
            (SOURCE_MENU["expert"], IDM_EXPERT),
            (SOURCE_MENU["custom"], IDM_CUSTOM),
            (None, 0),
            (SOURCE_MENU["mark"], IDM_MARK),
            (SOURCE_MENU["color"], IDM_COLOR),
            (None, 0),
            (SOURCE_MENU["best"], IDM_BEST),
            (None, 0),
            (SOURCE_MENU["quit"], IDM_QUIT),
        ]
        for text, cmd in items:
            if text is None:
                user32.AppendMenuW(game, MF_SEPARATOR, 0, None)
            else:
                user32.AppendMenuW(game, MF_STRING, cmd, text)
        help_items = [
            (SOURCE_MENU["help_contents"], IDM_HELP_CONTENTS),
            (SOURCE_MENU["help_search"], IDM_HELP_SEARCH),
            (SOURCE_MENU["help_how"], IDM_HELP_HOW),
            (None, 0),
            (SOURCE_MENU["about"], IDM_ABOUT),
        ]
        for text, cmd in help_items:
            if text is None:
                user32.AppendMenuW(helpm, MF_SEPARATOR, 0, None)
            else:
                user32.AppendMenuW(helpm, MF_STRING, cmd, text)
        user32.AppendMenuW(hmenu, MF_POPUP, game, SOURCE_MENU["game"])
        user32.AppendMenuW(hmenu, MF_POPUP, helpm, SOURCE_MENU["help"])
        return hmenu

    def _sync_menu(self):
        if not self.menu: return
        for cmd, selected in ((IDM_BEGINNER, self.preset_index == 0),
                              (IDM_INTERMEDIATE, self.preset_index == 1),
                              (IDM_EXPERT, self.preset_index == 2),
                              (IDM_MARK, self.mark_enabled),
                              (IDM_COLOR, self.color_mode)):
            user32.CheckMenuItem(self.menu, cmd, MF_CHECKED if selected else MF_UNCHECKED)
        # Source disables command 0x211 when the display reports <= 2 colors.
        user32.EnableMenuItem(self.menu, IDM_COLOR, 0 if self.color_supported else 0x0001)
        user32.DrawMenuBar(self.hwnd)

    def _invalidate(self):
        if getattr(self, "hwnd", None) and user32 is not None: user32.InvalidateRect(self.hwnd, None, False)

    def _client_rect(self):
        rc = RECT(); user32.GetClientRect(self.hwnd, ctypes.byref(rc)); return rc

    def board_at(self, x, y):
        bx = (x - BOARD_X) // CELL
        by = (y - BOARD_Y) // CELL
        return (bx, by) if self.in_board(bx, by) else None

    # FUN_1000_1c77 state -> bitmap frame: (state - 15) * -16.
    def cell_sprite(self, x, y):
        state = self.board[y][x] & 0x1F
        return max(0, min(15, 15 - state))

    # FUN_1000_1daa / 1d70
    def _draw_digits(self, hdc, value, x, y, negative_allowed=False):
        # IMPORTANT: FUN_1000_1d70 receives the digit value DIRECTLY as
        # param_3 and indexes the source offset table at param_3 * 2.
        # The shipped Card_Bitmap_420/421 sheets contain the source DIB frames
        # in bottom-up storage.  FUN_1000_1d70 uses source indices 0..9 for
        # digits 0..9, 10 for blank and 11 for minus.  The draw helper below
        # converts that source index to the visual GDI frame.
        v = int(value)
        if negative_allowed and v < 0:
            a = -v
            frames = [11, self._digit_frame((a // 10) % 10),
                      self._digit_frame(a % 10)]
        else:
            v = max(0, min(999, v))
            frames = [self._digit_frame(v // 100),
                      self._digit_frame((v // 10) % 10),
                      self._digit_frame(v % 10)]
        for i, frame in enumerate(frames):
            # frame is the source FUN_1000_1d70 index, not the visual
            # top-to-bottom index of the BMP loaded by LoadImageW.
            self.counter.draw_source_frame(hdc, frame, x + i * 13, y)

    @staticmethod
    def _digit_frame(digit):
        # FUN_1000_1d70 receives the numeric digit directly.  The source
        # offset table therefore uses 0..9 for digits 0..9; frame 10 is
        # blank and frame 11 is minus.
        d = int(digit)
        if 0 <= d <= 9:
            return d
        raise ValueError(f'unsupported source LED digit: {digit}')

    def _draw_counter(self, hdc):
        # FUN_1000_1daa uses x offsets 0x1c, 0x29, 0x36.
        v = self.mine_remaining
        self._draw_digits(hdc, v, 0x1c, 16, True)

    def _draw_counter_now(self):
        # FUN_1000_1e14: GetDC -> FUN_1000_1daa -> ReleaseDC.
        if not getattr(self, 'hwnd', None) or user32 is None:
            return
        hdc = user32.GetDC(self.hwnd)
        if not hdc:
            return
        try:
            self._draw_counter(hdc)
        finally:
            user32.ReleaseDC(self.hwnd, hdc)

    def _draw_timer(self, hdc, rc):
        # FUN_1000_1e3b: width - 0x43, width - 0x36, width - 0x29.
        # Digit values are passed directly to FUN_1000_1d70.
        self._draw_digits(hdc, self.elapsed, rc.right - 0x43, 16)

    def _draw_timer_now(self):
        # FUN_1000_1eaa: GetDC -> FUN_1000_1e3b -> ReleaseDC.
        if not getattr(self, 'hwnd', None) or user32 is None:
            return
        hdc = user32.GetDC(self.hwnd)
        if not hdc:
            return
        try:
            self._draw_timer(hdc, self._client_rect())
        finally:
            user32.ReleaseDC(self.hwnd, hdc)

    def _draw_face(self, hdc, rc):
        # Card_Bitmap_43x sprite sheet tile order (verified against the
        # shipped assets): 0=smile, 1=sunglasses/win, 2=dead/lose,
        # 3=surprised(O-mouth), 4=smile(face-button-pressed variant).
        # idx 1 and 3 were previously swapped, so winning showed the
        # "surprised" face and holding the mouse down on the board showed
        # the "sunglasses" (win) face instead of the surprised face.
        if self.finished and self.won: idx = 1
        elif self.finished: idx = 2
        elif self.press_face_button: idx = 4
        elif self.press_face: idx = 3
        else: idx = 0
        self.faces.draw(hdc, idx, (rc.right - 24)//2, 16)

    def _fill_rect(self, hdc, rect, color):
        brush = gdi32.CreateSolidBrush(color); old = gdi32.SelectObject(hdc, brush)
        user32.FillRect(hdc, ctypes.byref(rect), brush)
        gdi32.SelectObject(hdc, old); gdi32.DeleteObject(brush)

    def _create_bevel_pen(self):
        if self.bevel_pen:
            try: gdi32.DeleteObject(self.bevel_pen)
            except Exception: pass
        if self.color_mode:
            color = 0x00404040 if self.low_resolution else 0x00808080
            self.bevel_pen = gdi32.CreatePen(PS_SOLID, 1, color)
        else:
            self.bevel_pen = gdi32.GetStockObject(BLACK_PEN)

    def _frame_rect(self, hdc, l, t, r, b, raised=True, width=1, mode=None):
        # Exact control-flow transcription of FUN_1000_1f6b.  Source param7:
        # 0=recessed, 1=raised, 2=single bright bevel side.
        param6 = max(1, int(width))
        param2, param3, param4, param5 = int(t), int(l), int(b), int(r)
        mode = (1 if raised else 0) if mode is None else int(mode)
        # FUN_1000_1f3c
        if (mode & 1) == 0:
            gdi32.SetROP2(hdc, 0x0D)
            if self.bevel_pen:
                gdi32.SelectObject(hdc, self.bevel_pen)
        else:
            gdi32.SetROP2(hdc, 0x10)
        local4 = 0
        while local4 < param6:
            local4 += 1
            param5 -= 1
            gdi32.MoveToEx(hdc, param5, param2, None)
            gdi32.LineTo(hdc, param3, param2)
            gdi32.LineTo(hdc, param3, param4)
            param2 += 1; param3 += 1; param4 -= 1
        if mode < 2:
            other = mode ^ 1
            if (other & 1) == 0:
                gdi32.SetROP2(hdc, 0x0D)
                if self.bevel_pen:
                    gdi32.SelectObject(hdc, self.bevel_pen)
            else:
                gdi32.SetROP2(hdc, 0x10)
        # C evaluates iVar1=local_4+1 even on the failed condition, then
        # assigns local_4=iVar1. After the first pass local_4==param6,
        # therefore the second pass starts at param6+1 and draws param6
        # edges (decrement, test zero, then draw), not param6+1.
        local4 = param6 + 1
        while True:
            local4 -= 1
            if local4 == 0:
                break
            param5 += 1
            gdi32.MoveToEx(hdc, param5, param2, None)
            param4 += 1
            gdi32.LineTo(hdc, param5, param4)
            param3 -= 1
            gdi32.LineTo(hdc, param3, param4)
            param2 -= 1

    # FUN_1000_20d9 = frame + counter + face + timer + board.
    def paint(self, hdc):
        rc = self._client_rect()
        self._fill_rect(hdc, rc, 0x00C0C0C0)
        self._frame_rect(hdc, 0, 0, rc.right-1, rc.bottom-1, raised=True, width=3)
        # FUN_1000_201d exact logical regions.
        self._frame_rect(hdc, 0x14, 0x34, rc.right-0x15, rc.bottom-9, raised=False, width=3)
        self._frame_rect(hdc, 0x14, 9, rc.right-0x15, 0x2D, raised=False, width=2)
        self._frame_rect(hdc, 0x1B, 0x0F, 0x43, 0x27, raised=False, width=1)
        self._frame_rect(hdc, rc.right-0x44, 0x0F, rc.right-0x1C, 0x27, raised=False, width=1)
        face_x = (rc.right - 24) // 2 - 1
        # The face button is raised at rest and during board presses. It is
        # recessed only while the pointer is pressed inside the face button;
        # press_face also tracks whether the captured pointer remains inside.
        face_button_pressed_inside = bool(self.press_face_button and self.press_face)
        self._frame_rect(
            hdc, face_x, 0x0F, face_x + 0x19, 0x28,
            raised=not face_button_pressed_inside, width=1,
        )
        self._draw_counter(hdc); self._draw_face(hdc, rc); self._draw_timer(hdc, rc)
        for y in range(1, self.height+1):
            for x in range(1, self.width+1):
                self.cells.draw(hdc, self.cell_sprite(x, y),
                                BOARD_X + x*CELL, BOARD_Y + y*CELL)

    def _command(self, cmd):
        if cmd == IDM_NEW: self.new_game()
        elif cmd in (IDM_BEGINNER, IDM_INTERMEDIATE, IDM_EXPERT):
            self.preset_index = cmd - IDM_BEGINNER
            p = PRESETS[self.preset_index]
            self.width, self.height, self.mine_total = p.width, p.height, p.mines
            self._resize_native(); self.new_game(); self._sync_menu()
        elif cmd == IDM_MARK:
            self.mark_enabled = not self.mark_enabled; self._sync_menu()
        elif cmd == IDM_COLOR:
            # 0x211 is the source Color command (DAT_026c), not Sound.
            if not self.color_supported:
                return
            # FUN_1000_1a32 rebuilds the source DIB/pen state after the toggle.
            self.color_mode = not self.color_mode
            self._rebuild_palette_mode()
            self._sync_menu(); self._invalidate()
        elif cmd == IDM_QUIT: self.running = False; user32.DestroyWindow(self.hwnd)
        elif cmd == IDM_CUSTOM: self.custom_dialog()
        elif cmd == IDM_BEST: self.show_best()
        elif cmd == IDM_HELP_CONTENTS: self.show_help()
        elif cmd == IDM_HELP_SEARCH: self.show_help_search()
        elif cmd == IDM_HELP_HOW: self.show_help_how()
        elif cmd == IDM_ABOUT: self.show_about()

    def _resize_native(self):
        if not self.hwnd: return
        self.window_w = self.width*16 + 0x2E; self.window_h = self.height*16 + 0x43
        style = 0x00CF0000
        rc = RECT(0,0,self.window_w,self.window_h)
        user32.AdjustWindowRectEx(ctypes.byref(rc), style, True, 0)
        user32.SetWindowPos(self.hwnd, None, 0,0, rc.right-rc.left, rc.bottom-rc.top, 0x0002|0x0004)

    def _dialog_template(self, title, fields, buttons=(IDOK, IDCANCEL), size=(210, 105)):
        # A source-shaped Win16 dialog recreated from the exact control IDs and
        # validation logic in PREFDLGPROC/BESTDLGPROC/ENTERDLGPROC.  The original
        # NE resource template itself cannot be passed to 64-bit USER32.
        import struct
        b = bytearray()
        def w(v): b.extend(struct.pack("<H", v & 0xFFFF))
        def d(v): b.extend(struct.pack("<I", v & 0xFFFFFFFF))
        def align():
            while len(b) & 3: b.append(0)
        # DS_SETFONT must be set whenever the template body is followed by a
        # pointsize/typeface pair (it is, below), otherwise USER32 misparses
        # the template and DialogBoxIndirectParamW silently fails to create
        # the window (root cause of the "自定項目" dialog not responding).
        style = DS_MODALFRAME | DS_SETFONT | WS_POPUP | WS_CAPTION | WS_SYSMENU
        d(style); d(0); w(len(fields) * 2 + 1); w(10); w(10); w(size[0]); w(size[1])
        w(0); w(0)
        for ch in title: w(ord(ch))
        w(0); w(8)
        for ch in "MS Sans Serif": w(ord(ch))
        w(0)
        cid = 0
        for label, edit_id, value in fields:
            align(); d(SS_LEFT | WS_CHILD | WS_VISIBLE); d(0); w(5); w(10 + cid*22); w(55); w(12); w(0x1000 + cid)
            w(0xFFFF); w(0x0082)
            for ch in label: w(ord(ch))
            w(0)
            align(); d(WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL | ES_NUMBER); d(0); w(65); w(8 + cid*22); w(55); w(14); w(edit_id)
            w(0xFFFF); w(0x0081); w(0); w(0)
            cid += 1
        align(); d(WS_CHILD | WS_VISIBLE | WS_TABSTOP | (BS_DEFPUSHBUTTON if buttons[0] == IDOK else 0)); d(0); w(45); w(size[1]-25); w(50); w(14); w(buttons[0]); w(0xFFFF); w(0x0080)
        for ch in "OK": w(ord(ch))
        w(0)
        return (ctypes.c_ubyte * len(b)).from_buffer_copy(bytes(b))

    def _run_simple_dialog(self, title, fields, validator):
        result = {"accepted": False}
        ids = [f[1] for f in fields]
        template = self._dialog_template(title, fields)
        WND = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_void_p, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
        def proc(hwnd, msg, wp, lp):
            if msg == WM_INITDIALOG:
                for label, eid, value in fields:
                    user32.SetDlgItemInt(hwnd, eid, int(value), True)
                return 1
            if msg == WM_COMMAND:
                cid = _lo_word(wp)
                if cid == IDOK:
                    vals=[]
                    for eid in ids:
                        ok = wintypes.BOOL()
                        vals.append(int(user32.GetDlgItemInt(hwnd, eid, ctypes.byref(ok), True)))
                    normalized = validator(vals)
                    if normalized is not None:
                        result["accepted"] = True; result["values"] = normalized
                        user32.EndDialog(hwnd, IDOK)
                    else:
                        user32.MessageBoxW(hwnd, "請輸入有效的高度、寬度及地雷數。", title, 0x00000030)
                    return 1
                if cid == IDCANCEL:
                    user32.EndDialog(hwnd, IDCANCEL); return 1
            return 0
        cb = WND(proc)
        self._dialog_proc_keepalive = cb
        user32.DialogBoxIndirectParamW(self.hinstance, ctypes.byref(template), self.hwnd, cb, 0)
        self._dialog_proc_keepalive = None
        return result

    def custom_dialog(self):
        # Exact PREFDLGPROC / FUN_1000_1973 behavior:
        # height is clamped to [8, 16] when DAT_07AA == 0, otherwise [8, 22];
        # width to [8, 30]; mines to [10, min(999, (height-1)*(width-1))].
        # The native dialog clamps values; it does not reject ordinary
        # out-of-range integers with a Python-only validation message.
        max_height = 16 if getattr(self, "low_resolution", False) else 22
        def valid(v):
            if len(v) != 3: return None
            h = max(8, min(max_height, int(v[0])))
            w = max(8, min(30, int(v[1])))
            mine_max = min(999, (h - 1) * (w - 1))
            m = max(10, min(mine_max, int(v[2])))
            return [h, w, m]
        fields = [("高度(&H):", 0x8d, self.height), ("寬度(&W):", 0x8e, self.width), ("地雷(&M):", 0x8f, self.mine_total)]
        result = self._run_simple_dialog("自定項目", fields, valid)
        if result.get("accepted"):
            self.height, self.width, self.mine_total = result["values"]
            self.preset_index = 3
            self.custom = True
            self._resize_native()
            self._sync_menu()
            self.new_game()

    def _run_text_dialog(self, title, initial, prompt):
        import struct
        b=bytearray()
        def w(v): b.extend(struct.pack("<H", v & 0xFFFF))
        def d(v): b.extend(struct.pack("<I", v & 0xFFFFFFFF))
        def align():
            while len(b)&3: b.append(0)
        # DS_SETFONT required to match the pointsize/typeface block written
        # below (see _dialog_template for why its absence breaks the dialog).
        style=DS_MODALFRAME|DS_SETFONT|WS_POPUP|WS_CAPTION|WS_SYSMENU
        d(style); d(0); w(3); w(10); w(10); w(220); w(90); w(0); w(0)
        for ch in title: w(ord(ch))
        w(0); w(8)
        for ch in "MS Sans Serif": w(ord(ch))
        w(0)
        # static label
        align(); d(SS_LEFT|WS_CHILD|WS_VISIBLE); d(0); w(8); w(12); w(200); w(14); w(1001); w(0xFFFF); w(0x0082)
        for ch in prompt: w(ord(ch))
        w(0)
        # edit
        align(); d(WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL); d(0); w(8); w(28); w(200); w(14); w(1002); w(0xFFFF); w(0x0081); w(0); w(0)
        # OK
        align(); d(WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_DEFPUSHBUTTON); d(0); w(75); w(52); w(55); w(14); w(IDOK); w(0xFFFF); w(0x0080)
        for ch in "OK": w(ord(ch))
        w(0)
        tpl=(ctypes.c_ubyte*len(b)).from_buffer_copy(bytes(b)); result={}
        DLG=ctypes.WINFUNCTYPE(ctypes.c_ssize_t,ctypes.c_void_p,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM)
        def proc(hwnd,msg,wp,lp):
            if msg==WM_INITDIALOG:
                user32.SetDlgItemTextW(hwnd,1002,initial)
                return 1
            if msg==WM_COMMAND:
                cid=_lo_word(wp)
                if cid==IDOK:
                    buf=ctypes.create_unicode_buffer(128); user32.GetDlgItemTextW(hwnd,1002,buf,128)
                    result['accepted']=True; result['text']=buf.value
                    user32.EndDialog(hwnd,IDOK); return 1
                if cid==IDCANCEL:
                    user32.EndDialog(hwnd,IDCANCEL); return 1
            return 0
        cb=DLG(proc); self._dialog_proc_keepalive=cb
        # MAINWNDPROC command 0x210 -> FUN_1000_0440 -> DIALOGBOX resource 700.
        # Keep the callback alive for the full modal call and record a native
        # creation failure rather than silently treating it as a successful UI.
        try:
            dialog_result = user32.DialogBoxIndirectParamW(
                self.hinstance, ctypes.byref(tpl), self.hwnd, cb, 0
            )
            if dialog_result == -1:
                try:
                    (self.root / "winmine_gui_error.log").open("a", encoding="utf-8").write(
                        "DialogBoxIndirectParamW failed for source BEST dialog resource 700\n"
                    )
                except Exception:
                    pass
        finally:
            self._dialog_proc_keepalive=None
        return result

    def show_best(self):
        # Source BESTDLGPROC (dialog resource 600) displays three records and
        # handles command 0x309 by resetting all three times/names to the
        # resource defaults.  Rebuild the modal layout with the same logical
        # controls/command because the original 16-bit dialog template cannot
        # be instantiated by 64-bit USER32.
        import struct
        b = bytearray()
        def w(v): b.extend(struct.pack("<H", v & 0xFFFF))
        def d(v): b.extend(struct.pack("<I", v & 0xFFFFFFFF))
        def align():
            while len(b) & 3: b.append(0)
        # DS_SETFONT required to match the pointsize/typeface block written
        # below; without it USER32 misparses the template and the "最快
        # 時間" dialog never appears (DialogBoxIndirectParamW fails silently).
        style = DS_MODALFRAME | DS_SETFONT | WS_POPUP | WS_CAPTION | WS_SYSMENU
        # 3 rows x (label, time, name) + OK + reset = 11 controls.
        # cdit must match the number of item templates or USER32 rejects it.
        d(style); d(0); w(11); w(10); w(10); w(250); w(112); w(0); w(0)
        for ch in "最快速的掃雷者": w(ord(ch))
        w(0); w(8)
        for ch in "MS Sans Serif": w(ord(ch))
        w(0)
        rows = ((0x2bd, 0x274, "初學者"), (0x2bf, 0x2b4, "中級者"), (0x2c1, 0x2f4, "進階者"))
        for i, (time_id, name_id, label) in enumerate(rows):
            y = 10 + i * 22
            align(); d(SS_LEFT|WS_CHILD|WS_VISIBLE); d(0); w(8); w(y); w(70); w(14); w(3000+i); w(0xFFFF); w(0x0082)
            for ch in label: w(ord(ch))
            w(0); w(0)  # item title terminator + zero creation-data size
            align(); d(SS_LEFT|WS_CHILD|WS_VISIBLE); d(0); w(80); w(y); w(45); w(14); w(time_id); w(0xFFFF); w(0x0082)
            w(0); w(0)  # item title terminator + zero creation-data size
            align(); d(SS_LEFT|WS_CHILD|WS_VISIBLE); d(0); w(130); w(y); w(105); w(14); w(name_id); w(0xFFFF); w(0x0082)
            w(0); w(0)  # item title terminator + zero creation-data size
        align(); d(WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_DEFPUSHBUTTON); d(0); w(95); w(80); w(55); w(16); w(IDOK); w(0xFFFF); w(0x0080)
        for ch in "確定": w(ord(ch))
        w(0); w(0)  # item title terminator + zero creation-data size
        align(); d(WS_CHILD|WS_VISIBLE|WS_TABSTOP); d(0); w(155); w(80); w(70); w(16); w(0x309); w(0xFFFF); w(0x0080)
        for ch in "重新計分(&R)": w(ord(ch))
        w(0); w(0)  # item title terminator + zero creation-data size
        tpl = (ctypes.c_ubyte * len(b)).from_buffer_copy(bytes(b))
        result = {}
        DLG = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_void_p, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
        def reset_best():
            # FUN_1000_0b25: all three times=999 and names copy resource
            # string 0x418.  The NE string resource is not plain UTF-16 in
            # this executable, so the exact default text remains resource-
            # extraction work rather than an invented literal.
            self.best[:] = [999, 999, 999]
            self.best_names[:] = ["", "", ""]
        def proc(hwnd, msg, wp, lp):
            if msg == WM_INITDIALOG:
                labels = ("初學者", "中級者", "進階者")
                for i, (time_id, name_id, label) in enumerate(rows):
                    user32.SetDlgItemTextW(hwnd, time_id, f"{self.best[i]:03d}")
                    user32.SetDlgItemTextW(hwnd, name_id, self.best_names[i])
                return 1
            if msg == WM_COMMAND:
                cid = _lo_word(wp)
                if cid == 0x309:
                    reset_best()
                    for time_id, name_id, label in rows:
                        user32.SetDlgItemTextW(hwnd, time_id, "999")
                        user32.SetDlgItemTextW(hwnd, name_id, "")
                    # BESTDLGPROC sets DAT_00b6 after resetting; the Python
                    # equivalent must persist the changed records as well.
                    self.save_preferences()
                    return 1
                if cid in (IDOK, IDCANCEL, 100, 0x6d):
                    result['accepted'] = True
                    user32.EndDialog(hwnd, IDOK)
                    return 1
            return 0
        cb = DLG(proc); self._dialog_proc_keepalive = cb
        try:
            dialog_result = user32.DialogBoxIndirectParamW(
                self.hinstance, ctypes.byref(tpl), self.hwnd, cb, 0
            )
            if dialog_result == -1:
                # Do not silently swallow the native failure: source command
                # 0x210 opens dialog resource 700 via FUN_1000_0440.
                try:
                    with (self.root / "winmine_gui_error.log").open("a", encoding="utf-8") as log:
                        log.write(f"DialogBoxIndirectParamW failed for source BEST dialog resource 700; GetLastError={ctypes.get_last_error()}\n")
                except Exception:
                    pass
                try:
                    user32.MessageBoxW(self.hwnd,
                        "無法建立「最快時間」對話框。請查看 winmine_gui_error.log。",
                        "WinMine", 0x00000010)
                except Exception:
                    pass
        finally:
            self._dialog_proc_keepalive = None

    def show_name_entry(self):
        idx=self.preset_index
        if not (0 <= idx < 3): return
        result=self._run_text_dialog("", self.best_names[idx], SOURCE_STRINGS[9 + idx])
        if result.get("accepted"):
            self.best_names[idx]=result.get("text","")[:127]

    def show_help(self):
        # The original command dispatches to WINMINE.HLP.  Use the shipped
        # original help file rather than inventing replacement help content.
        help_path = self.root / "source" / "WINMINE.HLP"
        if help_path.exists():
            try:
                user32.WinHelpW(self.hwnd, str(help_path), 0x0003, 0)
                return
            except Exception:
                pass
        self.show_about_message("原版輔助說明檔：WINMINE.HLP")

    def show_help_search(self):
        help_path = self.root / "source" / "WINMINE.HLP"
        if help_path.exists():
            try:
                # Source FUN_1000_1933 uses HELP_PARTIALKEY (0x105) with a
                # string resource. The shipped HLP is the authoritative help
                # corpus; the modern call keeps the same WinHelp mechanism.
                user32.WinHelpW(self.hwnd, str(help_path), 0x0105, SOURCE_STRINGS[2])
                return
            except Exception:
                pass
        self.show_about_message("原版輔助說明檔：WINMINE.HLP")

    def show_help_how(self):
        help_path = self.root / "source" / "WINMINE.HLP"
        if help_path.exists():
            try:
                user32.WinHelpW(self.hwnd, str(help_path), 0x0004, 0)
                return
            except Exception:
                pass
        self.show_about_message("原版輔助說明檔：WINMINE.HLP")

    def show_about(self):
        self.show_about_message(SOURCE_STRINGS[13] + "\n" + SOURCE_STRINGS[14])

    def show_about_message(self, text):
        user32.MessageBoxW(self.hwnd, text, "WinMine", 0x40)

    def _window_proc_safe(self, hwnd, msg, wparam, lparam):
        try:
            if msg == WM_COMMAND:
                # Source MAINWNDPROC dispatches menu command 0x210 to
                # FUN_1000_0440. Record the actual native command so a
                # Windows run can distinguish menu routing from dialog failure.
                try:
                    with (self.root / "winmine_gui_error.log").open("a", encoding="utf-8") as f:
                        f.write(f"WM_COMMAND id=0x{_lo_word(wparam):04X} notify=0x{(int(wparam) >> 16) & 0xFFFF:04X}\n")
                except Exception:
                    pass
            return self._window_proc(hwnd, msg, wparam, lparam)
        except Exception as exc:
            # A callback exception must never unwind through USER32.  The
            # previous build could silently abort WM_PAINT and leave an
            # apparently empty window.  Keep the native message path alive
            # and persist the exact Python exception for diagnosis.
            try:
                log = self.root / "winmine_gui_error.log"
                with log.open("a", encoding="utf-8") as f:
                    f.write(f"msg=0x{int(msg):04X} error={exc!r}\n")
            except Exception:
                pass
            return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def _window_proc(self, hwnd, msg, wparam, lparam):
        if msg == WM_ERASEBKGND: return 1
        if msg == WM_PAINT:
            ps = PAINTSTRUCT(); hdc = user32.BeginPaint(hwnd, ctypes.byref(ps))
            self.paint(hdc); user32.EndPaint(hwnd, ctypes.byref(ps)); return 0
        if msg == WM_TIMER and wparam == TIMER_ID:
            self.update_timer(); return 0
        if msg == WM_COMMAND:
            self._command(_lo_word(wparam)); return 0
        if msg == WM_MOUSEACTIVATE:
            if _lo_word(wparam) == 2:
                self._eat_next_click = True
            return 0
        # Source MAINWNDPROC WM_ACTIVATE: state==2 arms one-click suppression.
        if msg == WM_ACTIVATE:
            if _lo_word(wparam) == 2:
                self._eat_next_click = True
            return user32.DefWindowProcW(hwnd, msg, wparam, lparam)
        # Source uses WM_ENTERIDLE/WM_MENURBUTTONUP as a small menu-state
        # latch (DAT_0018). Preserve that state even though it is not part of
        # the board rules.
        if msg == 0x0211:
            self._menu_mouse_state = 1
            return user32.DefWindowProcW(hwnd, msg, wparam, lparam)
        if msg == 0x0212:
            self._menu_mouse_state = 0
            return user32.DefWindowProcW(hwnd, msg, wparam, lparam)
        if msg == WM_SYSCOMMAND:
            sc = int(wparam) & 0xFFF0
            if sc == 0xF020:
                if self.started and not self.finished:
                    self._paused = True
                user32.ShowWindow(hwnd, 6)
                return 0
            if sc == 0xF120:
                user32.ShowWindow(hwnd, 9)
                if getattr(self, "_paused", False):
                    self._paused = False
                return 0
        if msg == WM_SIZE:
            # Source WM_SIZE stores the new client extents as +1 values.
            self.client_w = _lo_word(lparam) + 1
            self.client_h = _hi_word(lparam) + 1
            return 0
        if msg == WM_MOVE:
            return 0
        if msg == WM_KEYDOWN:
            self.handle_key_source(wparam)
            if wparam == VK_F2: self.new_game()
            elif wparam == VK_ESCAPE:
                user32.PostMessageW(hwnd, WM_SYSCOMMAND, 0xF020, 0)
            return 0
        if msg == WM_LBUTTONDOWN:
            if getattr(self, "_eat_next_click", False):
                self._eat_next_click = False
                return 0
            x, y = _signed16(_lo_word(lparam)), _signed16(_hi_word(lparam))
            fx = (self._client_rect().right-24)//2
            if fx <= x < fx+24 and 16 <= y < 40:
                self.press_face = self.press_face_button = True; self._invalidate(); user32.SetCapture(hwnd); return 0
            # Source bit 0 of DAT_0016 means the game is active. After finish
            # FUN_1000_2182 clears that bit, board capture must not start.
            cell = self.board_at(x,y)
            if cell and not self.finished:
                self.left_down = True; self.chord = bool(wparam & 0x0006); self.press_face = True
                self.hover_x = self.hover_y = -1
                self.preview_move(x, y)
                user32.SetCapture(hwnd); self._invalidate()
            return 0
        if msg == WM_MOUSEMOVE:
            x, y = _signed16(_lo_word(lparam)), _signed16(_hi_word(lparam))
            self._last_mouse = (x, y)
            # Source cheat path: after XYZZY, the fifth-key state is only
            # activated by a mouse move carrying MK_SHIFT (bit 3); once the
            # state advances beyond five, subsequent moves remain active.
            if self.cheat_index == 5 and not (int(wparam) & 0x0004):
                pass
            elif self.cheat_index >= 5 and not self.left_down:
                self.cheat_pixel_state(x, y)
            if self.press_face_button:
                rc = self._client_rect()
                fx = (rc.right - 24) // 2
                inside = fx <= x < fx + 24 and 16 <= y < 40
                if inside != self.press_face:
                    self.press_face = inside
                    self._invalidate()
            elif self.left_down:
                self.preview_move(x, y)
            return 0
        if msg == WM_LBUTTONUP:
            x, y = _signed16(_lo_word(lparam)), _signed16(_hi_word(lparam))
            if self.press_face_button:
                fx = (self._client_rect().right-24)//2
                if fx <= x < fx+24 and 16 <= y < 40: self.new_game()
            elif self.left_down:
                cell = self.board_at(x,y)
                if cell: self.activate_cell(*cell, chord=self.chord)
            self.left_down = self.chord = self.press_face = self.press_face_button = False
            self.hover_x = self.hover_y = -1
            user32.ReleaseCapture(); self._invalidate(); return 0
        if msg == WM_RBUTTONDOWN:
            if getattr(self, "_eat_next_click", False):
                self._eat_next_click = False
                return 0
            x, y = _signed16(_lo_word(lparam)), _signed16(_hi_word(lparam))
            # Source: right-button during an active left drag switches to
            # chord mode and posts the corresponding mouse-move. Without an
            # active drag, a plain right click marks; with the source modifier
            # bit set it enters the same chord path as the middle button.
            if self.left_down:
                self.preview_move(-1, -1)
                self.chord = True
                return 0
            if int(wparam) & 0x0001:
                cell = self.board_at(x, y)
                if cell:
                    self.left_down = True
                    self.chord = True
                    self.hover_x = self.hover_y = -1
                    self.preview_move(x, y)
                    user32.SetCapture(hwnd)
                return 0
            # Source checks DAT_0016 bit 0 (active game), not the Menu setting.
            if not self.finished:
                cell = self.board_at(x, y)
                if cell: self.toggle_mark(*cell)
            return 0
        if msg == WM_MBUTTONDOWN:
            if getattr(self, "_eat_next_click", False):
                self._eat_next_click = False
                return 0
            # Source middle-button path is gated by DAT_0016 bit 0 (active game),
            # not by the Menu preference.
            if self.finished:
                return 0
            x, y = _signed16(_lo_word(lparam)), _signed16(_hi_word(lparam))
            cell = self.board_at(x, y)
            if cell:
                self.left_down = True
                self.chord = True
                self.hover_x = self.hover_y = -1
                self.preview_move(x, y)
                user32.SetCapture(hwnd)
            return 0
        if msg in (WM_RBUTTONUP, WM_MBUTTONUP):
            # Source only commits the captured board action on the button-up
            # path; a standalone right click has already completed marking.
            if self.left_down and self.chord:
                x, y = _signed16(_lo_word(lparam)), _signed16(_hi_word(lparam))
                cell = self.board_at(x, y)
                self.left_down = False
                self.chord = False
                self.hover_x = self.hover_y = -1
                user32.ReleaseCapture()
                if cell:
                    self.activate_cell(*cell, chord=True)
                self._invalidate()
                return 0
            return 0
        if msg == WM_ENDSESSION:
            self.save_preferences()
            return 0
        if msg == WM_CLOSE:
            user32.DestroyWindow(hwnd); return 0
        if msg == WM_DESTROY:
            if self.hwnd:
                user32.KillTimer(hwnd, TIMER_ID)
            self.save_preferences(); self.running = False; user32.PostQuitMessage(0); return 0
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def run(self):
        msg = MSG()
        while self.running:
            r = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
            if r <= 0: break
            user32.TranslateMessage(ctypes.byref(msg)); user32.DispatchMessageW(ctypes.byref(msg))

    def close_for_test(self):
        for obj in (getattr(self, "cells", None), getattr(self, "counter", None), getattr(self, "faces", None)):
            if obj: obj.close()


class MSG(ctypes.Structure):
    _fields_ = [("hwnd", wintypes.HWND), ("message", wintypes.UINT),
                ("wParam", wintypes.WPARAM), ("lParam", wintypes.LPARAM),
                ("time", wintypes.DWORD), ("pt", POINT), ("lPrivate", wintypes.DWORD)]


def _ini_text(cfg):
    import io
    s = io.StringIO(); cfg.write(s); return s.getvalue()


def main():
    root = Path(__file__).resolve().parent
    game = WinMineGame(root)
    game.run()


if __name__ == "__main__":
    main()
