# -*- coding: utf-8 -*-
"""
dialogs.py
----------
對應原本 .rc 裡的幾個對話框，並且「比照原版」還原每個控制項在對話框
裡的實際座標／大小／排列順序（原始座標單位是 Win32 Dialog Unit，
換算方式沿用 Windows 官方作法：以對話框字型的平均字元寬度、字高當
基準，橫向 4 DLU = 1 個平均字元寬，縱向 8 DLU = 1 個字高）：

  103 關於 (About)      -> dialog.rc: DIALOG 22, 17, 134, 118
  144 狀態 (Status)      -> dialog.rc: DIALOGEX 0, 0, 342, 139
  146 物品 (Items)       -> dialog.rc: DIALOG 0, 0, 102, 105
  157 設定 (Settings)    -> dialog.rc: DIALOG 0, 0, 122, 159
  159 恭喜 / 作弊 (Secret cheat dialog，原本用滑鼠事件觸發，這裡改成
       在「關於」對話框的圖示上連點兩下觸發，保留原本「藏起來的
       彩蛋」精神——這點跟原程式 sub_405EF0 的行為一致)
"""
import string
import webbrowser

import tkinter as tk
from tkinter import ttk
import tkinter.font as tkfont

import sprites as sprites_mod

# 原始 .rc 裡 FONT 9, "新細明體"（PMingLiU）；找不到就讓 tkinter 自動
# 換成系統上可用的字型，不影響版面換算（換算時一律用「實際套用到的
# 字型」量測平均字寬／字高，所以外觀比例仍然會維持一致）。
DIALOG_FONT_FAMILY = "PMingLiU"
DIALOG_FONT_SIZE = 9
ABOUT_URL = "https://game76420.github.io/"


class DluConverter:
    """把 .rc 裡的 Dialog Unit 座標換算成實際像素，公式跟 Win32 的
    MapDialogRect 一樣：
        baseUnitX = 對話框字型英文字母（A-Z a-z）的平均字寬
        baseUnitY = 對話框字型的行高
        px_x = dlu_x * baseUnitX / 4
        px_y = dlu_y * baseUnitY / 8
    """

    def __init__(self, root, family=DIALOG_FONT_FAMILY, size=DIALOG_FONT_SIZE):
        try:
            self.font = tkfont.Font(root=root, family=family, size=size)
        except tk.TclError:
            self.font = tkfont.nametofont("TkDefaultFont")
        chars = string.ascii_letters
        self.base_x = self.font.measure(chars) / len(chars)
        self.base_y = self.font.metrics("linespace")

    def x(self, dlu):
        return round(dlu * self.base_x / 4)

    def y(self, dlu):
        return round(dlu * self.base_y / 8)


def _center_on_parent(win, parent):
    """把對話框擺在精靈（parent）右下方一點的位置，但如果精靈在螢幕
    邊緣或底部，導致對話框整個或部份跑出螢幕範圍，就自動改擺到另一側
    （左/上），必要時再夾回螢幕可視範圍內，確保視窗一定完整可見。"""
    win.update_idletasks()
    px, py = parent.winfo_x(), parent.winfo_y()
    pw = parent.winfo_width()
    ph = parent.winfo_height()
    w = win.winfo_width()
    h = win.winfo_height()

    margin = 10
    sw = win.winfo_screenwidth()
    sh = win.winfo_screenheight()

    offset = 40
    x = px + offset
    # 右邊放不下就改放到精靈左側
    if x + w > sw - margin:
        x = px - w - offset + pw
    y = py + offset
    # 下面放不下（例如精靈在螢幕底部）就改放到精靈上方
    if y + h > sh - margin:
        y = py - h - offset + ph

    # 最後再夾一次，避免精靈本身太靠邊時，翻轉後還是超出螢幕
    x = max(margin, min(x, sw - w - margin))
    y = max(margin, min(y, sh - h - margin))

    win.geometry(f"+{x}+{y}")


class _RcDialog(tk.Toplevel):
    """對應 .rc DIALOG／DIALOGEX 區塊的基底類別：用絕對座標 place()
    來還原原本每個 CONTROL 的位置與大小，而不是用 pack/grid 重排。"""

    def __init__(self, master, caption, dlu_w, dlu_h):
        super().__init__(master)
        self.title(caption)
        self.transient(master)
        self.resizable(False, False)
        self.dlu = DluConverter(self)
        self._placed_widgets = []
        self._parent_for_centering = master
        self._screen_margin = 24
        # .rc 裡的 dialog size 是「客戶區」大小，四周留一點邊界比較好看，
        # 跟原版 Win32 對話框的內距感覺一致。
        pad = 6
        self._pad = pad
        self._design_w = self.dlu.x(dlu_w) + pad * 2
        self._design_h = self.dlu.y(dlu_h) + pad * 2

        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.shell = ttk.Frame(self)
        self.shell.grid(row=0, column=0, sticky="nsew")
        self.shell.columnconfigure(0, weight=1)
        self.shell.rowconfigure(0, weight=1)

        self.canvas = tk.Canvas(self.shell, highlightthickness=0, borderwidth=0)
        self.v_scroll = ttk.Scrollbar(self.shell, orient="vertical", command=self.canvas.yview)
        self.h_scroll = ttk.Scrollbar(self.shell, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(
            xscrollcommand=self.h_scroll.set,
            yscrollcommand=self.v_scroll.set,
            width=self._design_w,
            height=self._design_h,
        )
        self.canvas.grid(row=0, column=0, sticky="nsew")

        self.body = tk.Frame(self.canvas, width=self._design_w, height=self._design_h)
        self.body.pack_propagate(False)
        self._body_window = self.canvas.create_window(
            (0, 0),
            anchor="nw",
            window=self.body,
            width=self._design_w,
            height=self._design_h,
        )
        self.canvas.configure(scrollregion=(0, 0, self._design_w, self._design_h))

    def put(self, widget, x, y, w=None, h=None):
        """依 .rc 座標（DLU）擺放控制項，(x, y) 為左上角。"""
        px_x, px_y = self.dlu.x(x) + self._pad, self.dlu.y(y) + self._pad
        kwargs = {"x": px_x, "y": px_y}
        px_w = self.dlu.x(w) if w is not None else None
        px_h = self.dlu.y(h) if h is not None else None
        if w is not None:
            kwargs["width"] = px_w
        if h is not None:
            kwargs["height"] = px_h
        widget.place(**kwargs)
        self._placed_widgets.append(
            {
                "widget": widget,
                "x": px_x,
                "y": px_y,
                "width": px_w,
                "height": px_h,
            }
        )
        return widget

    def finalize_dialog(self, parent=None):
        if parent is not None:
            self._parent_for_centering = parent
        self.refresh_layout(recenter=True)

    def refresh_layout(self, recenter=False):
        self._fit_to_contents()
        if recenter and self._parent_for_centering is not None:
            _center_on_parent(self, self._parent_for_centering)

    def _fit_to_contents(self):
        self.update_idletasks()
        self._expand_widgets_to_fit()
        self.update_idletasks()

        content_w, content_h = self._measure_content_size()
        self.body.config(width=content_w, height=content_h)
        self.canvas.itemconfigure(self._body_window, width=content_w, height=content_h)
        self.canvas.configure(scrollregion=(0, 0, content_w, content_h))
        self._apply_window_size(content_w, content_h)

    def _expand_widgets_to_fit(self):
        for meta in self._placed_widgets:
            widget = meta["widget"]
            if not widget.winfo_exists():
                continue
            req_w = widget.winfo_reqwidth()
            req_h = widget.winfo_reqheight()
            place_kwargs = {}
            if meta["width"] is not None and req_w > meta["width"]:
                meta["width"] = req_w
                place_kwargs["width"] = req_w
            if meta["height"] is not None and req_h > meta["height"]:
                meta["height"] = req_h
                place_kwargs["height"] = req_h
            if place_kwargs:
                widget.place_configure(**place_kwargs)

    def _measure_content_size(self):
        max_right = self._design_w
        max_bottom = self._design_h
        for meta in self._placed_widgets:
            widget = meta["widget"]
            if not widget.winfo_exists():
                continue
            width = meta["width"] if meta["width"] is not None else widget.winfo_reqwidth()
            height = meta["height"] if meta["height"] is not None else widget.winfo_reqheight()
            max_right = max(max_right, meta["x"] + width + self._pad)
            max_bottom = max(max_bottom, meta["y"] + height + self._pad)
        return max_right, max_bottom

    def _apply_window_size(self, content_w, content_h):
        self.update_idletasks()
        extra_w = max(0, self.winfo_reqwidth() - self.canvas.winfo_width())
        extra_h = max(0, self.winfo_reqheight() - self.canvas.winfo_height())
        max_total_w = max(260, self.winfo_screenwidth() - self._screen_margin * 2)
        max_total_h = max(220, self.winfo_screenheight() - self._screen_margin * 2)
        max_canvas_w = max(140, max_total_w - extra_w)
        max_canvas_h = max(140, max_total_h - extra_h)
        vbar_w = self.v_scroll.winfo_reqwidth()
        hbar_h = self.h_scroll.winfo_reqheight()

        show_v = False
        show_h = False
        for _ in range(3):
            canvas_w = max(140, min(content_w, max_canvas_w - (vbar_w if show_v else 0)))
            canvas_h = max(140, min(content_h, max_canvas_h - (hbar_h if show_h else 0)))
            new_show_v = content_h > canvas_h
            new_show_h = content_w > canvas_w
            if (new_show_v, new_show_h) == (show_v, show_h):
                break
            show_v, show_h = new_show_v, new_show_h

        canvas_w = max(140, min(content_w, max_canvas_w - (vbar_w if show_v else 0)))
        canvas_h = max(140, min(content_h, max_canvas_h - (hbar_h if show_h else 0)))

        if show_v:
            self.v_scroll.grid(row=0, column=1, sticky="ns")
        else:
            self.v_scroll.grid_remove()
        if show_h:
            self.h_scroll.grid(row=1, column=0, sticky="ew")
        else:
            self.h_scroll.grid_remove()

        self.canvas.configure(width=canvas_w, height=canvas_h)
        self.update_idletasks()
        self.geometry(f"{self.winfo_reqwidth()}x{self.winfo_reqheight()}")


class AboutDialog(_RcDialog):
    """103 DIALOG 22, 17, 134, 118 -- CAPTION "關於"

    對應原始碼 sub_405EF0：這個圖示雙擊會觸發隱藏的「作弊」彩蛋對話框
    （原本藏在關於對話框裡，不是藏在桌面上的兔子本體）。"""

    def __init__(self, master, sprites, on_icon_double_click=None):
        super().__init__(master, "關於", 134, 118)

        # CONTROL 107, 200, STATIC, SS_ICON, 57, 23, 20, 20
        icon_w, icon_h = self.dlu.x(20), self.dlu.y(20)
        img = sprites.ico_image(107, max(icon_w, icon_h))
        self._img = img
        icon_label = tk.Label(self.body, image=img, cursor="hand2", borderwidth=0)
        self.put(icon_label, 57, 23, 20, 20)
        if on_icon_double_click:
            icon_label.bind("<Double-Button-1>", lambda e: on_icon_double_click())

        # CONTROL "Mashmaro Version 1.0", -1, STATIC, 27, 10, 82, 8
        self.put(
            tk.Label(self.body, text="Mashmaro Version 1.0", anchor="w"),
            27, 10, 82, 8,
        )
        # CONTROL "確定", 1, BUTTON, BS_DEFPUSHBUTTON, 54, 86, 30, 11
        self.put(
            ttk.Button(self.body, text="確定", command=self.destroy),
            54, 86, 30, 11,
        )
        # CONTROL "Copyright (C) 2002", -1, STATIC, 36, 100, 73, 8
        self.put(
            tk.Label(self.body, text="Copyright (C) 2002", anchor="w"),
            36, 100, 73, 8,
        )
        # CONTROL "出品：闌之谷", 1022, STATIC, 40, 46, 49, 8
        self.put(
            tk.Label(self.body, text="賤兔原作：金在仁", anchor="w"),
            40, 46, 49, 8,
        )
        # CONTROL "https://game76420.github.io/", 1012, STATIC, 31, 58, 71, 8
        # 原版是把這一行做成可互動的超連結；這裡改成單擊即可開啟。
        link_label = tk.Label(
            self.body,
            text=ABOUT_URL,
            anchor="w",
            fg="#cc0000",
            cursor="hand2",
        )
        self.put(
            link_label,
            31, 58, 71, 8,
        )
        link_label.bind("<Button-1>", lambda e: self._open_url())
        # CONTROL "繁體中文化：Clong Lii", 1022, STATIC, 30, 73, 76, 8
        self.put(
            tk.Label(self.body, text="Python 重製：張書維", anchor="w"),
            30, 73, 76, 8,
        )
        # Python 重製版額外加一行署名，不影響原本版面（放在對話框最下面）
        self.put(
            tk.Label(self.body, text="Python 重製工具：Claude AI", anchor="w", fg="#555"),
            30, 108, 100, 8,
        )
        self.finalize_dialog(master)

    def _open_url(self):
        try:
            webbrowser.open(ABOUT_URL)
        except Exception:
            pass


class StatusDialog(_RcDialog):
    """144 DIALOGEX 0, 0, 342, 139 -- CAPTION "狀態" """

    def __init__(self, master, pet, sprites, on_change=None):
        self.pet = pet
        self.sprites = sprites
        self.on_change = on_change
        super().__init__(master, "狀態", 342, 139)

        # CONTROL "兔子狀態", -1, BUTTON, BS_GROUPBOX, 5, 5, 175, 115
        self.put(ttk.LabelFrame(self.body, text="兔子狀態"), 5, 5, 175, 115)
        # CONTROL "兔子等級評定", -1, BUTTON, BS_GROUPBOX, 185, 5, 145, 115
        self.put(ttk.LabelFrame(self.body, text="兔子等級評定"), 185, 5, 145, 115)

        # CONTROL "名字", -1, STATIC, 18, 18, 17, 8
        self.put(tk.Label(self.body, text="名字", anchor="w"), 18, 18, 17, 8)
        # CONTROL "", 1010, EDIT, 45, 15, 45, 14
        self.name_var = tk.StringVar(value=pet.name)
        self.put(ttk.Entry(self.body, textvariable=self.name_var), 45, 15, 45, 14)

        # CONTROL "年齡", -1, STATIC, 100, 20, 17, 8
        self.put(tk.Label(self.body, text="年齡", anchor="w"), 100, 20, 17, 8)
        # CONTROL "Static", 1008, STATIC, 124, 15, 45, 15
        y, m = pet.age_years_months
        self.put(tk.Label(self.body, text=f"{y} 歲 {m} 個月", anchor="w"), 124, 15, 45, 15)

        # 左欄標籤 + 數值：饑飽 / 口渴 / 體力
        left_rows = [
            ("饑飽", f"{pet.hunger}/{pet.hunger_cap}", 49, 48),
            ("口渴", f"{pet.thirst}/{pet.thirst_cap}", 71, 69),
            ("體力", f"{pet.stamina}/{pet.stamina_cap}", 90, 90),
        ]
        for label, value, label_y, value_y in left_rows:
            # CONTROL label, -1, STATIC, 15, label_y, 22, 12
            self.put(tk.Label(self.body, text=label, anchor="center"), 15, label_y, 22, 12)
            # CONTROL "Static", idxxx, STATIC, 45, value_y, 45, 15
            self.put(tk.Label(self.body, text=value, anchor="w"), 45, value_y, 45, 15)

        # 右欄標籤 + 數值：健康 / 快樂 / 疲勞
        right_rows = [
            ("健康", f"{pet.health}%", 49, 47),
            ("快樂", f"{pet.happy}%", 72, 71),
            ("疲勞", f"{pet.fatigue}%", 92, 92),
        ]
        for label, value, label_y, value_y in right_rows:
            # CONTROL label, -1, STATIC, 98, label_y, 22, 12
            self.put(tk.Label(self.body, text=label, anchor="w"), 98, label_y, 22, 12)
            # CONTROL "Static", idxxx, STATIC, 124, value_y, 45, 15
            self.put(tk.Label(self.body, text=value, anchor="w"), 124, value_y, 45, 15)

        # 原始碼 sub_4042F0 按下 1024 後，用 BitBlt 把 sub_405F60() 選中的
        # 等級點陣圖畫在對話框 (285,20) 的位置——換算成這裡的座標系統，
        # 大約落在「兔子等級評定」框內、標題下方的空白區塊，這裡用一個
        # Label 佔位，按鈕按下才動態載入對應的 bmp（跟原版一樣，一開始
        # 是空的，要按「察看兔子等級」才會顯示）。
        self.portrait_label = tk.Label(self.body, bg=self.body["bg"])
        self.put(self.portrait_label, 195, 16, 125, 95)
        self._portrait_img = None

        # CONTROL "察看兔子等級", 1024, BUTTON, BS_PUSHBUTTON, 187, 125, 53, 14
        self.put(
            ttk.Button(self.body, text="察看兔子等級", command=self._show_grade),
            187, 125, 53, 14,
        )
        # CONTROL "", 1025, STATIC, 243, 125, 97, 8
        self.grade_label = tk.Label(self.body, text="", anchor="w", justify="left")
        self.put(self.grade_label, 243, 125, 97, 24)

        # CONTROL "退出", 1, BUTTON, BS_DEFPUSHBUTTON, 50, 125, 63, 14
        self.put(ttk.Button(self.body, text="退出", command=self._close), 50, 125, 63, 14)

        self.finalize_dialog(master)

    def _show_grade(self):
        desc, leaning_angel = self.pet.grade()
        tone = "偏天使" if leaning_angel else "偏魔鬼"
        self.grade_label.config(
            text=f"評語：{desc}　傾向：{tone}\n"
            f"天使分數：{self.pet.angel_score}　魔鬼分數：{self.pet.devil_score}"
        )
        # 對應原始碼 sub_405F60 + sub_4042F0：依魔鬼/天使值挑一張等級
        # 點陣圖（167/178/180/181/183/184/186.bmp），原版是 BitBlt 到固定
        # 位置，這裡改成放進「兔子等級評定」框內的 Label 顯示。
        bmp_id = self.pet.grade_portrait_bmp_id()
        img = self.sprites.icon(bmp_id, 120)
        self._portrait_img = img  # 保留參照，避免被 GC 回收
        self.portrait_label.config(image=img)
        self.refresh_layout()

    def _close(self):
        self.pet.name = self.name_var.get() or self.pet.name
        if self.on_change:
            self.on_change()
        self.destroy()


class ItemsDialog(_RcDialog):
    """146 DIALOG 0, 0, 102, 105 -- CAPTION "物品" """

    def __init__(self, master, pet, sprites):
        super().__init__(master, "物品", 102, 105)

        # CONTROL "物品欄", -1, BUTTON, BS_GROUPBOX, 10, 5, 85, 70
        self.put(ttk.LabelFrame(self.body, text="物品欄"), 10, 5, 85, 70)

        # CONTROL 159, -1, STATIC, SS_ICON, 25, 15, 20, 20  (蘿蔔圖示)
        # 注意：.rc 裡這裡的 159 是 ICON 資源（159.ico），不是 BITMAP 資源
        # （159.bmp 是完全不相關的兔子動畫影格）。之前誤用 sprites.icon()
        # 讀成了 159.bmp，畫面上會變成兔子頭而不是蘿蔔，這裡改成
        # ico_image() 讀正確的 159.ico。
        icon_w, icon_h = self.dlu.x(20), self.dlu.y(20)
        carrot_img = sprites.ico_image(159, max(icon_w, icon_h))
        self._imgs = [carrot_img]
        self.put(tk.Label(self.body, image=carrot_img, borderwidth=0), 25, 15, 20, 20)
        # CONTROL "根", -1, STATIC, SS_CENTER, 70, 20, 9, 8
        self.put(tk.Label(self.body, text="根", anchor="center"), 70, 20, 9, 8)
        # CONTROL "Static", 1009, STATIC, SS_RIGHT, 50, 20, 15, 15
        self.put(
            tk.Label(self.body, text=str(pet.carrots), anchor="e"), 50, 20, 15, 15
        )

        # CONTROL 160, -1, STATIC, SS_ICON, 25, 44, 20, 20  (水瓶圖示)
        # 同上，160 是 ICON 資源（160.ico），改用 ico_image() 讀正確圖檔。
        water_img = sprites.ico_image(160, max(icon_w, icon_h))
        self._imgs.append(water_img)
        self.put(tk.Label(self.body, image=water_img, borderwidth=0), 25, 44, 20, 20)
        # CONTROL "瓶", -1, STATIC, SS_CENTER, 71, 50, 9, 8
        self.put(tk.Label(self.body, text="瓶", anchor="center"), 71, 50, 9, 8)
        # CONTROL "Static", 1011, STATIC, SS_RIGHT, 50, 50, 15, 15
        self.put(
            tk.Label(self.body, text=str(pet.water), anchor="e"), 50, 50, 15, 15
        )

        # CONTROL "確定(O)", 1, BUTTON, BS_DEFPUSHBUTTON, 30, 85, 33, 14
        self.put(
            ttk.Button(self.body, text="確定(O)", command=self.destroy), 30, 85, 33, 14
        )
        self.finalize_dialog(master)


class SettingsDialog(_RcDialog):
    """157 DIALOG 0, 0, 122, 159 -- CAPTION "設定" """

    def __init__(self, master, pet, on_apply=None):
        self.pet = pet
        self.on_apply = on_apply
        super().__init__(master, "設定", 122, 159)

        # CONTROL "軟體設置", -1, BUTTON, BS_GROUPBOX, 5, 5, 110, 70
        self.put(ttk.LabelFrame(self.body, text="軟體設置"), 5, 5, 110, 70)
        # 原本這裡是「開機自動執行」勾選框，改成「精靈大小」縮放設定
        # （100% = 原始尺寸，存進 pet.sprite_scale，跟其他數值存同一份存檔）。
        self.put(
            tk.Label(self.body, text="精靈大小(%)", anchor="w"),
            16, 32, 46, 10,
        )
        self.scale_var = tk.IntVar(value=round(pet.sprite_scale * 100))
        self.put(
            ttk.Spinbox(
                self.body,
                from_=50,
                to=300,
                increment=10,
                textvariable=self.scale_var,
                width=6,
            ),
            64, 30, 40, 14,
        )

        # CONTROL "兔子設定", -1, BUTTON, BS_GROUPBOX, 5, 80, 110, 55
        self.put(ttk.LabelFrame(self.body, text="兔子設定"), 5, 80, 110, 55)

        unlocked = pet.auto_feed_unlocked()
        state = "normal" if unlocked else "disabled"
        self.auto_eat_var = tk.BooleanVar(value=pet.auto_eat and unlocked)
        self.auto_drink_var = tk.BooleanVar(value=pet.auto_drink and unlocked)
        # CONTROL "自動吃東西", 1015, BUTTON, BS_AUTOCHECKBOX | WS_DISABLED, 14, 96, 56, 10
        self.put(
            ttk.Checkbutton(
                self.body, text="自動吃東西", variable=self.auto_eat_var, state=state
            ),
            14, 96, 56, 10,
        )
        # CONTROL "自動喝東西", 1016, BUTTON, BS_AUTOCHECKBOX | WS_DISABLED, 14, 110, 56, 10
        self.put(
            ttk.Checkbutton(
                self.body, text="自動喝東西", variable=self.auto_drink_var, state=state
            ),
            14, 110, 56, 10,
        )
        # CONTROL "只有達到天使兔等級才可自動進食。", -1, STATIC, 75, 95, 35, 35
        self.put(
            tk.Label(
                self.body,
                text="只有達到天使兔等級才可自動進食。",
                anchor="nw",
                justify="left",
                wraplength=self.dlu.x(35),
            ),
            75, 95, 40, 35,
        )

        # CONTROL "確定", 1, BUTTON, BS_DEFPUSHBUTTON, 45, 140, 25, 14
        self.put(ttk.Button(self.body, text="確定", command=self._ok), 45, 140, 25, 14)
        self.finalize_dialog(master)

    def _ok(self):
        try:
            pct = int(self.scale_var.get())
        except (tk.TclError, ValueError):
            pct = round(self.pet.sprite_scale * 100)
        pct = max(50, min(300, pct))
        self.pet.sprite_scale = pct / 100
        self.pet.auto_eat = self.auto_eat_var.get()
        self.pet.auto_drink = self.auto_drink_var.get()
        if self.on_apply:
            self.on_apply(self.pet.sprite_scale)
        self.destroy()


class SecretDialog(_RcDialog):
    """159 DIALOG 0, 0, 187, 100 -- CAPTION "恭喜"

    對應原本 159 號「恭喜」對話框：作弊按鈕 + 隱含屬性顯示。"""

    def __init__(self, master, pet, on_change=None):
        self.pet = pet
        self.on_change = on_change
        super().__init__(master, "恭喜", 187, 100)

        # CONTROL "作弊", -1, BUTTON, BS_GROUPBOX, 5, 5, 80, 70
        self.put(ttk.LabelFrame(self.body, text="作弊"), 5, 5, 80, 70)
        # CONTROL "得到十根蘿蔔", 1009, BUTTON, BS_PUSHBUTTON, 15, 20, 61, 14
        self.put(
            ttk.Button(self.body, text="得到十根蘿蔔", command=self._add_carrots),
            15, 20, 61, 14,
        )
        # CONTROL "得到十瓶水", 1011, BUTTON, BS_PUSHBUTTON, 15, 50, 61, 14
        self.put(
            ttk.Button(self.body, text="得到十瓶水", command=self._add_water),
            15, 50, 61, 14,
        )

        # CONTROL "隱含屬性", -1, BUTTON, BS_GROUPBOX, 95, 5, 85, 70
        self.put(ttk.LabelFrame(self.body, text="隱含屬性"), 95, 5, 85, 70)
        # CONTROL "魔鬼", -1, STATIC, 105, 25, 17, 8
        self.put(tk.Label(self.body, text="魔鬼", anchor="w"), 105, 25, 17, 8)
        # CONTROL "Static", 1020, STATIC, 125, 25, 40, 10
        self.devil_label = tk.Label(self.body, text=str(pet.devil_score), anchor="w")
        self.put(self.devil_label, 125, 25, 40, 10)
        # CONTROL "天使", -1, STATIC, 105, 55, 17, 8
        self.put(tk.Label(self.body, text="天使", anchor="w"), 105, 55, 17, 8)
        # CONTROL "", 1021, STATIC, 125, 53, 40, 10
        self.angel_label = tk.Label(self.body, text=str(pet.angel_score), anchor="w")
        self.put(self.angel_label, 125, 53, 40, 10)

        # CONTROL "確定", 1, BUTTON, BS_DEFPUSHBUTTON, 76, 85, 35, 14
        self.put(ttk.Button(self.body, text="確定", command=self.destroy), 76, 85, 35, 14)
        self.finalize_dialog(master)

    def _add_carrots(self):
        self.pet.cheat_add_carrots(10)
        self.devil_label.config(text=str(self.pet.devil_score))
        self.angel_label.config(text=str(self.pet.angel_score))
        if self.on_change:
            self.on_change()

    def _add_water(self):
        self.pet.cheat_add_water(10)
        self.devil_label.config(text=str(self.pet.devil_score))
        self.angel_label.config(text=str(self.pet.angel_score))
        if self.on_change:
            self.on_change()
