# -*- coding: utf-8 -*-
"""
sprites.py
----------
把 assets/ 底下的 .png（已經手動去背、本身就有 alpha 透明通道）轉成
tkinter 可以用的透明 PhotoImage。

（舊版原本是讀 .bmp、用 (0,255,0) 綠幕色key去背，跟原程式用 CreateRectRgn /
CombineRgn 做視窗去背是同一個概念；現在圖檔已經換成自帶透明背景的 .png，
不需要色key去背這一步了。）

不依賴 Pillow：圖片讀取／翻轉／縮放都改用 imaging.py 裡純 tkinter 實作的
小工具（Tk 8.6 內建就能解碼含 alpha 的 PNG，不需要另外裝套件）。

每張圖對應到哪個動作，記錄在存檔（~/.mashmaro_sprite_map.json）裡。
下面的 DEFAULT_MAPPING 只是第一次啟動、還沒有存檔時的預設猜測。
"""
import json
import os
import re

from imaging import flip_left_right, load_png, resize_to, resize_within
from paths import app_dir, resource_dir

ASSET_DIR = os.path.join(resource_dir(), "assets")
# 跟 pet_state.py 的 SAVE_FILE 一樣，改成放在程式資料夾而不是使用者家目錄，
# 方便整個資料夾一起搬移；多人共用同一份程式資料夾時會共用同一份設定。
CONFIG_FILE = os.path.join(app_dir(), "mashmaro_sprite_map.json")


# 動作代碼 -> 中文顯示名稱
# 走路拆成四個方向：向左 / 向右 / 向左下 / 向右下，各自可以單獨指定圖片。
# 如果某個方向沒有指定任何圖片，動畫系統會自動用「鏡像」的方式借用對面
# 方向的圖（例如向左沒圖就把向右的圖左右翻轉來用），所以舊的設定檔
# （只有單一「走路」分類）升級後畫面不會壞掉，仍然可以正常走動。
ACTIONS = [
    "idle",
    "walk_left",
    "walk_right",
    "walk_down_left",
    "walk_down_right",
    "eating",
    "drinking",
    "sleeping",
    "working",
    "playing",
    "portrait",
    "unused",
]
ACTION_LABELS = {
    "idle": "待機",
    "walk_left": "走路（向左）",
    "walk_right": "走路（向右）",
    "walk_down_left": "走路（向左下）",
    "walk_down_right": "走路（向右下）",
    "eating": "吃東西",
    "drinking": "喝水",
    "sleeping": "睡覺",
    "working": "勞動",
    "playing": "自由活動",
    "portrait": "肖像（對話框裝飾用）",
    "unused": "不使用",
}

# 方向互為鏡像的搭配：其中一邊沒圖時，借用另一邊的圖水平翻轉
MIRROR_PAIRS = {
    "walk_left": "walk_right",
    "walk_right": "walk_left",
    "walk_down_left": "walk_down_right",
    "walk_down_right": "walk_down_left",
}

# 點擊兔子本體時的反應動畫（對應原始碼 sub_405C40 隨機挑中的其中一種）。
# 這兩組不透過可重新指派的動作分類，而是直接對應原始碼寫死
# 的 bmp 資源編號——原版本來就是拿「吃/喝/睡覺/勞動」也在用的同一批點陣圖
# 去湊出這兩個反應動畫（例如 147~152 同時也是吃/喝動畫的影格），不是獨立
# 準備的專屬素材，所以這裡照樣直接借用相同編號的圖檔，行為上才會一致：
#   Anim_Blink     (sub_4050A0，狀態61~66，200ms/格)：147→148→149→150→151→152→148
#   Anim_HopReaction(sub_405930，狀態81~85，100ms/格，先升後降)：
#       161→156→157→158→159→158→157→156→161
CLICK_REACTION_SEQUENCES = {
    "blink": [147, 148, 149, 150, 151, 152, 148],
    "hop": [161, 156, 157, 158, 159, 158, 157, 156, 161],
}

# 閒置狀態下的隨機小動作（對應原始碼 sub_405C80 / Anim_IdleGesture，
# 主狀態代碼 90，次狀態 91→92→93→94 依序播放）：
#   狀態91 -> dword_40AAA0 = sub_402F10(dword_40AB28) -> 155.bmp
#   狀態92 -> dword_40AA9C = sub_402F10(dword_40AB24) -> 162.bmp
#   狀態93 -> dword_40AA98 = sub_402F10(dword_40AB20) -> 160.bmp
#   狀態94 -> hrgnSrc2     = sub_402F10(h)            -> 146.bmp（=待機基本站姿，
#             播完這格就 KillTimer 停止，回到一般待機動畫，不像 blink/hop
#             那樣結束後還會再接一次 sub_404F50 QuickAck 閃爍）
# 由 sub_405370 (LifeTick，每 60 秒一次) 尾端以 50% 機率跟 QuickAck 二選一
# 觸發（另一半機率是 sub_404F50），見 main.py 的 _game_tick_loop。
IDLE_GESTURE_SEQUENCE = [155, 162, 160, 146]

# 下面這份對照表是直接對照原始反編譯 C 源碼重新核對出來的結果，
# 不是憑外觀猜的。依據有二：
#   1) sub_401150 裡 LoadBitmapA(hInstance, 資源ID) 把哪個點陣圖檔
#      存進哪個全域變數（例如 dword_40AB74 = 144.bmp）；
#   2) sub_4013C0 的 WM_PAINT 內，"dword_40ACAC 主狀態／dword_40ACA8
#      次狀態" 這組全域變數在各個 Anim_* 函式裡被設成哪個值時，
#      WM_PAINT 會拿哪個全域變數（也就是哪張 bmp）去 BitBlt。
# 對照結果（主狀態代碼 -> 影格 bmp 編號）：
#   0            待機基本站姿(h)            -> 146
#   1/2/3        走路(向左) 第1/2/3格        -> 136 / 134 / 135
#   11/12/13     走路(向右) 第1/2/3格        -> 137 / 138 / 140
#   21/22        吃東西 第1/2格              -> 139 / 141
#   31/32        喝水 第1/2格                -> 142 / 143
#   41/42        勞動 第1/2格                -> 144 / 145
#   51           Anim_QuickAck 短暫回應閃爍  -> 133（單張，非固定活動，見下方說明）
#   60(61~66)    Anim_Blink 點擊反應-眨眼    -> 147/148/149/150/151/152（見 CLICK_REACTION_SEQUENCES）
#   71/72        Anim_Sleeping 真正的睡覺動畫 -> 153 / 154
#   80(81~85)    Anim_HopReaction 點擊反應-跳一下 -> 161/156/157/158/159（見 CLICK_REACTION_SEQUENCES）
#   90(91~94)    Anim_IdleGesture 閒置隨機小動作(94格會回到146) -> 155/162/160/(146)
#   100(101/102) Anim_HopDownLeft  自由活動-向左下跳 -> 163 / 164
#   110(111/112) Anim_HopDownRight 自由活動-向右下跳 -> 165 / 166
#
# 之前版本把 133 當成「待機」預設圖、把 146~152 一起塞進「吃東西」、
# 151~154 塞進「喝水」、155~158 塞進「睡覺」、161~166 塞進「勞動」，
# 這些都對不上原始碼裡真正的用途，這就是預設狀態圖跟原版不一致、
# 需要手動修正才會一致的原因。這裡直接改成跟
# 原始碼一致的正確預設值，第一次啟動、還沒有設定檔時就會是對的。
#
# 133（Anim_QuickAck）、147~152（眨眼）、155~162（閒置小動作/跳躍
# 反應影格）這些不是「持續播放的活動」，是原程式用計時器/狀態機在
# 特定瞬間交替閃過的單張過場影格；本移植版沒有實作那些瞬間過場
# 機制（跳一下/眨眼兩種點擊反應改用 CLICK_REACTION_SEQUENCES 直接
# 照 bmp 編號硬寫死撥放，見上方），所以這些編號預設不歸類到任何
# 「活動」分類，維持「不使用」，才不會讓待機/吃/喝等動畫混進不相關
# 的過場影格。若有需要，仍可直接編輯設定檔把它們指派給想要的分類。
_DEFAULT_WALK_LEFT = [136, 134, 135]
_DEFAULT_WALK_RIGHT = [137, 138, 140]
_DEFAULT_WALK_DOWN_LEFT = [163, 164]
_DEFAULT_WALK_DOWN_RIGHT = [165, 166]
_DEFAULT_EAT = [139, 141]
_DEFAULT_DRINK = [142, 143]
_DEFAULT_SLEEP = [153, 154]
_DEFAULT_WORK = [144, 145]
_DEFAULT_IDLE = [146]
_DEFAULT_PORTRAIT = [167, 178, 180, 181, 183, 184, 186]


def _build_default_mapping():
    mapping = {}
    for bmp_id in _DEFAULT_IDLE:
        mapping[str(bmp_id)] = "idle"
    for bmp_id in _DEFAULT_WALK_LEFT:
        mapping[str(bmp_id)] = "walk_left"
    for bmp_id in _DEFAULT_WALK_RIGHT:
        mapping[str(bmp_id)] = "walk_right"
    for bmp_id in _DEFAULT_WALK_DOWN_LEFT:
        mapping[str(bmp_id)] = "walk_down_left"
    for bmp_id in _DEFAULT_WALK_DOWN_RIGHT:
        mapping[str(bmp_id)] = "walk_down_right"
    for bmp_id in _DEFAULT_EAT:
        mapping[str(bmp_id)] = "eating"
    for bmp_id in _DEFAULT_DRINK:
        mapping[str(bmp_id)] = "drinking"
    for bmp_id in _DEFAULT_SLEEP:
        mapping[str(bmp_id)] = "sleeping"
    for bmp_id in _DEFAULT_WORK:
        mapping[str(bmp_id)] = "working"
    for bmp_id in _DEFAULT_PORTRAIT:
        mapping[str(bmp_id)] = "portrait"
    return mapping


DEFAULT_MAPPING = _build_default_mapping()


def all_bmp_ids():
    ids = []
    if os.path.isdir(ASSET_DIR):
        for fname in os.listdir(ASSET_DIR):
            m = re.match(r"^(\d+)\.png$", fname)
            if m:
                ids.append(int(m.group(1)))
    return sorted(ids)


def _load_image(bmp_id):
    path = os.path.join(ASSET_DIR, f"{bmp_id}.png")
    # 圖檔已經是自己去背好的 PNG（本身就有 alpha 透明通道），Tk 內建就能
    # 直接解碼出含透明度的 PhotoImage，不需要 Pillow 轉換。
    return load_png(path)


class SpriteBook:
    """載入並快取所有姿勢動畫，回傳 tkinter PhotoImage。"""

    def __init__(self, scale=1.0):
        self._img_cache = {}
        self._tk_cache = {}
        # 精靈放大縮小倍率（1.0=100%，對應 PetState.sprite_scale）。只影響
        # 桌面上的兔子本體（frame/reaction_bmp），不影響設定/狀態/物品欄等
        # 對話框裡固定尺寸的小圖（portrait/icon/ico_image）。
        self.scale = scale
        self.mapping = self._load_mapping()
        self._rebuild_sets()

    def set_scale(self, scale):
        """執行期間即時調整放大倍率：清掉舊尺寸的 PhotoImage 快取，
        下一次 frame()/reaction_bmp() 就會用新倍率重新產生。"""
        if scale == self.scale:
            return
        self.scale = scale
        self._tk_cache.clear()

    def _scaled(self, im):
        if self.scale == 1.0:
            return im
        w = max(1, round(im.width() * self.scale))
        h = max(1, round(im.height() * self.scale))
        # 素材本身的 alpha 只有全透明/全不透明兩種值（無半透明羽化邊緣，
        # 已逐檔驗證過），所以顏色跟 alpha 統一用最近鄰縮放即可：畫面上
        # 兔子視窗是靠 -transparentcolor 去背（TRANSPARENT_KEY 洋紅色
        # #ff00fe 當畫布底色），只要 alpha 縮放後仍是非 0 即 255，就不會
        # 有半透明像素跟洋紅色底混出粉紅色鑲邊。
        return resize_to(im, w, h)

    # ------------------------------------------------------------------
    # 圖片 <-> 動作 對應表：讀取 / 存檔 / 重建
    # ------------------------------------------------------------------
    def _load_mapping(self):
        mapping = dict(DEFAULT_MAPPING)
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                if isinstance(saved, dict):
                    mapping.update(saved)
            except (OSError, ValueError):
                pass
        # 相容舊版設定檔：舊版只有單一「walk」分類，升級後改成「向右」
        for k, v in list(mapping.items()):
            if v == "walk":
                mapping[k] = "walk_right"
        # 涵蓋所有實際存在、但預設表沒提到的圖 -> 先歸類為不使用
        for bmp_id in all_bmp_ids():
            mapping.setdefault(str(bmp_id), "unused")
        return mapping

    def save_mapping(self):
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(self.mapping, f, ensure_ascii=False, indent=2)
        except OSError:
            pass

    def _rebuild_sets(self):
        sets = {a: [] for a in ACTIONS}
        for bmp_id in all_bmp_ids():
            action = self.mapping.get(str(bmp_id), "unused")
            if action not in sets:
                action = "unused"
            sets[action].append(bmp_id)
        self.sets = sets

    # ------------------------------------------------------------------
    def _image(self, bmp_id):
        if bmp_id not in self._img_cache:
            self._img_cache[bmp_id] = _load_image(bmp_id)
        return self._img_cache[bmp_id]

    def _frame_source(self, activity):
        """
        回傳 (實際要用的動作 key, 是否要水平翻轉)。
        走路四個方向若沒有指派圖片，會依序嘗試：
          1. 鏡像方向（向左 <-> 向右、向左下 <-> 向右下），翻轉借用
          2. 「下」方向沒圖時，退回同水平方向的一般走路（不下沉），
             一樣先試自己再試鏡像
          3. 都沒有的話，退回 idle，最後才退回任何一張圖，避免動畫掛掉
        """
        if self.sets.get(activity):
            return activity, False

        mirror = MIRROR_PAIRS.get(activity)
        if mirror and self.sets.get(mirror):
            return mirror, True

        if activity in ("walk_down_left", "walk_down_right"):
            base = "walk_left" if activity == "walk_down_left" else "walk_right"
            if self.sets.get(base):
                return base, False
            base_mirror = MIRROR_PAIRS.get(base)
            if base_mirror and self.sets.get(base_mirror):
                return base_mirror, True

        for fallback in ("idle", "walk_right", "walk_left"):
            if self.sets.get(fallback):
                return fallback, False

        all_ids = all_bmp_ids()
        if all_ids:
            for a, ids in self.sets.items():
                if ids:
                    return a, False
        return None, False

    def _frame_ids_for(self, activity):
        source, _flip = self._frame_source(activity)
        if source is None:
            return []
        return self.sets.get(source) or []

    def frame(self, activity, index, flip=False):
        source, auto_flip = self._frame_source(activity)
        if source is None:
            return None
        ids = self.sets.get(source) or []
        if not ids:
            return None
        bmp_id = ids[index % len(ids)]
        effective_flip = bool(flip) != bool(auto_flip)  # 兩者互斥時才要翻轉
        cache_key = (bmp_id, effective_flip, self.scale)
        if cache_key not in self._tk_cache:
            im = self._image(bmp_id)
            if effective_flip:
                im = flip_left_right(im)
            im = self._scaled(im)
            self._tk_cache[cache_key] = im
        return self._tk_cache[cache_key]

    def frame_count(self, activity):
        return len(self._frame_ids_for(activity))

    def reaction_bmp(self, bmp_id):
        """直接依 bmp 資源編號取圖（不經過可重新指派的動作分組），
        給 CLICK_REACTION_SEQUENCES 這種寫死特定影格序列的場合使用。"""
        cache_key = (bmp_id, False, self.scale)
        if cache_key not in self._tk_cache:
            self._tk_cache[cache_key] = self._scaled(self._image(bmp_id))
        return self._tk_cache[cache_key]

    def portrait(self, bmp_id, max_size=160):
        key = (bmp_id, "portrait", max_size)
        if key not in self._tk_cache:
            im = self._image(bmp_id)
            self._tk_cache[key] = resize_within(im, max_size, max_size)
        return self._tk_cache[key]

    def icon(self, bmp_id, size=48):
        return self.portrait(bmp_id, max_size=size)

    def ico_image(self, ico_id, size=48):
        """讀取原本 Windows ICON 資源(107/108/159/160/161)轉出來的 PNG，
        用於關於對話框、視窗圖示，以及物品欄的蘿蔔(159)/水(160)圖示。

        這些 icon 資源檔在資源轉檔階段要預先挑好「正確的那一張」影格、
        存成 assets/{id}ico.png（例如 159.ico 裡混雜了誤植的兔子頭跟真正
        的蘿蔔圖兩張完全不同的圖，轉檔時要手動挑出蘿蔔圖那張存成
        159ico.png），所以這裡不需要再像舊版那樣自己解析 .ico 多影格、
        挑色彩深度最高的那張——直接讀檔即可。

        故意不做「找不到就退回讀同編號一般素材」的保底：{id}.png 跟
        {id}ico.png 是完全不同的兩張圖（來自不同的資源類型），退回讀
        錯的那張只會讓畫面顯示錯誤圖案卻不容易發現，比直接報錯更糟。
        找不到檔案就讓它明確失敗，才知道是缺了哪個轉檔。"""
        key = (ico_id, "ico", size)
        if key not in self._tk_cache:
            path = os.path.join(ASSET_DIR, f"{ico_id}ico.png")
            if not os.path.exists(path):
                raise FileNotFoundError(
                    f"缺少 icon 素材：{path}\n"
                    f"ico_image({ico_id}) 需要 assets/{ico_id}ico.png，"
                    f"這張圖跟同編號的一般素材 {ico_id}.png 內容不同、"
                    "不能互相替代，請從原始 .ico 資源重新轉出這一張圖。"
                )
            im = load_png(path)
            self._tk_cache[key] = resize_within(im, size, size)
        return self._tk_cache[key]
