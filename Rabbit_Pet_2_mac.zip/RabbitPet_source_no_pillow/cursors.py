# -*- coding: utf-8 -*-
"""
cursors.py
----------
把 assets/{id}cur.png 現場包裝成 Windows 原生 .cur 檔，供 tkinter 用
cursor="@路徑.cur" 套用成滑鼠游標。

背景：Tk 在 Windows 下的 -cursor "@檔案路徑" 只吃真正的 .cur/.ani 容器
格式，不能直接指定一張 PNG 當游標。素材轉檔階段已經把原本的 154.cur /
155.cur / 156.cur 轉成純 PNG（154cur.png / 155cur.png / 156cur.png，
本身就有 alpha 透明通道），所以程式啟動、第一次需要套用某個游標時，
在這裡把對應的 PNG 現場包成一個最小、合法的 .cur 檔（傳統的 32bpp BGRA
DIB + 1bpp AND mask，這是相容性最好、Windows 一定看得懂的舊式編碼），
寫到系統暫存資料夾（tempfile.gettempdir()）底下的專屬子資料夾裡，
不會跟 exe 或存檔放在一起，之後用法就跟原本直接讀真正 .cur 檔一樣。

轉檔後已經沒有原始 .cur 檔留存的「熱點 (hotspot)」資訊了，這裡預設一律
用圖片左上角 (0, 0) 當熱點——這是最常見、最安全的預設值。如果實際點下去
的感覺跟圖案對不太起來，可以在下面的 HOTSPOTS 裡個別調整。
"""
import os
import struct
import tempfile

from imaging import load_png

# 產生的 .cur 檔集中放在系統 temp 底下這個子資料夾，跟 exe/存檔分開。
_CUR_CACHE_DIR = os.path.join(tempfile.gettempdir(), "RabbitPet_cursors")

# 個別游標的熱點座標 (x, y)；沒列在這裡的就用預設 (0, 0)。
HOTSPOTS = {}

_generated_paths = {}


def _build_cur_bytes(img, hotspot=(0, 0)):
    """把一張 tkinter.PhotoImage 包裝成合法的單一影格 .cur 檔案 bytes。"""
    w, h = img.width(), img.height()
    hot_x, hot_y = hotspot

    color_data = bytearray()
    row_bytes = (w + 7) // 8
    row_bytes_padded = ((row_bytes + 3) // 4) * 4  # AND mask 每列要補齊到 4 bytes
    mask_data = bytearray()

    # DIB 資料由下往上存（bottom-up），這是 BMP/ICO/CUR 的傳統慣例。
    for y in reversed(range(h)):
        row_mask = bytearray(row_bytes_padded)
        for x in range(w):
            r, g, b = img.get(x, y)
            transparent = bool(img.transparency_get(x, y))
            a = 0 if transparent else 255
            color_data += bytes((b, g, r, a))  # DIB 是 BGRA 順序
            if transparent:
                row_mask[x // 8] |= 0x80 >> (x % 8)
        mask_data += row_mask

    # BITMAPINFOHEADER：高度要寫成「彩色影格 + AND mask」疊在一起的 2 倍高。
    header = struct.pack(
        "<IiiHHIIiiII",
        40,   # biSize
        w,    # biWidth
        h * 2,  # biHeight（XOR 彩色影格 + AND mask）
        1,    # biPlanes
        32,   # biBitCount
        0,    # biCompression (BI_RGB，不壓縮)
        len(color_data) + len(mask_data),  # biSizeImage
        0, 0,  # biXPelsPerMeter, biYPelsPerMeter
        0, 0,  # biClrUsed, biClrImportant
    )
    image_data = header + bytes(color_data) + bytes(mask_data)

    # ICONDIR：reserved=0, type=2(游標，1是圖示), count=1
    icondir = struct.pack("<HHH", 0, 2, 1)
    w_byte = w if w < 256 else 0
    h_byte = h if h < 256 else 0
    # CUR 的 ICONDIRENTRY 跟 ICO 共用同一個 16-byte 結構，只是原本
    # 「色彩平面數/色彩深度」這兩個 WORD 欄位在 CUR 裡改當熱點 x/y 用。
    entry = struct.pack(
        "<BBBBHHII",
        w_byte, h_byte, 0, 0,
        hot_x, hot_y,
        len(image_data),
        22,  # 檔案裡只有一張影格時，影格資料固定接在 6+16=22 位元組之後
    )
    return icondir + entry + image_data


def _cache_path(cur_id):
    os.makedirs(_CUR_CACHE_DIR, exist_ok=True)
    return os.path.join(_CUR_CACHE_DIR, f"mashmaro_cursor_{cur_id}.cur")


def ensure_cur_file(cur_id, png_path):
    """確保系統 temp 資料夾底下有一份由 png_path 現場轉出來的 .cur 檔，回傳
    該 .cur 檔的路徑；找不到來源 PNG 就回傳 None（呼叫端自行決定要不要
    安靜略過，跟原本檔案不存在時的容錯風格一致）。"""
    cached = _generated_paths.get(cur_id)
    if cached is not None:
        return cached
    if not os.path.exists(png_path):
        return None
    img = load_png(png_path)
    data = _build_cur_bytes(img, HOTSPOTS.get(cur_id, (0, 0)))
    out_path = _cache_path(cur_id)
    with open(out_path, "wb") as f:
        f.write(data)
    _generated_paths[cur_id] = out_path
    return out_path
