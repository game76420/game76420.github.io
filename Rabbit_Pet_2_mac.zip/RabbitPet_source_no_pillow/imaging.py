# -*- coding: utf-8 -*-
"""
imaging.py
----------
不依賴 Pillow 的最小影像工具。

只用 tkinter.PhotoImage 內建的 PNG 解碼能力（Tk 8.6 起原生支援讀取含
alpha 通道的 PNG，不需要另外裝任何套件），加上這裡手動實作的翻轉／縮放，
取代原本 sprites.py 裡 PIL.Image / PIL.ImageTk 的用途。

本專案 assets/ 底下每一張 .png 的 alpha 通道都已經逐檔掃描驗證過，
只會出現「全透明(0)」或「全不透明(255)」兩種值，沒有半透明的羽化邊緣。
所以下面的縮放／翻轉統一對 RGB 與 alpha 都採「最近鄰」取樣即可：
不會有「顏色用平滑濾波、alpha 用最近鄰」兩套邏輯要保持一致的問題，
也不會在二元 alpha 的邊緣長出半透明鑲邊（貼在洋紅色去背視窗上會變成
一圈粉紅色鑲邊的那個舊問題）。
"""
import tkinter as tk


def load_png(path):
    """讀取一張 PNG 檔，回傳 tkinter.PhotoImage（Tk 內建解碼，含 alpha）。"""
    return tk.PhotoImage(file=path)


def flip_left_right(img):
    """回傳水平鏡像後的新 PhotoImage（顏色與透明度都一起鏡像）。
    Tk 沒有內建的鏡像指令，這裡逐像素搬移來完成；圖檔都不大，
    只在第一次用到某個鏡像方向時執行一次，之後會被上層快取住。"""
    w, h = img.width(), img.height()
    out = tk.PhotoImage(width=w, height=h)
    for y in range(h):
        row = " ".join("#%02x%02x%02x" % img.get(w - 1 - x, y) for x in range(w))
        out.put("{%s}" % row, to=(0, y))
    for y in range(h):
        for x in range(w):
            if img.transparency_get(w - 1 - x, y):
                out.transparency_set(x, y, True)
    return out


def resize_to(img, new_w, new_h):
    """縮放到指定的絕對尺寸（不保留長寬比，由呼叫端自己算好目標尺寸）。
    對應原本 SpriteBook._scaled() 依「精靈大小(%)」設定縮放的用途。"""
    w, h = img.width(), img.height()
    new_w = max(1, int(new_w))
    new_h = max(1, int(new_h))
    if new_w == w and new_h == h:
        return img
    out = tk.PhotoImage(width=new_w, height=new_h)
    # 先把每個輸出座標對應的最近鄰來源座標算好，避免在雙層迴圈裡重算
    xs = [min(w - 1, (x * w) // new_w) for x in range(new_w)]
    ys = [min(h - 1, (y * h) // new_h) for y in range(new_h)]
    for oy, sy in enumerate(ys):
        row = " ".join("#%02x%02x%02x" % img.get(sx, sy) for sx in xs)
        out.put("{%s}" % row, to=(0, oy))
    for oy, sy in enumerate(ys):
        for ox, sx in enumerate(xs):
            if img.transparency_get(sx, sy):
                out.transparency_set(ox, oy, True)
    return out


def resize_within(img, max_w, max_h):
    """等比例縮小到 (max_w, max_h) 以內；圖片本來就比較小的話完全不動。
    對應原本 PIL 的 Image.thumbnail()：只縮小、不放大。"""
    w, h = img.width(), img.height()
    scale = min(max_w / w, max_h / h, 1.0)
    if scale >= 1.0:
        return img
    return resize_to(img, round(w * scale), round(h * scale))
