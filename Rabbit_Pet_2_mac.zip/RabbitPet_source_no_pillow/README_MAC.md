# macOS 版說明

原本的 `RabbitPet.exe` 是 Windows 專屬執行檔（PyInstaller 打包），沒辦法在
Mac 上直接跑。這個資料夾裡的 Python 原始碼已經改好，讓透明背景視窗在
macOS 上也能正常顯示（改用 Tk/Aqua 支援的 `-transparent` + `systemTransparent`，
不是原本 Windows 專屬的 `-transparentcolor`），有兩種方式可以在 Mac 上使用：

## 方式一：直接用 Python 執行（最簡單，推薦先試這個）

**最簡單的開法：雙擊 `啟動兔子.command`**

這個檔案雙擊後會自動開一個 Terminal 視窗、執行 `python3 main.py`，
不需要自己打指令。第一次使用前要先給它執行權限（只需做一次）：
```bash
chmod +x 啟動兔子.command
```
（在 Terminal 裡 `cd` 到這個資料夾後執行上面這行指令）

之後在 Finder 裡雙擊 `啟動兔子.command` 就能開啟兔子桌寵。如果雙擊後
跳出「無法確認開發者」的警告，在檔案上按右鍵（或 Control+點擊）選
「打開」、再按一次「打開」放行即可，之後雙擊就會正常執行。

**或者自己手動執行也可以：**

1. 確認 Mac 上有 Python 3，而且內建 tkinter：
   ```bash
   python3 --version
   python3 -c "import tkinter"
   ```
   如果第二行報錯（`No module named _tkinter`），代表你的 Python 沒帶 tkinter
   （常見於某些 Homebrew 裝的 python）。解法擇一：
   - 到 [python.org](https://www.python.org/downloads/) 下載官方安裝包（本身就內建 tkinter）
   - 或執行 `brew install python-tk`
2. 在 Terminal 裡進到這個資料夾，執行：
   ```bash
   python3 main.py
   ```
   不需要另外裝 Pillow 或任何套件，跑的就是這份原始碼本身。

## 方式二：打包成獨立的 RabbitPet.app（不需要另外裝 Python 也能雙擊執行）

這一步**一定要在 Mac 上執行**，因為 App 打包工具（PyInstaller）沒辦法跨平台
「在別的系統上做出 Mac 能用的 App」，只能在 Mac 本機上打包。

1. 把整個資料夾複製到 Mac 上
2. 打開 Terminal，進到這個資料夾，執行：
   ```bash
   chmod +x build_mac.sh
   ./build_mac.sh
   ```
3. 完成後，`dist/RabbitPet.app` 就是可以雙擊執行的獨立 App。
   - 第一次打開如果跳出「無法確認開發者」的警告（Gatekeeper 攔截，因為
     沒有付費的 Apple 開發者簽章），到 App 上按右鍵（或 Control+點擊）
     選「打開」，再按一次「打開」就會放行；之後就能正常雙擊開啟。

## 跟 Windows 版行為上的差異

- **透明背景**：Mac 上是用真正的像素透明（`systemTransparent`），比
  Windows 版的洋紅色key去背更乾淨，理論上不會有邊緣色偏的問題。
- **滑鼠游標**（拖曳/懸停時換游標）：目前只在 Windows 上生效，Mac 上會
  維持系統預設游標，不影響其他功能（拖曳、選單、吃喝勞動等照常運作）。
- **App 圖示**：`build_mac.sh` 會自動把 `assets/107ico.png` 轉成 App 需要的
  `.icns` 圖示；因為來源圖檔解析度不高，放大後可能不夠銳利，純外觀問題。
- 存檔位置（`~/.mashmaro_rabbit_save.json`、`~/.mashmaro_sprite_map.json`）
  在 Mac 上一樣可以正常讀寫，兩個平台的存檔格式相同。

其他遊戲玩法、選單功能都跟 Windows 版完全一樣，詳見 `README.md`。
