# -*- coding: utf-8 -*-
"""
pet_state.py
------------
遊戲邏輯核心：數值系統、動作、存讀檔、天使/魔鬼隱藏屬性、等級評定。

版本說明（重要）：
這一版已依照「賤兔_加註解_exe.c」（Hex-Rays 反編譯 + 中文加註）裡實際找得到
的具體邏輯與數值重新對齊，取代先前「合理猜測參數」的版本。對照依據：

    - sub_403ED0（AdoptNewPet）    -> 初始數值
    - sub_403920 / sub_403BD0     -> 吃 / 喝 的實際增量與動畫節奏
    - sub_4047B0 / sub_404B70     -> 勞動的體力消耗、心情代價與隨機獎勵
    - sub_4037A0                  -> 自由活動（閒晃模式）的心情/疲勞/體力代價
    - sub_4057B0                  -> 睡覺動畫結束時的瞬間效果
    - sub_405370（LifeTick）      -> 每分鐘一次的核心生命週期：
        飢餓/口渴衰減與自動吃喝、天使/魔鬼值依「心情」高低累積、
        每 10 次呼叫的自動存檔與「每滿12個月，飢餓/口渴/體力上限+10」
        的成長機制
    - sub_405F60（ComputeRabbitRank）-> 等級門檻
    - sub_402DA0（SettingsDialogProc）-> 自動吃喝解鎖門檻

已知且刻意保留的原始程式「怪癖」：
    1. LifeTick 裡口渴值是否要「自動喝水」的判斷，用的是「剛更新過的飢餓值」
       (v0/10>2)，而不是口渴值自己，這在原始加註裡就被指出很可能是開發者
       筆誤，但這是實際會執行的邏輯，這裡如實保留（見 tick() 內註解）。
    2. 原始碼裡「健康(health)」只有在領養當下被設成 100，之後整個程式
       沒有任何地方會再去讀寫它做遊戲邏輯判斷（只在狀態視窗顯示用），也就是
       健康其實是個「顯示用但不會自動變化」的數字。這一版也如實保留這個
       行為：health 不再有任何自動增減。
    3. 快樂度(happy)不會隨時間自然漂移，只會被「吃 / 喝 / 勞動 / 自由活動 /
       睡覺結束」這些具體事件明確地加或扣。
    4. 疲勞(fatigue)與體力(stamina)平時（發呆／閒置）完全不會自動變化，
       只有「勞動」「自由活動」會直接消耗，「睡覺完成」會補滿體力/歸零疲勞。

【2026 校對更新】拿到新一份「加註解」反編譯稿（逐函式重新核對過中文字串
與行內細節）之後，發現並修正了 2 個先前版本裡跟真正組語邏輯不符的地方：
    A. 睡覺結束（原 sub_4057B0）：先前誤以為 dword_40AD00 是「心情」而在
       睡醒時把 happy 歸零。新註解重新核對全域變數表，dword_40AD00 其實
       是「疲勞(fatigue)」，被歸零的是疲勞，不是心情——睡醒後心情完全
       不受影響。舊版「睡醒但心情變平淡」的訊息與 happy=0 已一併移除。
    B. 兔子等級評定（原 sub_405F60）「天使 / 魔鬼」傾向判斷，原始碼用的是
       嚴格大於：devil_score < angel_score 才算「偏天使」，天使值等於
       魔鬼值時算「偏魔鬼」；舊版用 >= 誤把打平也算天使，已改回嚴格 >。
       同一份反編譯稿也還原出等級判斷各分支「真正會顯示的描述文字」
       （原本只有點陣圖檔名，沒有中文敘述），一併加進 grade() 回傳值，
       取代先前自己想的「稱號」文字。

【存檔行為：刻意不跟隨原版的一個疏漏】
新註解核對 sub_403F90(存檔)/sub_404140(讀檔) 的實際欄位順序後發現：原始
存檔 rabbit.dat 其實只存了名字、視窗位置、領養旗標、開機自動執行/自動吃喝
開關、天使/魔鬼值，並「不包含」飢餓/口渴/體力/健康/心情/疲勞/年齡這六維
即時數值——代表原版理論上每次重開程式，這六維數值都會回到 C 全域變數的
預設值(0)，這看起來是原作者當年的資料結構疏漏，而不是刻意設計。
跟你確認過後決定：Python 版**不**重現這個疏漏，繼續用 JSON 把六維數值也
完整存讀，維持「關掉程式數值不會亂跳」的合理使用體驗。

無法從反編譯精確還原、仍採用合理近似值的地方：
    - 自由活動在原始碼是「持續閒晃模式」，每 ~4.5 秒（30 個 150ms 影格）
      結算一次代價（心情+5、疲勞+2、體力-1）。這裡把它保留成單次點擊的
      離散動作，直接套用「一次結算」的代價，而不是持續模式，方便沿用
      現有的右鍵選單互動方式。
    - 原始睡覺動畫實際長度約 40 秒（20 格 x 2 秒），這裡近似成 1 個心跳
      （TICK_SECONDS）之後套用瞬間效果。
"""
import json
import os
import random
import time

# 存檔位置：跟這支 .py 檔案放在同一個資料夾（方便整個資料夾複製/搬移就
# 帶著存檔走，等於「攜帶式」用法）。原本是存在使用者家目錄
# (os.path.expanduser("~"))，那樣比較符合一般桌面程式的習慣、也不會因為
# 把整個資料夾複製到別台電腦而動到存檔；改成放在程式資料夾後要注意：
# 如果好幾個人共用同一台電腦、且用同一份程式資料夾，會共用同一個存檔
# （不像家目錄那樣每個 Windows 帳號各自獨立）。
from paths import app_dir

APP_DIR = app_dir()
SAVE_FILE = os.path.join(APP_DIR, "mashmaro_rabbit_save.json")

# ---------------------------------------------------------------------------
# 可調參數
# ---------------------------------------------------------------------------
TICK_SECONDS = 60        # 每隔幾秒真實時間 = 遊戲的一個「心跳」
                          # 對應原始碼 SetTimer(hWnd, 1, 0xEA60, ...)，0xEA60 = 60000ms
MAX_STAT = 100            # 健康 / 快樂 / 疲勞 的固定上限（這三個原始碼裡不會成長）

# 飢餓/口渴：每 2 個心跳（≈120秒）才結算一次，一次 -4
# 對應原始碼 sub_405370 裡 ++dword_40A960 >= 2 的節流
DECAY_HUNGER = 4
DECAY_THIRST = 4
AUTO_EAT_HUNGER_GAIN = 6    # 飢餓偏低且開啟自動吃、有蘿蔔時：改成 +6（而非 -4）
AUTO_DRINK_THIRST_GAIN = 6  # 口渴同理

# 吃 / 喝（sub_403920 / sub_403BD0）
EAT_HUNGER_GAIN = 10          # 沒吃到上限：饑飽 +10
EAT_HAPPY_GAIN_SUCCESS = 4    # 吃到 +10 沒超過上限：心情 +4
EAT_HAPPY_GAIN_CAPPED = 3     # 吃到會超過上限，直接重置成上限：心情只 +3
DRINK_THIRST_GAIN = 10
DRINK_HAPPY_GAIN_SUCCESS = 3
DRINK_HAPPY_GAIN_CAPPED = 2

# 勞動（sub_4047B0 / sub_404B70）
WORK_FATIGUE_GAIN = 10        # 疲勞固定 +10（上限100）
WORK_STAMINA_MIN_REQUIRED = 20  # 體力 < 20 時，工作仍會做完，但結果會較差
WORK_STAMINA_BASE_COST = 10   # 體力消耗 = 10 + (工作後疲勞 // 10)，動態隨疲勞變重
WORK_FATIGUE_HAPPY_THRESHOLD = 40  # 工作後疲勞 <=40：心情代價較輕；>40：代價變重
WORK_HAPPY_COST_LOW = 3
WORK_HAPPY_COST_HIGH_MULT = 4  # 疲勞>40時，心情代價 = 4 * (疲勞//10)

# 自由活動 / 閒晃（sub_4037A0）
# 【注意】原始碼是「持續閒晃模式」，不是單次離散動作：main.py 目前用
# roam_tick()（配合 ROAM_TICK_MS=4500，對應「每30個150ms影格結算一次」）
# 走的是持續模式這條路，跟這裡的常數完全吻合，已經精準對齊。
# 下面 free_activity()（單次結算版）目前沒有被 main.py 呼叫，是保留給
# 「萬一想改回單次點擊」用的備用 API，避免有人誤以為自由活動的代價是
# 靠這幾個常數算的——實際在跑的是 roam_tick() 那一份，數值上兩者相同。
PLAY_HAPPY_GAIN = 5
PLAY_FATIGUE_GAIN = 2
PLAY_STAMINA_COST = 1

# 天使 / 魔鬼值（sub_405370）：每 2 個心跳，依「目前心情」高低累積，各有上限
ANGEL_DEVIL_CAP = 50000
MOOD_THRESHOLD_FOR_DEVIL = 50  # 心情 <=50 -> 魔鬼值+1；否則天使值+1

# 成長機制（sub_405370 每 10 次呼叫一輪，每滿 12 輪 = 12「個月」就長大一次）
GROWTH_TICKS_PER_MONTH = 10
MONTHS_PER_GROWTH_CYCLE = 12
GROWTH_CAP_GAIN = 10   # 每次長大：飢餓/口渴/體力 上限 各 +10

# ---------------------------------------------------------------------------
# 【2026 精算更新】動作「忙碌鎖定」的真實秒數
# ---------------------------------------------------------------------------
# 之前這幾個動作的持續時間是用 TICK_SECONDS(60秒)當顆粒度概略給的，這次把
# 原始碼裡每個動作實際用的計時器 ID／毫秒間隔／要重複幾輪才結算，逐一算成
# 真實秒數，發現落差非常大（吃/喝/勞動原本只要 1.8~2.7 秒就播完動畫、
# 结算完畢，之前卻誤鎖了好幾分鐘）：
#   吃：計時器4000，全程150ms/格，6次咀嚼(=12格切換) -> 12*0.15 = 1.8秒
#   喝：計時器5000，第1格150ms、之後全部改成300ms，4口(=8格切換)
#       -> 0.15 + 7*0.3 = 2.25秒
#   勞動：計時器6000，A格150ms／B格300ms交替，6輪 -> 6*(0.15+0.3) = 2.7秒
# 這三個現在改成用真實毫秒計時器（由 main.py 的 root.after 驅動）跳回待機，
# 不再借用 60 秒一次的 LifeTick 心跳來倒數，兩邊顆粒度差太多，硬綁在一起
# 反而失真。
#
# 睡覺則維持用 TICK_SECONDS 心跳倒數（1 個心跳=60秒）：原始碼算出來是
# 計時器9000，A格500ms／B格2000ms交替，滿21輪結束 -> 21*(0.5+2) = 52.5秒，
# 跟目前用的 60 秒已經很接近（誤差在一成左右），不像吃/喝/勞動差了
# 一兩百倍那麼誇張，沒必要為了 7.5 秒的差距換一套機制、多引入額外的
# 計時器管理複雜度。
ACTION_BUSY_SECONDS = {
    "eating": 1.8,
    "drinking": 2.25,
    "working": 2.7,
}

ACTIVITY_DURATION = {
    # "eating"/"drinking"/"working" 已改用 ACTION_BUSY_SECONDS + 真實毫秒
    # 計時器處理（見 main.py），不再放進這個以「心跳」為單位的表。
    "sleeping": 1,   # 對應原始 ~52.5 秒的固定長度睡眠動畫（見上方說明）
}


def _clamp(v, lo=0, hi=MAX_STAT):
    return max(lo, min(hi, v))


class PetState:
    def __init__(self):
        self.name = "小賤兔"
        self.hunger = 80
        self.thirst = 80
        self.stamina = 100
        self.health = 100
        self.happy = 100
        self.fatigue = 0

        # 三個「會隨成長提高」的上限（其餘三維健康/快樂/疲勞上限固定100）
        self.hunger_cap = 100
        self.thirst_cap = 100
        self.stamina_cap = 100

        self.age_ticks = 0          # 心跳數（每分鐘+1，用來算「每2次結算一次」的節流）
        self.growth_counter = 0     # 對應 dword_40ADDC，累積到10觸發一次成長檢查
        self.age_months = 0         # 對應 dword_40ACDC，每滿12個月觸發一次成長

        self.carrots = 2
        self.water = 2

        self.angel_score = 0
        self.devil_score = 0

        self.activity = "idle"      # idle / eating / drinking / working / playing / sleeping
        self.activity_left = 0      # 剩餘心跳數

        # 精靈放大縮小倍率：1.0 = 100%（預設），透過「軟體設置」對話框調整，
        # 存進跟其他數值同一份 JSON 存檔裡。取代原本的「開機自動執行」選項。
        self.sprite_scale = 1.0
        self.auto_eat = False
        self.auto_drink = False

        self.born_at = time.time()
        self.last_tick_at = time.time()

        self.adopted = False
        self.window_x = None
        self.window_y = None

        # 這次 tick() 產生、還沒顯示給使用者看的警告訊息。
        # 不存進存檔，只是暫存給 main.py 用。
        self.pending_warnings = []

        # 對應原始碼 sub_405370 裡 dword_40ACE4<=0 || dword_40ACEC<=0 的
        # 「異常/危機」分支：饑餓或口渴見底時為 True。原始碼在這個分支會
        # 呼叫 sub_404B40() 停掉所有動畫計時器，讓兔子整隻凍結在畫面上、
        # 只剩下每分鐘跳出的警告訊息框（並不會真的把已領養旗標清掉，所以
        # 不是真正的死亡，是「餓/渴到僵住」）。不存進存檔，只是暫存給
        # main.py 用來決定要不要停掉閒置動畫/自由活動。
        self.in_crisis = False

    # ------------------------------------------------------------------
    # 存 / 讀檔（改用 JSON，取代原本的自訂二進位格式）
    # ------------------------------------------------------------------
    def save(self, path=SAVE_FILE):
        data = self.__dict__.copy()
        data.pop("pending_warnings", None)
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except OSError:
            pass

    @classmethod
    def load(cls, path=SAVE_FILE):
        st = cls()
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for k, v in data.items():
                    if hasattr(st, k):
                        setattr(st, k, v)
            except (OSError, ValueError):
                pass
        # 吃/喝/勞動的忙碌狀態現在是靠 main.py 的真實毫秒計時器解除的
        # （見 ACTION_BUSY_SECONDS），不像睡覺有 activity_left 可以跨重開
        # 程式繼續倒數。如果剛好在動畫播放中途關掉程式，讀檔時這幾個狀態
        # 一律視為已經播完，直接回到待機，避免卡死在忙碌狀態出不來。
        if st.activity in ("eating", "drinking", "working"):
            st.activity = "idle"
            st.activity_left = 0
        return st

    # ------------------------------------------------------------------
    # 年齡（對應 dword_40ACDC：除以12=年，餘數=月）
    # ------------------------------------------------------------------
    @property
    def age_years_months(self):
        return self.age_months // 12, self.age_months % 12

    # ------------------------------------------------------------------
    # 等級評定（sub_405F60：依 (魔鬼值+天使值)//100 分四段）
    # 傾向判斷是嚴格大於：devil_score < angel_score 才算「偏天使」，
    # 打平(相等)時原始碼會走「偏魔鬼」那個分支，不是平手算天使。
    # 描述文字直接採用反編譯稿裡還原出的原始 .exe 字串（unk_40A4xx 系列），
    # 不再自己另外發明「稱號」。
    # ------------------------------------------------------------------
    def grade(self):
        total = self.angel_score + self.devil_score
        leaning_angel = self.angel_score > self.devil_score
        tier = total // 100
        if tier == 0:
            return "現在是兔寶寶，細心照料哦", leaning_angel
        elif tier <= 3:
            return ("兔子得到細心照料﹐很乖巧" if leaning_angel
                     else "兔子吃不飽，不時去流浪"), leaning_angel
        elif tier <= 9:
            return ("兔子得到主人的細心照料" if leaning_angel
                     else "照顧不周﹐兔子很悲傷"), leaning_angel
        else:
            return ("兔子被培育成天使兔" if leaning_angel
                     else "兔子被培育成魔鬼兔"), leaning_angel

    def grade_portrait_bmp_id(self):
        """對應 sub_405F60 挑選的等級點陣圖（原始碼用 BitBlt 直接畫在
        狀態對話框上，這裡回傳資源編號，讓 GUI 版用 sprites.icon() 顯示
        同一張圖）：
          級距0        -> 186.bmp（初階通用，不分天使/魔鬼）
          級距1~3 天使 -> 178.bmp／魔鬼 -> 180.bmp
          級距4~9 天使 -> 183.bmp／魔鬼 -> 181.bmp
          級距10+ 天使 -> 184.bmp／魔鬼 -> 167.bmp
        """
        total = self.angel_score + self.devil_score
        leaning_angel = self.angel_score > self.devil_score
        tier = total // 100
        if tier == 0:
            return 186
        elif tier <= 3:
            return 178 if leaning_angel else 180
        elif tier <= 9:
            return 183 if leaning_angel else 181
        else:
            return 184 if leaning_angel else 167

    def auto_feed_unlocked(self):
        """只有天使值明顯領先魔鬼值才可自動進食（原設定對話框 sub_402DA0：
        (魔鬼值+天使值) > 1000 且 天使值 > 魔鬼值 才會把核取方塊解鎖）"""
        total = self.angel_score + self.devil_score
        return total > 1000 and self.angel_score > self.devil_score

    # ------------------------------------------------------------------
    # 動作 API（對應右鍵選單）
    # ------------------------------------------------------------------
    def can_act(self):
        return self.activity in ("idle",)

    def eat(self):
        if self.carrots <= 0:
            return False, "沒有蘿蔔了，快去勞動賺點蘿蔔吧！"
        if not self.can_act():
            return False, "牠現在正忙著呢。"
        self._set_activity("eating")
        return True, f"{self.name} 開始吃蘿蔔了。"

    def drink(self):
        if self.water <= 0:
            return False, "沒有水了。"
        if not self.can_act():
            return False, "牠現在正忙著呢。"
        self._set_activity("drinking")
        return True, f"{self.name} 開始喝水了。"

    def _work_reward(self):
        """對應 sub_404B70：心情越高，骰出好結果的機率相對越高。"""
        v0 = (MAX_STAT - self.happy) // 10
        roll = random.randint(0, v0 + 9)
        if roll == 0:
            self.carrots += 2
            return f"{self.name} 工作表現優異，得到 2 根蘿蔔！"
        elif roll <= 3:
            self.carrots += 1
            return f"{self.name} 認真工作，得到 1 根蘿蔔。"
        elif roll == 4:
            self.water += 2
            return f"{self.name} 工作表現優異，得到 2 瓶水！"
        elif roll <= 7:
            self.water += 1
            return f"{self.name} 認真工作，得到 1 瓶水。"
        else:
            return f"{self.name} 工作了一陣子，但這次沒有收穫。"

    def work(self):
        if not self.can_act():
            return False, "牠現在正忙著呢。"
        if self.stamina <= 0:
            return False, f"{self.name} 已經累壞了，完全沒力氣工作。"
        self._set_activity("working")
        return True, f"{self.name} 開始努力工作了。"

    def free_activity(self):
        """【未被 main.py 使用的備用 API】單次結算版的自由活動，數值跟
        roam_tick() 完全相同，只是包成「呼叫一次就結算一次」而非持續模式。
        目前 main.py 走的是 roam_tick() + ROAM_TICK_MS 那條持續閒晃模式的
        路徑（跟原始碼 sub_4037A0 一致），這個方法保留著純粹是為了 API
        完整性／方便之後想改回單次點擊時直接用，不影響目前的實際行為。"""
        if not self.can_act():
            return False, "牠現在正忙著呢。"
        self.happy = _clamp(self.happy + PLAY_HAPPY_GAIN)
        self.fatigue = _clamp(self.fatigue + PLAY_FATIGUE_GAIN)
        self.stamina = _clamp(self.stamina - PLAY_STAMINA_COST)
        return True, f"{self.name} 到處蹦蹦跳跳，玩得很開心！"

    def sleep_toggle(self):
        if self.activity == "sleeping":
            return False, f"{self.name} 已經睡著了，現在叫不醒。"
        if not self.can_act():
            return False, "牠現在正忙著呢。"
        self._set_activity("sleeping")
        return True, f"{self.name} 要睡覺了……"

    def _set_activity(self, name):
        self.activity = name
        self.activity_left = ACTIVITY_DURATION.get(name, 0)

    def _resolve_eat(self):
        self.carrots -= 1
        if self.hunger + EAT_HUNGER_GAIN <= self.hunger_cap:
            self.hunger += EAT_HUNGER_GAIN
            self.happy = _clamp(self.happy + EAT_HAPPY_GAIN_SUCCESS)
            return f"{self.name} 開心地吃著蘿蔔，吃飽了一點。"
        self.hunger = self.hunger_cap
        self.happy = _clamp(self.happy + EAT_HAPPY_GAIN_CAPPED)
        return f"{self.name} 已經吃得很飽了，不太想再吃了。"

    def _resolve_drink(self):
        self.water -= 1
        if self.thirst + DRINK_THIRST_GAIN <= self.thirst_cap:
            self.thirst += DRINK_THIRST_GAIN
            self.happy = _clamp(self.happy + DRINK_HAPPY_GAIN_SUCCESS)
            return f"{self.name} 咕嚕咕嚕地喝水，解渴多了。"
        self.thirst = self.thirst_cap
        self.happy = _clamp(self.happy + DRINK_HAPPY_GAIN_CAPPED)
        return f"{self.name} 已經喝得很飽了，不太想再喝了。"

    def _resolve_work(self):
        old_stamina = self.stamina
        self.fatigue = _clamp(self.fatigue + WORK_FATIGUE_GAIN)
        if old_stamina >= WORK_STAMINA_MIN_REQUIRED:
            v5 = self.fatigue // 10
            self.stamina = _clamp(self.stamina - (WORK_STAMINA_BASE_COST + v5))
            if self.fatigue <= WORK_FATIGUE_HAPPY_THRESHOLD:
                self.happy = _clamp(self.happy - WORK_HAPPY_COST_LOW)
                return self._work_reward()
            cost = WORK_HAPPY_COST_HIGH_MULT * v5
            if self.happy - cost >= 0:
                self.happy -= cost
                return self._work_reward()
            self.happy = 0
            return f"{self.name} 太累了，沒力氣工作了。"
        self.stamina = 0
        cost = WORK_HAPPY_COST_HIGH_MULT * (self.fatigue // 10)
        self.happy = _clamp(self.happy - cost)
        return f"{self.name} 體力不夠，這次工作沒什麼成果，還覺得心情低落。"

    def finish_action(self, name):
        """由 main.py 用真實毫秒計時器在吃/喝/勞動動畫播完後呼叫。
        只有目前仍是同一個動作時才會生效，並在這一刻才真正結算數值。"""
        if self.activity != name:
            return False, None
        if name == "eating":
            msg = self._resolve_eat()
        elif name == "drinking":
            msg = self._resolve_drink()
        elif name == "working":
            msg = self._resolve_work()
        else:
            msg = None
        self.activity = "idle"
        self.activity_left = 0
        return True, msg

    def click_reaction(self):
        """單純點一下（非雙擊拖曳）時的正向回饋，對應 sub_405C40：
        心情+1，並播放一個小反應動畫（動畫本身純視覺，交給呼叫端處理）。"""
        if not self.can_act():
            return False
        self.happy = _clamp(self.happy + 1)
        return True

    def roam_tick(self):
        """「自由活動」持續閒晃模式下，每隔約 4.5 秒（對應原始碼 30 個
        150ms 影格）結算一次的代價：心情+5、疲勞+2、體力-1。
        由 main.py 在自由活動模式開啟期間週期性呼叫（對應 sub_4037A0）。"""
        self.happy = _clamp(self.happy + PLAY_HAPPY_GAIN)
        self.fatigue = _clamp(self.fatigue + PLAY_FATIGUE_GAIN)
        self.stamina = _clamp(self.stamina - PLAY_STAMINA_COST)

    def cheat_add_carrots(self, n=10):
        self.carrots += n

    def cheat_add_water(self, n=10):
        self.water += n

    # ------------------------------------------------------------------
    # 心跳 tick：每 TICK_SECONDS 呼叫一次（對應 sub_405370 LifeTick）
    # ------------------------------------------------------------------
    def tick(self):
        self.pending_warnings = []  # 每次心跳重新收集，只反映「這一次」要跳出的提醒
        self.age_ticks += 1

        # 對應 ++dword_40A960 >= 2 的節流：主要邏輯大約每 2 分鐘才結算一次
        decay_tick = self.age_ticks % 2 == 0

        if decay_tick:
            # --- 天使/魔鬼值：依「目前心情」高低累積，兩者皆有上限 ---
            if self.happy <= MOOD_THRESHOLD_FOR_DEVIL:
                if self.devil_score < ANGEL_DEVIL_CAP:
                    self.devil_score += 1
            else:
                if self.angel_score < ANGEL_DEVIL_CAP:
                    self.angel_score += 1

            if self.hunger <= 0 or self.thirst <= 0:
                # 危機狀態：原始碼這裡不管是飢餓還是口渴見底（甚至兩者都
                # 見底），都只組出「同一句」訊息——byte_40A0FC("你的") +
                # 寵物名字 + byte_40A370("太久沒吃或沒喝東西，死了!")，
                # 標題固定是 byte_40A38C("死了")，並不會因為是餓還是渴
                # 而分成兩種不同文字/標題。並呼叫 sub_404B40() 停掉所有
                # 動畫計時器——還原回這個「凍結」行為，由 main.py 依
                # in_crisis 旗標停掉閒置動畫、自由活動排程，並灰掉互動選單。
                self.in_crisis = True
                self.pending_warnings.append(
                    ("死了", f"你的{self.name}太久沒吃或沒喝東西，死了!")
                )
            else:
                self.in_crisis = False
                # --- 飢餓值變化 ---
                if self.hunger // 10 > 2:  # 還算充足 (>29)
                    new_hunger = self.hunger - DECAY_HUNGER
                elif self.carrots > 0 and self.auto_eat:
                    new_hunger = self.hunger + AUTO_EAT_HUNGER_GAIN
                    self.carrots -= 1
                else:
                    new_hunger = self.hunger - DECAY_HUNGER
                    self.pending_warnings.append(("提醒", f"{self.name} 開始覺得肚子餓了。"))
                self.hunger = _clamp(new_hunger, hi=self.hunger_cap)

                # --- 口渴值變化 ---
                # 原始碼這裡的判斷條件用的是「剛剛更新過的飢餓值」(new_hunger)
                # 而不是口渴值自己，很可能是原開發者沿用上面變數時的筆誤，
                # 但這是實際會執行的邏輯，這裡如實保留（見檔頭說明）。
                if new_hunger // 10 > 2:
                    new_thirst = self.thirst - DECAY_THIRST
                elif self.water > 0 and self.auto_drink:
                    new_thirst = self.thirst + AUTO_DRINK_THIRST_GAIN
                    self.water -= 1
                else:
                    new_thirst = self.thirst - DECAY_THIRST
                    self.pending_warnings.append(("提醒", f"{self.name} 開始覺得口渴了。"))
                self.thirst = _clamp(new_thirst, hi=self.thirst_cap)

        # --- 每 10 次心跳一輪：對應自動存檔 + 每滿12個月的成長機制 ---
        # （自動存檔交給 main.py 的排程處理，這裡只處理成長部分）
        self.growth_counter += 1
        if self.growth_counter >= GROWTH_TICKS_PER_MONTH:
            self.growth_counter = 0
            self.age_months += 1
            if self.age_months % MONTHS_PER_GROWTH_CYCLE == 0:
                self.hunger_cap += GROWTH_CAP_GAIN
                self.thirst_cap += GROWTH_CAP_GAIN
                self.stamina_cap += GROWTH_CAP_GAIN
                self.pending_warnings.append(
                    ("提醒", f"{self.name} 又長大了一點！飢餓/口渴/體力的上限都提高了。")
                )

        # --- 動作倒數 ---
        if self.activity_left > 0:
            self.activity_left -= 1
            if self.activity_left == 0:
                if self.activity == "sleeping":
                    # 睡覺動畫自然跑完：疲勞歸零、體力補滿。
                    # （對應 sub_4057B0：dword_40AD00=0、dword_40ACF4=上限；
                    # 新版反編譯稿核對全域變數表後確認 dword_40AD00 是
                    # 「疲勞」不是「心情」，先前版本誤把心情也歸零，已修正
                    # ——睡醒不會影響心情。）
                    self.fatigue = 0
                    self.stamina = self.stamina_cap
                    self.pending_warnings.append(
                        ("提醒", f"{self.name} 睡飽了！體力全滿，疲勞也消除了。")
                    )
                self.activity = "idle"

        self.last_tick_at = time.time()

    def apply_offline_elapsed(self):
        """讀檔時，依照離線的真實秒數補算 tick，避免關掉程式數值就停住不動。"""
        elapsed = time.time() - self.last_tick_at
        ticks = int(elapsed // TICK_SECONDS)
        ticks = min(ticks, 2000)  # 上限，避免離線太久要跑很久迴圈
        for _ in range(ticks):
            self.tick()
        self.pending_warnings = []  # 離線期間累積的提醒不用一次跳出一排視窗，靜默補算就好
