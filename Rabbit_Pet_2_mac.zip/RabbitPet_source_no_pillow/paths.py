# -*- coding: utf-8 -*-
"""
paths.py
--------
統一處理「一般執行 (python main.py)」與「PyInstaller 打包成 exe」兩種情況下的路徑，
給 pet_state.py / sprites.py / main.py 共用。

- app_dir()：存放存檔 (json)、設定檔等「需要跟著 exe 走、且可讀寫」資料的資料夾。
  一般執行時 = 這支程式所在資料夾；打包成 exe 時 = exe 檔案所在資料夾。
  【注意】打包成 --onefile exe 時，不能用 os.path.dirname(__file__) 當存檔資料夾，
  因為那會指向 PyInstaller 執行時解壓縮素材的暫存資料夾，程式關閉後會被刪除，
  存檔等於白存。一定要用 sys.executable 所在的資料夾。

- resource_dir()：讀取「打包進 exe 裡」的靜態資源（assets/、logo.ico）用的資料夾。
  一般執行時 = 這支程式所在資料夾；打包成 --onefile exe 時 = PyInstaller 執行期間
  解壓縮素材的暫存資料夾 (sys._MEIPASS)。
"""
import os
import sys


def app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def resource_dir():
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(sys.executable)))
    return os.path.dirname(os.path.abspath(__file__))
