#!/bin/bash
# build_mac.sh —— 在 macOS 上把這份原始碼打包成 RabbitPet.app
#
# 使用方式（在 Mac 上，Terminal 進到這個資料夾後執行）：
#   chmod +x build_mac.sh
#   ./build_mac.sh
#
# 完成後，App 會在 dist/RabbitPet.app，直接雙擊就能執行
# （第一次開啟如果被 Gatekeeper 擋下，右鍵「打開」一次即可）。
set -e
cd "$(dirname "$0")"

if ! command -v python3 &> /dev/null; then
    echo "找不到 python3，請先安裝 Python 3（建議到 python.org 下載安裝，"
    echo "或用 Homebrew：brew install python-tk）"
    exit 1
fi

if ! python3 -c "import tkinter" 2>/dev/null; then
    echo "這個 Python 沒有內建 tkinter（macOS 系統內建的 python3 常常缺這個）。"
    echo "請改用 python.org 官方安裝包，或執行：brew install python-tk"
    exit 1
fi

if ! python3 -m pip show pyinstaller >/dev/null 2>&1; then
    echo "安裝 PyInstaller..."
    python3 -m pip install --user pyinstaller
fi

# 把現成的 assets/107ico.png 轉成 macOS App 需要的 .icns 圖示格式。
# sips / iconutil 是 macOS 內建工具，只能在 Mac 上跑（所以這步不能在別的系統先做好）。
ICON_SRC="assets/107ico.png"
ICONSET_DIR="logo.iconset"
if [ -f "$ICON_SRC" ]; then
    echo "轉換 App 圖示..."
    rm -rf "$ICONSET_DIR" logo.icns
    mkdir "$ICONSET_DIR"
    for size in 16 32 64 128 256 512; do
        sips -z "$size" "$size" "$ICON_SRC" --out "$ICONSET_DIR/icon_${size}x${size}.png" >/dev/null
        double=$((size * 2))
        sips -z "$double" "$double" "$ICON_SRC" --out "$ICONSET_DIR/icon_${size}x${size}@2x.png" >/dev/null
    done
    iconutil -c icns "$ICONSET_DIR" -o logo.icns
    rm -rf "$ICONSET_DIR"
    ICON_ARGS=(--icon logo.icns)
else
    echo "找不到 $ICON_SRC，將略過 App 圖示設定。"
    ICON_ARGS=()
fi

rm -rf build dist RabbitPet.spec.bak
python3 -m PyInstaller --onefile --windowed --noconfirm --name RabbitPet \
    "${ICON_ARGS[@]}" \
    --add-data "assets:assets" \
    --add-data "logo.ico:." \
    main.py

echo ""
echo "完成！打包好的 App 在：dist/RabbitPet.app"
