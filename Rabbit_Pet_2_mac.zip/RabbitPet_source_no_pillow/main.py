# -*- coding: utf-8 -*-
"""
main.py
-------
電子賤兔 / Mashmaro 桌面寵物 —— Python 重製版
原作：闌之谷 (2002)　繁中化：Clong Lii　Python 重製：Claude

執行方式（Windows / macOS）：
    python main.py

（不需要額外安裝 Pillow：圖片讀取／翻轉／縮放都改用 imaging.py 裡
純 tkinter 實作的小工具，只靠 Python 標準函式庫就能跑。）

這支程式會在桌面上放一隻會走來走去的透明背景兔子小精靈，右鍵叫出選單，
左鍵拖曳可以移動牠，連點兩下兔子本體會有心情+1的小反應（對應原始碼
sub_405C40）。原本隱藏的「恭喜」作弊對話框其實藏在「關於」對話框裡雙擊
圖示才會打開，不是雙擊兔子本體，見 dialogs.AboutDialog。

透明背景視窗：
- Windows 用 `-transparentcolor` 這個 Windows 專屬視窗屬性（洋紅色
  TRANSPARENT_KEY 當去背色）。
- macOS 改用 Tk/Aqua 支援的 `-transparent` 視窗屬性 + `systemTransparent`
  這個特殊背景色，是「真．像素透明」（不是色key去背），效果比色key更乾淨，
  桌布花紋、選單列穿透都不會有色偏。
- 其他平台（例如 Linux）兩種都不支援，會跳出提示、退回一般不透明視窗。
滑鼠游標（154/155/156.cur）目前仍只在 Windows 上生效，macOS／Linux 會
安靜略過、維持系統預設游標，不影響其餘功能。
"""
import os
import random
import sys
import tkinter as tk
from tkinter import messagebox

from pet_state import PetState, TICK_SECONDS, ACTION_BUSY_SECONDS
from sprites import SpriteBook, CLICK_REACTION_SEQUENCES, IDLE_GESTURE_SEQUENCE
from paths import resource_dir
import cursors
import dialogs

# exe 檔案本身的圖示、以及視窗（含所有由 root 開出來的 Toplevel 對話框）左上角
# 的圖示，統一使用跟 main.py 放在一起的 logo.ico（打包時用 --add-data 一起塞進
# exe，執行期間會被解壓縮到 resource_dir()）。
LOGO_ICO = os.path.join(resource_dir(), "logo.ico")

IS_MAC = sys.platform == "darwin"
TRANSPARENT_KEY = "#ff00fe"  # Windows 用：拿一個幾乎不會出現在素材裡的洋紅色當視窗去背色
MAC_TRANSPARENT_BG = "systemTransparent"  # macOS Tk/Aqua 專用的「真透明」特殊色
ANIM_MS = 150                # 動畫換一張圖的間隔（原程式預設 uElapse = 150ms）
ROAM_TICK_MS = 4500           # 自由活動模式下，數值代價的結算間隔
                              # 對應原始碼 sub_4037A0：每 30 個 150ms 影格 (=4500ms) 結算一次

# ---- 滑鼠游標（對應原始碼 sub_401150 的三個 LoadCursorA 呼叫）----
#   CURSOR_DRAG    154.cur -> dword_40AA94：拖曳兔子時換上的游標
#                  （同一個全域變數也被 sub_405E70/sub_405EF0 拿去當「關於」
#                  對話框連結/圖示的手指狀可點擊游標，可見這顆本身就是
#                  手指/抓取造型，用在拖曳上合情合理）
#   CURSOR_HOVER   155.cur -> hCursor：滑鼠停在兔子身上但『未拖曳』時的游標
#   CURSOR_DEFAULT 156.cur -> WNDCLASS.hCursor：視窗類別的預設游標
# 原始反編譯稿沒有留下 WM_SETCURSOR 的完整分支細節，這裡依三顆游標各自
# 註解的用途，合理還原成「進入兔子範圍換成 155、拖曳中換成 154、離開範圍
# 或其餘情況换回 156」。
CURSOR_DRAG = 154
CURSOR_HOVER = 155
CURSOR_DEFAULT = 156

# ---- 自由活動「隨機走/跳」動作的離散步伐參數 ----
# 對照原始碼 sub_4037A0（隨機挑動作）+ sub_403050/sub_403560（走路）+
# sub_403260/sub_4033E0（跳躍），原版走的是「一格一格位移＋碰邊界瞬間繞到
# 對面」的復古手感，不是挑一個隨機終點再平滑走過去；这里改成完全對應原始
# 碼的離散狀態機，不再使用舊版的 WALK_SPEED/FRAME_MS 平滑路徑規劃常數。
WALK_STEP_PX = 10             # 對應 sub_403050/sub_403560：走路每格水平移動 10px
WALK_FRAMES = 4                # 對應原始碼 4 格影格(1~4 / 11~14)跑完才交還挑動作
WALK_TICK_MS = 150             # 對應 SetTimer(...,0x96,0) = 150ms
HOP_STEP_X = 9                 # 對應 sub_403260/sub_4033E0：跳躍每格水平移動 9px
HOP_STEP_Y = 5                  # 跳躍每格垂直移動 5px
HOP_TOTAL_STEPS = 6              # 對應 dword_40ADC0/40ADC4 累計到 3
                                  # （=3 組交替影格＝6 次位移）才結束
HOP_TICK_MS = 200                 # 對應 SetTimer(...,0xC8,0) = 200ms
WRAP_MARGIN = 40                   # 原始碼 (Point.x - 10 <= -40) 判斷用的邊界餘裕

# ---- 點擊反應動畫（sub_405C40 隨機挑中的其中一種）的播放間隔 ----
REACTION_TICK_MS = {
    "blink": 200,  # 對應 sub_4050A0：SetTimer(...,0xC8,0) = 200ms/格
    "hop": 100,    # 對應 sub_405930：SetTimer(...,0x64,0) = 100ms/格
}

# 閒置隨機小動作（155→162→160→146，對應 sub_405C80）的影格間隔，
# 對應原始碼 SetTimer(hWnd, 0x2AF8, 0xC8, 0) = 200ms/格。
IDLE_GESTURE_TICK_MS = 200

# 對應原始 .rc STRINGTABLE 裡的字串（32772/32775/32776/32779/32780），
# 用選單項目的顯示文字當 key，滑鼠移到該項目上時會顯示這行提示文字。
# 原本這幾個 ID 在反編譯後的程式裡其實從沒被 LoadStringA 呼叫過（等於是
# 沒派上用場的資源），這裡拿來當滑鼠提示算是物盡其用，不是還原原本就有
# 的畫面效果。
MENU_TOOLTIPS = {
    "狀態(Z)": "察看兔子狀態",
    "喝": "喝水",
    "睡覺(S)": "兔子要休息了",
    "勞動(W)": "勞動混吃的",
    "自由活動(G)": "提高快樂度，疲勞度，減少體力",
}


class RabbitPet:
    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()  # 用不到主視窗本體，隱藏它
        try:
            # default=True：不只設定 root 本身，之後從 root 開出來的 Toplevel
            # （包含右下角小提示、對話框等）也會預設沿用這個圖示。
            self.root.iconbitmap(default=LOGO_ICO)
        except Exception:
            pass

        self.pet = PetState.load()
        self.pet.apply_offline_elapsed()
        self.sprites = SpriteBook(scale=self.pet.sprite_scale)

        first_size = self.sprites.frame("idle", 0)
        self.sprite_w = first_size.width()
        self.sprite_h = first_size.height()

        self.win = tk.Toplevel(self.root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", True)
        # 依平台選擇對應的「透明視窗」實作方式：
        #   Windows -> -transparentcolor（色key去背）
        #   macOS   -> -transparent + systemTransparent（Tk/Aqua 原生真透明）
        # 兩者都失敗（例如 Linux）就跳出提示，退回一般不透明視窗。
        self.canvas_bg = TRANSPARENT_KEY
        transparent_ok = False
        if IS_MAC:
            try:
                self.win.attributes("-transparent", True)
                self.canvas_bg = MAC_TRANSPARENT_BG
                transparent_ok = True
            except tk.TclError:
                pass
        else:
            try:
                self.win.attributes("-transparentcolor", TRANSPARENT_KEY)
                transparent_ok = True
            except tk.TclError:
                pass
        if not transparent_ok:
            messagebox.showwarning(
                "提示", "這個系統不支援透明視窗，將以一般不透明視窗顯示。"
            )

        try:
            self.win.iconbitmap(LOGO_ICO)
        except Exception:
            pass

        self.canvas = tk.Canvas(
            self.win,
            width=self.sprite_w,
            height=self.sprite_h,
            bg=self.canvas_bg,
            highlightthickness=0,
        )
        self.canvas.pack()
        if IS_MAC and transparent_ok:
            # macOS 上 Toplevel 本身的背景也要設成 systemTransparent，
            # 不然視窗邊緣（canvas 尺寸之外那一圈）還是會露出灰底。
            try:
                self.win.configure(bg=MAC_TRANSPARENT_BG)
            except tk.TclError:
                pass
        self._apply_cursor(CURSOR_DEFAULT)  # 對應 WNDCLASS.hCursor = 156.cur

        screen_w = self.win.winfo_screenwidth()
        screen_h = self.win.winfo_screenheight()
        self.ground_y = screen_h - self.sprite_h - 48  # 大約放在工作列上方（初始站立位置）
        # 注意：原版「左下跳／右下跳」的垂直位移是直接在整個螢幕高度範圍內
        # 位移＋碰邊界繞到對面（見 sub_403260/sub_4033E0），不像舊版那樣把
        # y 限制在 ground_y 附近一段範圍內，所以這裡不再需要 top_y。
        default_x = random.randint(50, screen_w - 50 - self.sprite_w)
        default_y = self.ground_y
        if not self.pet.adopted:
            self.x = min(500, max(0, screen_w - self.sprite_w))
            self.y = min(300, max(0, screen_h - self.sprite_h))
        elif self.pet.window_x is not None and self.pet.window_y is not None:
            max_x = max(0, screen_w - self.sprite_w)
            max_y = max(0, screen_h - self.sprite_h)
            self.x = max(0, min(int(self.pet.window_x), max_x))
            self.y = max(0, min(int(self.pet.window_y), max_y))
        else:
            self.x = default_x
            self.y = default_y
        self.win.geometry(f"{self.sprite_w}x{self.sprite_h}+{self.x}+{self.y}")
        self._sync_pet_window_position()

        self.image_id = self.canvas.create_image(0, 0, anchor="nw")
        self.frame_index = 0
        self.facing = "right"  # walk_left / walk_right / walk_down_left / walk_down_right 的方向部分
        # 自由活動時目前正在跑的離散動作狀態機（對應 sub_4037A0 選出來、
        # 交由 sub_403050/sub_403560/sub_403260/sub_4033E0 接手驅動的動作）：
        #   roam_action: None（尚未挑）/ "walk_left" / "walk_right" /
        #                "hop_left" / "hop_right"
        #   roam_frame:  走路動作目前跑到第幾格（0~WALK_FRAMES）
        #   roam_hop_steps: 跳躍動作目前跑到第幾格（0~HOP_TOTAL_STEPS）
        self.roam_action = None
        self.roam_frame = 0
        self.roam_hop_steps = 0
        self._roam_timer_id = None  # 目前排定中的下一步 after() id，供拖曳時取消
        # 點擊反應動畫（對應 sub_405C40 隨機挑中的「眨眼」或「跳一下」，見
        # sprites.CLICK_REACTION_SEQUENCES）目前播放狀態：
        #   reaction_kind: None（沒在播）/ "blink" / "hop"
        self.reaction_kind = None
        self.reaction_frames = []
        self.reaction_index = 0
        self._reaction_timer_id = None
        # 對應原始碼 dword_40ACA0：是否處於「自由活動」持續閒晃模式。
        # 平常（沒開這個模式）兔子站著不動，只有開了才會到處走。
        self.free_roam = False
        self._game_tick_started = False
        self._play_menu_index = None

        self._menu_tip = None  # 選單提示小視窗（滑鼠移到項目上顯示原始字串表文字）
        self._build_menu()
        self._bind_events()

        self._update_sprite()
        self._animation_loop()
        if self.pet.adopted:
            self._set_interactive_menu_enabled(True)
            self._ensure_game_tick_started()
        else:
            self._set_interactive_menu_enabled(False)

        self.win.protocol("WM_DELETE_WINDOW", self._quit)

    # ------------------------------------------------------------------
    def _show_adopt_welcome(self):
        messagebox.showinfo(
            "領養兔子",
            f"歡迎領養這隻小兔子！右鍵點牠可以打開選單，\n"
            f"記得餵牠吃蘿蔔、喝水，別讓牠餓肚子喔。",
        )

    def _ensure_game_tick_started(self):
        if self._game_tick_started:
            return
        self._game_tick_started = True
        self._game_tick_loop()

    # ------------------------------------------------------------------
    # 選單（對應原本 109 MENU 資源）
    # ------------------------------------------------------------------
    def _build_menu(self):
        m = tk.Menu(self.win, tearoff=0)
        m.add_command(label="關於(A)", command=self._show_about)
        m.add_separator()
        m.add_command(label="領養兔子", command=self._adopt_new)
        m.add_command(label="狀態(Z)", command=self._show_status)
        eat_menu = tk.Menu(m, tearoff=0)
        eat_menu.add_command(label="吃", command=self._do_eat)
        eat_menu.add_command(label="喝", command=self._do_drink)
        m.add_cascade(label="吃喝(E)", menu=eat_menu)
        m.add_command(label="勞動(W)", command=self._do_work)
        m.add_command(label="開始自由活動(G)", command=self._do_play)
        self._play_menu_index = m.index("end")
        m.add_command(label="睡覺(S)", command=self._do_sleep)
        m.add_command(label="察看物品", command=self._show_items)
        m.add_separator()
        m.add_command(label="軟體設置(C)", command=self._show_settings)
        m.add_command(label="退出(X)", command=self._quit)
        m.bind("<<MenuSelect>>", self._on_menu_select)
        eat_menu.bind("<<MenuSelect>>", self._on_menu_select)
        self.menu = m
        self._eat_menu = eat_menu
        # 對應原始碼 sub_404EF0 裡 `for (i = 3; i <= 8; ++i) EnableMenuItem(hMenu, i, ...)`
        # 操作的選單項目範圍：狀態(Z)/吃喝(E)/勞動(W)/開始自由活動(G)/睡覺(S)/
        # 察看物品，正好對應這裡建置出來、以 0 起算的第 3~8 個項目。
        self._interactive_menu_indices = range(3, 9)

    def _bind_events(self):
        self.canvas.bind("<Button-3>", self._popup_menu)
        self.canvas.bind("<Button-1>", self._drag_start)
        self.canvas.bind("<B1-Motion>", self._drag_move)
        self.canvas.bind("<ButtonRelease-1>", self._drag_end)
        self.canvas.bind("<Double-Button-1>", self._click_reaction)
        # 滑鼠進入/離開兔子範圍時切換一般游標(155.cur)/預設游標(156.cur)，
        # 對應原始碼 WM_SETCURSOR 依滑鼠是否在寵物視窗上換不同游標。
        self.canvas.bind("<Enter>", lambda e: self._apply_cursor(CURSOR_HOVER))
        self.canvas.bind("<Leave>", lambda e: self._apply_cursor(CURSOR_DEFAULT))

    # ------------------------------------------------------------------
    # 套用游標（154 拖曳 / 155 懸停 / 156 預設，見上方常數與原始碼註解）。
    # 素材轉檔階段已經把原本的 .cur 檔換成一般 PNG（154cur.png 等），但
    # tkinter 在 Windows 下的 cursor="@路徑.cur" 只吃真正的 .cur 容器格式，
    # 不能直接指定一張 PNG，所以這裡用 cursors.ensure_cur_file() 把 PNG
    # 現場包成一個最小、合法的 .cur 檔（第一次用到某個 cur_id 才轉一次，
    # 之後直接複用），再套用那個轉出來的 .cur 檔路徑。
    # 非 Windows 平台（或找不到來源 PNG、套用失敗）就安靜略過，不影響其餘
    # 功能，跟原本 `-transparentcolor` 失敗時的容錯風格一致。
    # ------------------------------------------------------------------
    def _apply_cursor(self, cur_id):
        if sys.platform != "win32":
            return
        png_path = os.path.join(resource_dir(), "assets", f"{cur_id}cur.png")
        path = cursors.ensure_cur_file(cur_id, png_path)
        if not path:
            return
        # 注意：Tk 的 -cursor 選項在丟給 Windows API 之前，字串本身會先被
        # Tcl 當成一份 list／做反斜線跳脫處理，所以：
        #   1. os.path.join 在 Windows 上組出來的是反斜線路徑，"\1"、"\U"
        #      這類序列會被 Tcl 誤判成跳脫字元，把路徑改壞；
        #   2. 如果路徑（例如使用者資料夾）中間有空白，沒加大括號包起來
        #      的話會被拆成好幾個 list 元素，同樣會讓 Tk 找不到檔案。
        # 這兩種情況 Tk 通常不會丟出可見的錯誤，只是悄悄套用失敗、游標維持
        # 原樣不變，所以外觀上就是「完全沒有效果」。這裡把路徑正規化成
        # 正斜線，並用 {} 包成單一 Tcl list 元素來避開這兩個問題。
        cursor_spec = "@" + path.replace("\\", "/")
        try:
            self.canvas.config(cursor=f"{{{cursor_spec}}}")
        except tk.TclError:
            pass

    # ------------------------------------------------------------------
    # 拖曳（對應原始碼 WM_LBUTTONDOWN=0x201：按下時先 KillTimer 停掉正在跑的
    # 走/跳動畫計時器，放開後用 ClientToScreen 把 Point 同步成拖曳結束的新
    # 座標，若原本在自由活動模式就用 150ms 重新啟動計時器接力）
    # ------------------------------------------------------------------
    def _drag_start(self, event):
        self._drag_off = (event.x, event.y)
        self._apply_cursor(CURSOR_DRAG)  # 對應拖曳中換上 154.cur
        # 使用者抓著的時候先停掉目前排定中的下一步位移，
        # 避免離散動作的 after() 跟拖曳互搶座標。
        if self._roam_timer_id is not None:
            self.root.after_cancel(self._roam_timer_id)
            self._roam_timer_id = None
        # 點擊反應動畫（眨眼/跳一下）也一併中止，改成直接回到一般待機顯示，
        # 避免拖曳中畫面還在跑反應動畫的殘留影格。
        if self._reaction_timer_id is not None:
            self.root.after_cancel(self._reaction_timer_id)
            self._reaction_timer_id = None
        self.reaction_kind = None

    def _drag_move(self, event):
        x = self.win.winfo_x() + (event.x - self._drag_off[0])
        y = self.win.winfo_y() + (event.y - self._drag_off[1])
        self.win.geometry(f"+{x}+{y}")
        # 原本這裡沒有同步 self.x/self.y，導致放開滑鼠、自由活動恢復移動時
        # 會瞬間「跳回」拖曳前的舊座標；這裡補上同步，讓离散移動接著從使用者
        # 放開的位置繼續，而不是憑空跳動。
        self.x, self.y = x, y
        self._sync_pet_window_position()

    def _drag_end(self, event):
        self._apply_cursor(CURSOR_HOVER)  # 拖曳結束、滑鼠通常仍在兔子上，換回 155.cur
        self._sync_pet_window_position()
        self.pet.save()
        if not self.free_roam or self.pet.activity != "idle":
            return
        # 拖曳結束後接力恢復原本正在跑的動作（走路/跳躍），跟原始碼放開滑鼠
        # 後重新 SetTimer 接力的邏輯相同；若剛好還沒挑過動作就直接重新挑。
        if self.roam_action in ("walk_left", "walk_right"):
            self._roam_timer_id = self.root.after(WALK_TICK_MS, self._roam_walk_step)
        elif self.roam_action in ("hop_left", "hop_right"):
            self._roam_timer_id = self.root.after(HOP_TICK_MS, self._roam_hop_step)
        else:
            self._roam_pick_action()

    def _popup_menu(self, event):
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()
            self._hide_menu_tip()

    def _click_reaction(self, event):
        """對應原始碼 sub_405C40：點兔子時的正向回饋（心情+1，並隨機播放
        「眨眼」(sub_4050A0) 或「跳一下」(sub_405930) 其中一種反應動畫）。
        睡覺中、自由活動模式、或上一個反應動畫還沒播完時不會反應。隱藏的
        作弊選單改成藏在「關於」對話框的圖示雙擊裡（見 _show_about /
        dialogs.AboutDialog）。"""
        if self.pet.in_crisis:
            return
        if self.free_roam or self.pet.activity == "sleeping":
            return
        if self.reaction_kind is not None:
            return
        if not self.pet.click_reaction():
            return
        kind = random.choice(("blink", "hop"))
        self._play_click_reaction(kind)

    def _open_secret_dialog(self):
        dialogs.SecretDialog(self.win, self.pet, on_change=self._refresh_after_change)

    # ------------------------------------------------------------------
    # 選單提示文字（對應原始 .rc STRINGTABLE 32772/32775/32776/32779/32780）
    # ------------------------------------------------------------------
    def _on_menu_select(self, event):
        widget = event.widget
        self._hide_menu_tip()
        try:
            idx = widget.index("active")
            if idx is None:
                return
            label = widget.entrycget(idx, "label")
        except tk.TclError:
            return
        text = MENU_TOOLTIPS.get(label)
        if text:
            self._show_menu_tip(text)

    def _show_menu_tip(self, text):
        tip = tk.Toplevel(self.win)
        tip.overrideredirect(True)
        tip.attributes("-topmost", True)
        tk.Label(
            tip,
            text=text,
            bg="#ffffe1",
            fg="#333333",
            font=("Microsoft JhengHei", 9),
            padx=6,
            pady=2,
            relief="solid",
            borderwidth=1,
        ).pack()
        px, py = self.win.winfo_pointerxy()
        tip.geometry(f"+{px + 16}+{py + 8}")
        self._menu_tip = tip

    def _hide_menu_tip(self):
        if self._menu_tip is not None:
            try:
                self._menu_tip.destroy()
            except tk.TclError:
                pass
            self._menu_tip = None

    # ------------------------------------------------------------------
    # 選單指令
    # ------------------------------------------------------------------
    def _show_about(self):
        dialogs.AboutDialog(self.win, self.sprites, on_icon_double_click=self._open_secret_dialog)

    def _adopt_new(self):
        if self.pet.adopted:
            if not messagebox.askyesno("領養新兔子", "你決定領養一隻新兔子嗎?"):
                return
        if self.free_roam:
            self._stop_roam()
        if self._reaction_timer_id is not None:
            self.root.after_cancel(self._reaction_timer_id)
            self._reaction_timer_id = None
        self.reaction_kind = None
        self._quick_ack_active = False
        self.pet = PetState()
        self.pet.adopted = True
        self._sync_pet_window_position()
        self.pet.save()
        # 對應 sub_403ED0 領養完成後開放全部互動項目；第一次領養也不再維持
        # 啟動時那種「未領養前鎖住大部分選單」的狀態。
        self._set_interactive_menu_enabled(True)
        self._ensure_game_tick_started()
        self._show_adopt_welcome()

    def _show_status(self):
        dialogs.StatusDialog(self.win, self.pet, self.sprites, on_change=self.pet.save)

    def _show_items(self):
        dialogs.ItemsDialog(self.win, self.pet, self.sprites)

    def _show_settings(self):
        dialogs.SettingsDialog(self.win, self.pet, on_apply=self._apply_sprite_scale)

    def _apply_sprite_scale(self, scale):
        """設定對話框按下確定後即時套用「精靈大小」：清掉舊尺寸的圖片
        快取、以新尺寸重新量出寬高，並透過 _set_frame 同步調整 canvas
        與視窗大小（底部+水平中心對齊，兔子不會因為變大變小而位移），
        畫面立刻換成新大小，不需要重開程式。"""
        self.sprites.set_scale(scale)
        new_frame = self.sprites.frame(self._current_activity_key(), self.frame_index)
        self._set_frame(new_frame)
        self.pet.save()

    def _do_eat(self):
        self._stop_roam()
        ok, msg = self.pet.eat()
        self._toast(msg)
        if ok:
            self._schedule_finish_action("eating")

    def _do_drink(self):
        self._stop_roam()
        ok, msg = self.pet.drink()
        self._toast(msg)
        if ok:
            self._schedule_finish_action("drinking")

    def _do_work(self):
        self._stop_roam()
        ok, msg = self.pet.work()
        self._toast(msg)
        if ok:
            self._schedule_finish_action("working")

    def _schedule_finish_action(self, name):
        """吃/喝/勞動動畫實際播放的長度是 1.8~2.7 秒等級（見
        pet_state.ACTION_BUSY_SECONDS 開頭的精算註解），跟每分鐘一次的
        LifeTick 心跳顆粒度差太多，所以改用獨立的真實毫秒計時器；數值也在
        這一刻才真正結算，不再是按下選單當下先扣先算。"""
        seconds = ACTION_BUSY_SECONDS.get(name, 0)

        def _finish():
            resolved, msg = self.pet.finish_action(name)
            if not resolved:
                return
            # 對應原始碼 sub_403920/sub_403BD0/sub_4047B0 結算完都會呼叫
            # sub_404F50 (Anim_QuickAck) 閃一下，見 _play_quick_ack 說明。
            self._play_quick_ack()
            if msg:
                self._toast(msg)
            self.pet.save()

        self.root.after(int(seconds * 1000), _finish)

    def _do_sleep(self):
        self._stop_roam()
        ok, msg = self.pet.sleep_toggle()
        self._toast(msg)

    # ------------------------------------------------------------------
    # 自由活動（對應原始碼 32780：切換式的「持續閒晃」模式，開啟時兔子
    # 會自己走來走去，並每隔約4.5秒結算一次心情/疲勞/體力的代價；平常
    # 待機（沒開這個模式）兔子是站著不動的）
    # ------------------------------------------------------------------
    def _do_play(self):
        if self.free_roam:
            self._stop_roam()
        else:
            self._start_roam()

    def _start_roam(self):
        if not self.pet.can_act():
            self._toast("牠現在正忙著呢。")
            return
        self.free_roam = True
        self.menu.entryconfig(self._play_menu_index, label="停止自由活動(G)")
        self._toast(f"{self.pet.name} 開始到處蹦蹦跳跳！")
        self._roam_pick_action()  # 對應 sub_4037A0：切換模式當下立刻挑一次動作
        self._roam_tick_loop()

    def _stop_roam(self):
        if not self.free_roam:
            return
        self.free_roam = False
        self.roam_action = None
        if self._roam_timer_id is not None:
            self.root.after_cancel(self._roam_timer_id)
            self._roam_timer_id = None
        self.menu.entryconfig(self._play_menu_index, label="開始自由活動(G)")

    def _roam_tick_loop(self):
        if not self.free_roam:
            return
        self.pet.roam_tick()
        self.root.after(ROAM_TICK_MS, self._roam_tick_loop)

    def _toast(self, msg):
        """在兔子頭上冒出一個小對話泡泡顯示訊息，兩秒後自動消失。"""
        bubble = tk.Toplevel(self.win)
        bubble.overrideredirect(True)
        bubble.attributes("-topmost", True)
        label = tk.Label(
            bubble,
            text=msg,
            bg="#fffbe6",
            fg="#333333",
            font=("Microsoft JhengHei", 9),
            padx=8,
            pady=4,
            relief="solid",
            borderwidth=1,
            wraplength=220,
        )
        label.pack()
        bubble.update_idletasks()
        bw = bubble.winfo_width()
        bx = self.x + self.sprite_w // 2 - bw // 2
        by = max(0, self.y - bubble.winfo_height() - 6)
        bubble.geometry(f"+{bx}+{by}")
        bubble.after(2200, bubble.destroy)

    def _refresh_after_change(self):
        pass

    def _sync_pet_window_position(self):
        self.pet.window_x = int(self.x)
        self.pet.window_y = int(self.y)

    # ------------------------------------------------------------------
    # 動畫
    # ------------------------------------------------------------------
    def _current_activity_key(self):
        act = self.pet.activity
        if self.free_roam and self.roam_action is not None:
            return f"walk_{self.facing}"
        return act

    def _set_frame(self, img):
        """把 canvas 上顯示的圖換成 img，並在圖片尺寸跟目前 canvas/視窗
        尺寸不一致時，同步調整 canvas 與視窗大小。

        原本 canvas/視窗大小只在程式啟動時依「待機」影格（146.bmp，
        60x88）量一次，之後就固定不變；但不同動作用的 bmp 尺寸其實差很
        多（例如勞動 144/145.bmp 是 98x106，眨眼反應 152.bmp 是
        92x87），畫到比待機影格大張的圖時，超出視窗範圍的部分會被
        overrideredirect 視窗本身的邊界直接裁掉——這就是「精靈圖片會
        超出顯示範圍」的成因。這裡改成每次換圖都檢查尺寸，需要的話就
        跟著放大/縮小視窗，並且用「底部+水平中心」對齊而不是單純固定
        左上角，這樣換成不同尺寸的影格時，兔子看起來仍然站在原地（腳
        底沒有跳動），只是視窗框本身跟著圖片大小長大或縮小。
        """
        if img is None:
            return
        new_w, new_h = img.width(), img.height()
        if new_w != self.sprite_w or new_h != self.sprite_h:
            self.x += (self.sprite_w - new_w) // 2
            self.y += self.sprite_h - new_h
            self.sprite_w, self.sprite_h = new_w, new_h
            self.canvas.config(width=self.sprite_w, height=self.sprite_h)
            self.win.geometry(f"{self.sprite_w}x{self.sprite_h}+{self.x}+{self.y}")
            self._sync_pet_window_position()
        self.canvas.itemconfig(self.image_id, image=img)
        self._img_ref = img  # 保留參照避免被 GC 回收

    def _update_sprite(self):
        if self.reaction_kind is not None or getattr(self, "_quick_ack_active", False):
            # 反應動畫（眨眼/跳一下，或收尾用的 QuickAck 閃爍）播放中，
            # 畫面交給對應的函式自己控制，這裡先讓路，避免每 150ms 一次
            # 的一般待機動畫把閃爍中的畫面蓋掉。
            return
        key = self._current_activity_key()
        n = self.sprites.frame_count(key)
        self.frame_index = (self.frame_index + 1) % max(n, 1)
        img = self.sprites.frame(key, self.frame_index)
        self._set_frame(img)

    def _animation_loop(self):
        self._update_sprite()
        self.root.after(ANIM_MS, self._animation_loop)

    # ------------------------------------------------------------------
    # 點擊反應動畫（對應原始碼 sub_4050A0「眨眼」/ sub_405930「跳一下」，
    # 由 sub_405C40 點擊時 rand()%2 隨機挑一種播放）。播放期間會暫停一般
    # 待機動畫的換格（見 _update_sprite 的防呆），跑完固定的影格序列後
    # 自動交還給一般動畫迴圈。
    # ------------------------------------------------------------------
    def _play_click_reaction(self, kind):
        self.reaction_kind = kind
        self.reaction_frames = CLICK_REACTION_SEQUENCES[kind]
        self.reaction_index = 0
        self._show_click_reaction_frame()
        tick = REACTION_TICK_MS[kind]
        self._reaction_timer_id = self.root.after(tick, self._advance_click_reaction)

    def _advance_click_reaction(self):
        self.reaction_index += 1
        if self.reaction_index >= len(self.reaction_frames):
            self._finish_click_reaction()
            return
        self._show_click_reaction_frame()
        tick = REACTION_TICK_MS[self.reaction_kind]
        self._reaction_timer_id = self.root.after(tick, self._advance_click_reaction)

    def _show_click_reaction_frame(self):
        bmp_id = self.reaction_frames[self.reaction_index]
        img = self.sprites.reaction_bmp(bmp_id)
        self._set_frame(img)

    def _finish_click_reaction(self):
        # 原始碼 sub_405C40 隨機挑中的「眨眼」「跳一下」反應播完後，
        # 也是靠這同一個 sub_404F50 (Anim_QuickAck) 收尾。
        self.reaction_kind = None
        self._reaction_timer_id = None
        self._play_quick_ack()

    # ------------------------------------------------------------------
    # 閒置狀態下的隨機小動作（對應原始碼 sub_405C80 / Anim_IdleGesture）。
    # 跟上面的點擊反應共用同一套「暫停一般待機動畫、200ms 換一格」機制
    # （見 _update_sprite 對 reaction_kind 的防呆判斷），差別是：
    #   1. 影格序列固定是 155→162→160→146（IDLE_GESTURE_SEQUENCE），
    #      不是點擊觸發，而是由 _game_tick_loop 每個心跳以 50% 機率
    #      隨機觸發（對應 sub_405370 尾端的 rand()%2）。
    #   2. 播完最後一格（146，其實就是待機基本站姿）後直接結束、交還
    #      給一般待機動畫，原始碼這裡沒有再接 sub_404F50 QuickAck 閃爍
    #      （跟「眨眼/跳一下」點擊反應不同，所以不能複用
    #      _finish_click_reaction，得自己收尾）。
    # ------------------------------------------------------------------
    def _play_idle_gesture(self):
        self.reaction_kind = "idle_gesture"
        self.reaction_frames = IDLE_GESTURE_SEQUENCE
        self.reaction_index = 0
        self._show_click_reaction_frame()
        self._reaction_timer_id = self.root.after(
            IDLE_GESTURE_TICK_MS, self._advance_idle_gesture
        )

    def _advance_idle_gesture(self):
        self.reaction_index += 1
        if self.reaction_index >= len(self.reaction_frames):
            # 對應 case '^'：KillTimer，不接 QuickAck，直接回到一般待機動畫。
            self.reaction_kind = None
            self._reaction_timer_id = None
            self._update_sprite()
            return
        self._show_click_reaction_frame()
        self._reaction_timer_id = self.root.after(
            IDLE_GESTURE_TICK_MS, self._advance_idle_gesture
        )

    # ------------------------------------------------------------------
    # QuickAck 收尾閃爍（對應原始碼 sub_404F50）：在「目前外觀」跟
    # bmp133 之間閃爍 2 輪 (200ms 切到133 -> 300ms 切回原本外觀)。
    # 原始碼裡，下面幾個地方結算完都會呼叫這個小動畫，這裡照樣呼叫：
    #   - sub_403920 吃東西結算完                 -> eat() 完成時
    #   - sub_403BD0 喝水結算完                    -> drink() 完成時
    #   - sub_4047B0 工作結算完（不論有沒有拿到獎勵/太累）-> work() 完成時
    #   - sub_4057B0 睡滿一輪、自然醒來             -> 睡眠自然結束時
    # bmp133 不是待機姿勢(待機基本站姿其實是146.bmp，見 sprites.py
    # 對 _DEFAULT_IDLE 的說明)，所以這一下閃爍在畫面上看得出來，
    # 不能省略不播。
    # ------------------------------------------------------------------
    def _play_quick_ack(self):
        self._quick_ack_round = 0
        self._quick_ack_active = True
        self._quick_ack_flash()

    def _quick_ack_flash(self):
        """對應 sub_404F50 (Anim_QuickAck)：短暫閃一下 bmp133，
        再切回目前活動該有的一般外觀，重複2輪。"""
        img = self.sprites.reaction_bmp(133)
        self._set_frame(img)
        self._reaction_timer_id = self.root.after(200, self._quick_ack_restore)

    def _quick_ack_restore(self):
        self._quick_ack_active = False
        self._update_sprite()
        self._quick_ack_round += 1
        if self._quick_ack_round <= 1:
            self._quick_ack_active = True
            self._reaction_timer_id = self.root.after(300, self._quick_ack_flash)
        else:
            self._reaction_timer_id = None

    # ------------------------------------------------------------------
    # 自由活動時的隨機走/跳（對應原始碼 sub_4037A0 挑動作 +
    # sub_403050/sub_403560/sub_403260/sub_4033E0 走跳動畫）
    #
    # 原版不是「挑一個隨機終點、平滑走過去」，而是：每次隨機挑 4 選 1
    # （向左走／向右走／左下跳／右下跳），用固定像素步伐一格一格移動，
    # 碰到螢幕邊界就瞬間繞到對面（不是彈回來），跑完固定格數後再重新
    # 隨機挑下一個動作。這裡照原始碼的參數/邊界判斷式逐一還原。
    # ------------------------------------------------------------------
    def _roam_pick_action(self):
        """對應 sub_4037A0 的挑動作部分（數值代價結算已經獨立交給
        _roam_tick_loop/ROAM_TICK_MS 處理，這裡只負責 rand()%4 選動作）。"""
        if not self.free_roam:
            return
        kind = random.randint(0, 3)  # 0=右 1=左 2=左下跳 3=右下跳，對照 sub_4037A0 的 switch
        if kind == 0:
            self.roam_action = "walk_right"
            self.roam_frame = 0
            self.facing = "right"
            self._roam_walk_step()
        elif kind == 1:
            self.roam_action = "walk_left"
            self.roam_frame = 0
            self.facing = "left"
            self._roam_walk_step()
        elif kind == 2:
            self.roam_action = "hop_left"
            self.roam_hop_steps = 0
            self.facing = "down_left"
            self._roam_hop_step()
        else:
            self.roam_action = "hop_right"
            self.roam_hop_steps = 0
            self.facing = "down_right"
            self._roam_hop_step()

    def _roam_finish_action(self):
        """對應原始碼跑完固定格數後 KillTimer + SetTimer(0xBB8,0x96)：
        交還給「自由活動挑動作」計時器，延遲 150ms 後再挑下一個動作。"""
        self.roam_action = None
        self._roam_timer_id = self.root.after(WALK_TICK_MS, self._roam_pick_action)

    def _roam_walk_step(self):
        """對應 sub_403050（向左走）/ sub_403560（向右走）：
        每 150ms 一格，水平移動 WALK_STEP_PX，碰邊界瞬間繞到對面，
        跑滿 WALK_FRAMES 格後交還挑動作。"""
        if not self.free_roam or self.pet.activity != "idle":
            return
        screen_w = self.win.winfo_screenwidth()
        if self.roam_action == "walk_left":
            if self.x - WALK_STEP_PX <= -WRAP_MARGIN:
                self.x = screen_w - 5           # 從左邊界瞬間繞到螢幕右側
            else:
                self.x -= WALK_STEP_PX
        else:  # walk_right
            if self.x + WALK_STEP_PX >= screen_w:
                self.x = 0                      # 從右邊界瞬間繞到螢幕左側
            else:
                self.x += WALK_STEP_PX
        self.win.geometry(f"+{self.x}+{self.y}")
        self._sync_pet_window_position()
        self.roam_frame += 1
        if self.roam_frame >= WALK_FRAMES:
            self._roam_finish_action()
        else:
            self._roam_timer_id = self.root.after(WALK_TICK_MS, self._roam_walk_step)

    def _roam_hop_step(self):
        """對應 sub_403260（左下跳）/ sub_4033E0（右下跳）：
        每 200ms 一格，水平移動 HOP_STEP_X、垂直移動 HOP_STEP_Y（皆碰邊界
        瞬間繞到對面），跑滿 HOP_TOTAL_STEPS 格後交還挑動作。"""
        if not self.free_roam or self.pet.activity != "idle":
            return
        screen_w = self.win.winfo_screenwidth()
        screen_h = self.win.winfo_screenheight()
        if self.roam_action == "hop_left":
            if self.x - HOP_STEP_X <= -WRAP_MARGIN:
                self.x = screen_w - 7           # 從左邊界瞬間繞到螢幕右側
            else:
                self.x -= HOP_STEP_X
        else:  # hop_right
            if self.x + HOP_STEP_X >= screen_w:
                self.x = 0                       # 從右邊界瞬間繞到螢幕左側
            else:
                self.x += HOP_STEP_X
        # 垂直方向兩個跳躍動作都是往下移動，碰到底部就瞬間繞回最上面
        self.y = 0 if self.y + HOP_STEP_Y >= screen_h else self.y + HOP_STEP_Y
        self.win.geometry(f"+{self.x}+{self.y}")
        self._sync_pet_window_position()
        self.roam_hop_steps += 1
        if self.roam_hop_steps >= HOP_TOTAL_STEPS:
            self._roam_finish_action()
        else:
            self._roam_timer_id = self.root.after(HOP_TICK_MS, self._roam_hop_step)

    # ------------------------------------------------------------------
    # 數值心跳（飢餓、口渴、體力……）
    # ------------------------------------------------------------------
    def _game_tick_loop(self):
        was_sleeping = self.pet.activity == "sleeping"
        self.pet.tick()
        if was_sleeping and self.pet.activity == "idle":
            # 睡滿一輪、自然醒來，對應 sub_4057B0 結尾呼叫的 sub_404F50
            # (Anim_QuickAck)，見 _play_quick_ack 說明。
            self._play_quick_ack()
        for title, msg in self.pet.pending_warnings:
            messagebox.showwarning(title, msg)
        # 對應原始碼 sub_405370：每 10 次生命週期 tick（約每10分鐘）才自動
        # 存檔一次，而不是每次 tick 都存；growth_counter 每次 tick 遞增，
        # 滿10就歸零，剛好可以拿來當這個節流的判斷點。
        if self.pet.growth_counter == 0:
            self._sync_pet_window_position()
            self.pet.save()

        if self.pet.in_crisis:
            # 還原 sub_405370 的「異常/危機」分支：饑餓或口渴見底時，原始碼
            # 呼叫 sub_404B40() 把所有動畫計時器 (1000~14000) 全部 KillTimer，
            # 兔子會整隻凍結在畫面上不再動，只剩每分鐘的警告訊息框持續跳出
            # （並沒有把已領養旗標清掉，所以不是真的死亡淘汰，是「餓/渴到
            # 僵住」）。這裡對應停掉自由活動與待機反應動畫的排程；玩家一旦
            # 餵食/給水讓饑餓或口渴回升，下次 tick 就會離開這個分支，之後
            # 的餵食/勞動/自由活動等操作會照常重新排程動畫，等於「解凍」。
            self._freeze_for_crisis()
        else:
            # 對應 sub_405370 尾端：不在睡覺、也不在自由活動時，每個心跳有
            # 50% 機率隨機觸發一個閒置反應動畫，二選一（對應 rand()%2）：
            #   - sub_404F50 (Anim_QuickAck)：跟目前外觀與 bmp133 之間閃爍
            #   - sub_405C80 (Anim_IdleGesture)：155→162→160→146 依序播放
            # 只有真的沒在忙(閒置、沒有其他反應動畫在播)時才觸發，避免蓋掉
            # 吃/喝/勞動/睡覺/自由活動/其他反應動畫正在播放的畫面。
            if (
                self.pet.activity == "idle"
                and not self.free_roam
                and self.reaction_kind is None
                and not getattr(self, "_quick_ack_active", False)
            ):
                if random.randint(0, 1) == 0:
                    self._play_idle_gesture()
                else:
                    self._play_quick_ack()

        self.root.after(int(TICK_SECONDS * 1000), self._game_tick_loop)

    def _set_interactive_menu_enabled(self, enabled):
        """對應 sub_404EF0：批次啟用/停用選單裡「狀態/吃喝/勞動/自由活動/
        睡覺/察看物品」這幾個互動項目。停用時只留下「關於」「領養兔子」
        「軟體設置」「退出」可以點——跟原版兔子死亡凍結時、右鍵選單只剩
        這四項可用的畫面一致。"""
        state = tk.NORMAL if enabled else tk.DISABLED
        for i in self._interactive_menu_indices:
            self.menu.entryconfig(i, state=state)

    def _freeze_for_crisis(self):
        """饑餓或口渴見底時的凍結處理，對應 sub_404B40 KillTimer 掉所有
        動畫計時器、sub_404EF0(2) 灰掉互動選單：停掉自由活動排程、取消
        尚在進行中的待機反應動畫，並讓選單只剩「關於/領養兔子/軟體設置/
        退出」可以點——玩家此時已經無法再餵食/查看狀態，只能重新領養一
        隻新兔子，等於原版「死了」的死路狀態。"""
        if self.free_roam:
            self._stop_roam()
        if self._reaction_timer_id is not None:
            self.root.after_cancel(self._reaction_timer_id)
            self._reaction_timer_id = None
        self.reaction_kind = None
        self._quick_ack_active = False
        self._set_interactive_menu_enabled(False)

    # ------------------------------------------------------------------
    def _quit(self):
        self._sync_pet_window_position()
        self.pet.save()
        self.root.destroy()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    app = RabbitPet()
    app.run()
