#!/bin/bash
# 雙擊這個檔案就會開一個 Terminal 視窗，自動執行 main.py。
#
# 第一次使用前，請先在 Terminal 裡執行一次（給它「可執行」權限）：
#   chmod +x 啟動兔子.command
# 之後就可以直接在 Finder 裡雙擊這個檔案來開啟兔子桌寵了。
#
# 如果雙擊後跳出「無法確認開發者」的警告：在檔案上按右鍵（或
# Control+點擊）選「打開」，再按一次「打開」放行即可，之後雙擊就正常了。

cd "$(dirname "$0")"

if ! command -v python3 &> /dev/null; then
    echo "找不到 python3，請先安裝 Python 3："
    echo "  - 到 https://www.python.org/downloads/ 下載官方安裝包（建議）"
    echo "  - 或執行：brew install python-tk"
    echo ""
    read -p "按 Enter 鍵關閉視窗..."
    exit 1
fi

if ! python3 -c "import tkinter" 2>/dev/null; then
    echo "這個 Python 沒有內建 tkinter（常見於某些 Homebrew 版本）。"
    echo "請改用 python.org 官方安裝包，或執行：brew install python-tk"
    echo ""
    read -p "按 Enter 鍵關閉視窗..."
    exit 1
fi

python3 main.py

# 讓視窗在程式結束後留著，方便看到錯誤訊息（如果有的話）。
echo ""
echo "程式已結束。"
read -p "按 Enter 鍵關閉視窗..."
